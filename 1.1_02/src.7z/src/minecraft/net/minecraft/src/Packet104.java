package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet104 extends Packet {
	public int field_20036_a;
	public ItemStack[] field_20035_b;

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.field_20036_a = dataInputStream1.readByte();
		short s2 = dataInputStream1.readShort();
		this.field_20035_b = new ItemStack[s2];

		for(int i3 = 0; i3 < s2; ++i3) {
			short s4 = dataInputStream1.readShort();
			if(s4 >= 0) {
				byte b5 = dataInputStream1.readByte();
				short s6 = dataInputStream1.readShort();
				this.field_20035_b[i3] = new ItemStack(s4, b5, s6);
			}
		}

	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeByte(this.field_20036_a);
		dataOutputStream1.writeShort(this.field_20035_b.length);

		for(int i2 = 0; i2 < this.field_20035_b.length; ++i2) {
			if(this.field_20035_b[i2] == null) {
				dataOutputStream1.writeShort(-1);
			} else {
				dataOutputStream1.writeShort((short)this.field_20035_b[i2].itemID);
				dataOutputStream1.writeByte((byte)this.field_20035_b[i2].stackSize);
				dataOutputStream1.writeShort((short)this.field_20035_b[i2].itemDamage);
			}
		}

	}

	public void processPacket(NetHandler netHandler1) {
		netHandler1.func_20094_a(this);
	}

	public int getPacketSize() {
		return 3 + this.field_20035_b.length * 5;
	}
}
