package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet39 extends Packet {
	public int field_6365_a;
	public int field_6364_b;

	public int getPacketSize() {
		return 8;
	}

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.field_6365_a = dataInputStream1.readInt();
		this.field_6364_b = dataInputStream1.readInt();
	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeInt(this.field_6365_a);
		dataOutputStream1.writeInt(this.field_6364_b);
	}

	public void processPacket(NetHandler netHandler1) {
		netHandler1.func_6497_a(this);
	}
}
