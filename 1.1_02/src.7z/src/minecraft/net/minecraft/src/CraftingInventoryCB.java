package net.minecraft.src;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public abstract class CraftingInventoryCB {
	public List field_20123_d = new ArrayList();
	public List field_20122_e = new ArrayList();
	public int unusedList = 0;
	private short craftMatrix = 0;
	protected List field_20121_g = new ArrayList();
	private Set craftResult = new HashSet();

	protected void func_20117_a(Slot slot1) {
		slot1.field_20007_a = this.field_20122_e.size();
		this.field_20122_e.add(slot1);
		this.field_20123_d.add((Object)null);
	}

	public void func_20114_a() {
		for(int i1 = 0; i1 < this.field_20122_e.size(); ++i1) {
			ItemStack itemStack2 = ((Slot)this.field_20122_e.get(i1)).getStack();
			ItemStack itemStack3 = (ItemStack)this.field_20123_d.get(i1);
			if(!ItemStack.func_20107_a(itemStack3, itemStack2)) {
				itemStack3 = itemStack2 == null ? null : itemStack2.copy();
				this.field_20123_d.set(i1, itemStack3);

				for(int i4 = 0; i4 < this.field_20121_g.size(); ++i4) {
					((ICrafting)this.field_20121_g.get(i4)).func_20159_a(this, i1, itemStack3);
				}
			}
		}

	}

	public Slot func_20118_a(int i1) {
		return (Slot)this.field_20122_e.get(i1);
	}

	public ItemStack func_20116_a(int i1, int i2, EntityPlayer entityPlayer3) {
		ItemStack itemStack4 = null;
		if(i2 == 0 || i2 == 1) {
			InventoryPlayer inventoryPlayer5 = entityPlayer3.inventory;
			if(i1 == -999) {
				if(inventoryPlayer5.func_20075_i() != null && i1 == -999) {
					if(i2 == 0) {
						entityPlayer3.dropPlayerItem(inventoryPlayer5.func_20075_i());
						inventoryPlayer5.func_20076_b((ItemStack)null);
					}

					if(i2 == 1) {
						entityPlayer3.dropPlayerItem(inventoryPlayer5.func_20075_i().splitStack(1));
						if(inventoryPlayer5.func_20075_i().stackSize == 0) {
							inventoryPlayer5.func_20076_b((ItemStack)null);
						}
					}
				}
			} else {
				Slot slot6 = (Slot)this.field_20122_e.get(i1);
				if(slot6 != null) {
					slot6.onSlotChanged();
					ItemStack itemStack7 = slot6.getStack();
					if(itemStack7 != null) {
						itemStack4 = itemStack7.copy();
					}

					if(itemStack7 != null || inventoryPlayer5.func_20075_i() != null) {
						int i8;
						if(itemStack7 != null && inventoryPlayer5.func_20075_i() == null) {
							i8 = i2 == 0 ? itemStack7.stackSize : (itemStack7.stackSize + 1) / 2;
							inventoryPlayer5.func_20076_b(slot6.func_20004_a(i8));
							if(itemStack7.stackSize == 0) {
								slot6.putStack((ItemStack)null);
							}

							slot6.onPickupFromSlot();
						} else if(itemStack7 == null && inventoryPlayer5.func_20075_i() != null && slot6.isItemValid(inventoryPlayer5.func_20075_i())) {
							i8 = i2 == 0 ? inventoryPlayer5.func_20075_i().stackSize : 1;
							if(i8 > slot6.getSlotStackLimit()) {
								i8 = slot6.getSlotStackLimit();
							}

							slot6.putStack(inventoryPlayer5.func_20075_i().splitStack(i8));
							if(inventoryPlayer5.func_20075_i().stackSize == 0) {
								inventoryPlayer5.func_20076_b((ItemStack)null);
							}
						} else if(itemStack7 != null && inventoryPlayer5.func_20075_i() != null) {
							if(slot6.isItemValid(inventoryPlayer5.func_20075_i())) {
								if(itemStack7.itemID != inventoryPlayer5.func_20075_i().itemID) {
									if(inventoryPlayer5.func_20075_i().stackSize <= slot6.getSlotStackLimit()) {
										slot6.putStack(inventoryPlayer5.func_20075_i());
										inventoryPlayer5.func_20076_b(itemStack7);
									}
								} else if(itemStack7.itemID == inventoryPlayer5.func_20075_i().itemID) {
									if(i2 == 0) {
										i8 = inventoryPlayer5.func_20075_i().stackSize;
										if(i8 > slot6.getSlotStackLimit() - itemStack7.stackSize) {
											i8 = slot6.getSlotStackLimit() - itemStack7.stackSize;
										}

										if(i8 > inventoryPlayer5.func_20075_i().getMaxStackSize() - itemStack7.stackSize) {
											i8 = inventoryPlayer5.func_20075_i().getMaxStackSize() - itemStack7.stackSize;
										}

										inventoryPlayer5.func_20075_i().splitStack(i8);
										if(inventoryPlayer5.func_20075_i().stackSize == 0) {
											inventoryPlayer5.func_20076_b((ItemStack)null);
										}

										itemStack7.stackSize += i8;
									} else if(i2 == 1) {
										i8 = 1;
										if(i8 > slot6.getSlotStackLimit() - itemStack7.stackSize) {
											i8 = slot6.getSlotStackLimit() - itemStack7.stackSize;
										}

										if(i8 > inventoryPlayer5.func_20075_i().getMaxStackSize() - itemStack7.stackSize) {
											i8 = inventoryPlayer5.func_20075_i().getMaxStackSize() - itemStack7.stackSize;
										}

										inventoryPlayer5.func_20075_i().splitStack(i8);
										if(inventoryPlayer5.func_20075_i().stackSize == 0) {
											inventoryPlayer5.func_20076_b((ItemStack)null);
										}

										itemStack7.stackSize += i8;
									}
								}
							} else if(itemStack7.itemID == inventoryPlayer5.func_20075_i().itemID && inventoryPlayer5.func_20075_i().getMaxStackSize() > 1) {
								i8 = itemStack7.stackSize;
								if(i8 > 0 && i8 + inventoryPlayer5.func_20075_i().stackSize <= inventoryPlayer5.func_20075_i().getMaxStackSize()) {
									ItemStack itemStack10000 = inventoryPlayer5.func_20075_i();
									itemStack10000.stackSize += i8;
									itemStack7.splitStack(i8);
									if(itemStack7.stackSize == 0) {
										slot6.putStack((ItemStack)null);
									}

									slot6.onPickupFromSlot();
								}
							}
						}
					}
				}
			}
		}

		return itemStack4;
	}

	public void onCraftGuiClosed(EntityPlayer entityPlayer1) {
		InventoryPlayer inventoryPlayer2 = entityPlayer1.inventory;
		if(inventoryPlayer2.func_20075_i() != null) {
			entityPlayer1.dropPlayerItem(inventoryPlayer2.func_20075_i());
			inventoryPlayer2.func_20076_b((ItemStack)null);
		}

	}

	public void onCraftMatrixChanged(IInventory iInventory1) {
		this.func_20114_a();
	}

	public void func_20119_a(int i1, ItemStack itemStack2) {
		this.func_20118_a(i1).putStack(itemStack2);
	}

	public void func_20115_a(ItemStack[] itemStack1) {
		for(int i2 = 0; i2 < itemStack1.length; ++i2) {
			this.func_20118_a(i2).putStack(itemStack1[i2]);
		}

	}

	public void func_20112_a(int i1, int i2) {
	}

	public short func_20111_a(InventoryPlayer inventoryPlayer1) {
		++this.craftMatrix;
		return this.craftMatrix;
	}

	public void func_20113_a(short s1) {
	}

	public void func_20110_b(short s1) {
	}

	public abstract boolean func_20120_b(EntityPlayer entityPlayer1);
}
