package net.minecraft.src;

import java.util.ArrayList;
import java.util.List;

class MinecartTrackLogic {
	private World worldObj;
	private int field_1165_c;
	private int field_1164_d;
	private int field_1163_e;
	private int field_1162_f;
	private List field_1161_g;
	final BlockMinecartTrack field_1160_a;

	public MinecartTrackLogic(BlockMinecartTrack blockMinecartTrack1, World world2, int i3, int i4, int i5) {
		this.field_1160_a = blockMinecartTrack1;
		this.field_1161_g = new ArrayList();
		this.worldObj = world2;
		this.field_1165_c = i3;
		this.field_1164_d = i4;
		this.field_1163_e = i5;
		this.field_1162_f = world2.getBlockMetadata(i3, i4, i5);
		this.func_789_a();
	}

	private void func_789_a() {
		this.field_1161_g.clear();
		if(this.field_1162_f == 0) {
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1));
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1));
		} else if(this.field_1162_f == 1) {
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e));
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e));
		} else if(this.field_1162_f == 2) {
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e));
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c + 1, this.field_1164_d + 1, this.field_1163_e));
		} else if(this.field_1162_f == 3) {
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c - 1, this.field_1164_d + 1, this.field_1163_e));
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e));
		} else if(this.field_1162_f == 4) {
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e - 1));
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1));
		} else if(this.field_1162_f == 5) {
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1));
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e + 1));
		} else if(this.field_1162_f == 6) {
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e));
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1));
		} else if(this.field_1162_f == 7) {
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e));
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1));
		} else if(this.field_1162_f == 8) {
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e));
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1));
		} else if(this.field_1162_f == 9) {
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e));
			this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1));
		}

	}

	private void func_785_b() {
		for(int i1 = 0; i1 < this.field_1161_g.size(); ++i1) {
			MinecartTrackLogic minecartTrackLogic2 = this.func_795_a((ChunkPosition)this.field_1161_g.get(i1));
			if(minecartTrackLogic2 != null && minecartTrackLogic2.func_793_b(this)) {
				this.field_1161_g.set(i1, new ChunkPosition(minecartTrackLogic2.field_1165_c, minecartTrackLogic2.field_1164_d, minecartTrackLogic2.field_1163_e));
			} else {
				this.field_1161_g.remove(i1--);
			}
		}

	}

	private boolean func_784_a(int i1, int i2, int i3) {
		return this.worldObj.getBlockId(i1, i2, i3) == this.field_1160_a.blockID ? true : (this.worldObj.getBlockId(i1, i2 + 1, i3) == this.field_1160_a.blockID ? true : this.worldObj.getBlockId(i1, i2 - 1, i3) == this.field_1160_a.blockID);
	}

	private MinecartTrackLogic func_795_a(ChunkPosition chunkPosition1) {
		return this.worldObj.getBlockId(chunkPosition1.x, chunkPosition1.y, chunkPosition1.z) == this.field_1160_a.blockID ? new MinecartTrackLogic(this.field_1160_a, this.worldObj, chunkPosition1.x, chunkPosition1.y, chunkPosition1.z) : (this.worldObj.getBlockId(chunkPosition1.x, chunkPosition1.y + 1, chunkPosition1.z) == this.field_1160_a.blockID ? new MinecartTrackLogic(this.field_1160_a, this.worldObj, chunkPosition1.x, chunkPosition1.y + 1, chunkPosition1.z) : (this.worldObj.getBlockId(chunkPosition1.x, chunkPosition1.y - 1, chunkPosition1.z) == this.field_1160_a.blockID ? new MinecartTrackLogic(this.field_1160_a, this.worldObj, chunkPosition1.x, chunkPosition1.y - 1, chunkPosition1.z) : null));
	}

	private boolean func_793_b(MinecartTrackLogic minecartTrackLogic1) {
		for(int i2 = 0; i2 < this.field_1161_g.size(); ++i2) {
			ChunkPosition chunkPosition3 = (ChunkPosition)this.field_1161_g.get(i2);
			if(chunkPosition3.x == minecartTrackLogic1.field_1165_c && chunkPosition3.z == minecartTrackLogic1.field_1163_e) {
				return true;
			}
		}

		return false;
	}

	private boolean func_794_b(int i1, int i2, int i3) {
		for(int i4 = 0; i4 < this.field_1161_g.size(); ++i4) {
			ChunkPosition chunkPosition5 = (ChunkPosition)this.field_1161_g.get(i4);
			if(chunkPosition5.x == i1 && chunkPosition5.z == i3) {
				return true;
			}
		}

		return false;
	}

	private int func_790_c() {
		int i1 = 0;
		if(this.func_784_a(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1)) {
			++i1;
		}

		if(this.func_784_a(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1)) {
			++i1;
		}

		if(this.func_784_a(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e)) {
			++i1;
		}

		if(this.func_784_a(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e)) {
			++i1;
		}

		return i1;
	}

	private boolean handleKeyPress(MinecartTrackLogic minecartTrackLogic1) {
		if(this.func_793_b(minecartTrackLogic1)) {
			return true;
		} else if(this.field_1161_g.size() == 2) {
			return false;
		} else if(this.field_1161_g.size() == 0) {
			return true;
		} else {
			ChunkPosition chunkPosition2 = (ChunkPosition)this.field_1161_g.get(0);
			return minecartTrackLogic1.field_1164_d == this.field_1164_d && chunkPosition2.y == this.field_1164_d ? true : true;
		}
	}

	private void func_788_d(MinecartTrackLogic minecartTrackLogic1) {
		this.field_1161_g.add(new ChunkPosition(minecartTrackLogic1.field_1165_c, minecartTrackLogic1.field_1164_d, minecartTrackLogic1.field_1163_e));
		boolean z2 = this.func_794_b(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1);
		boolean z3 = this.func_794_b(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1);
		boolean z4 = this.func_794_b(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e);
		boolean z5 = this.func_794_b(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e);
		byte b6 = -1;
		if(z2 || z3) {
			b6 = 0;
		}

		if(z4 || z5) {
			b6 = 1;
		}

		if(z3 && z5 && !z2 && !z4) {
			b6 = 6;
		}

		if(z3 && z4 && !z2 && !z5) {
			b6 = 7;
		}

		if(z2 && z4 && !z3 && !z5) {
			b6 = 8;
		}

		if(z2 && z5 && !z3 && !z4) {
			b6 = 9;
		}

		if(b6 == 0) {
			if(this.worldObj.getBlockId(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e - 1) == this.field_1160_a.blockID) {
				b6 = 4;
			}

			if(this.worldObj.getBlockId(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e + 1) == this.field_1160_a.blockID) {
				b6 = 5;
			}
		}

		if(b6 == 1) {
			if(this.worldObj.getBlockId(this.field_1165_c + 1, this.field_1164_d + 1, this.field_1163_e) == this.field_1160_a.blockID) {
				b6 = 2;
			}

			if(this.worldObj.getBlockId(this.field_1165_c - 1, this.field_1164_d + 1, this.field_1163_e) == this.field_1160_a.blockID) {
				b6 = 3;
			}
		}

		if(b6 < 0) {
			b6 = 0;
		}

		this.worldObj.setBlockMetadataWithNotify(this.field_1165_c, this.field_1164_d, this.field_1163_e, b6);
	}

	private boolean func_786_c(int i1, int i2, int i3) {
		MinecartTrackLogic minecartTrackLogic4 = this.func_795_a(new ChunkPosition(i1, i2, i3));
		if(minecartTrackLogic4 == null) {
			return false;
		} else {
			minecartTrackLogic4.func_785_b();
			return minecartTrackLogic4.handleKeyPress(this);
		}
	}

	public void func_792_a(boolean z1) {
		boolean z2 = this.func_786_c(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1);
		boolean z3 = this.func_786_c(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1);
		boolean z4 = this.func_786_c(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e);
		boolean z5 = this.func_786_c(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e);
		byte b6 = -1;
		if((z2 || z3) && !z4 && !z5) {
			b6 = 0;
		}

		if((z4 || z5) && !z2 && !z3) {
			b6 = 1;
		}

		if(z3 && z5 && !z2 && !z4) {
			b6 = 6;
		}

		if(z3 && z4 && !z2 && !z5) {
			b6 = 7;
		}

		if(z2 && z4 && !z3 && !z5) {
			b6 = 8;
		}

		if(z2 && z5 && !z3 && !z4) {
			b6 = 9;
		}

		if(b6 == -1) {
			if(z2 || z3) {
				b6 = 0;
			}

			if(z4 || z5) {
				b6 = 1;
			}

			if(z1) {
				if(z3 && z5) {
					b6 = 6;
				}

				if(z4 && z3) {
					b6 = 7;
				}

				if(z5 && z2) {
					b6 = 9;
				}

				if(z2 && z4) {
					b6 = 8;
				}
			} else {
				if(z2 && z4) {
					b6 = 8;
				}

				if(z5 && z2) {
					b6 = 9;
				}

				if(z4 && z3) {
					b6 = 7;
				}

				if(z3 && z5) {
					b6 = 6;
				}
			}
		}

		if(b6 == 0) {
			if(this.worldObj.getBlockId(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e - 1) == this.field_1160_a.blockID) {
				b6 = 4;
			}

			if(this.worldObj.getBlockId(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e + 1) == this.field_1160_a.blockID) {
				b6 = 5;
			}
		}

		if(b6 == 1) {
			if(this.worldObj.getBlockId(this.field_1165_c + 1, this.field_1164_d + 1, this.field_1163_e) == this.field_1160_a.blockID) {
				b6 = 2;
			}

			if(this.worldObj.getBlockId(this.field_1165_c - 1, this.field_1164_d + 1, this.field_1163_e) == this.field_1160_a.blockID) {
				b6 = 3;
			}
		}

		if(b6 < 0) {
			b6 = 0;
		}

		this.field_1162_f = b6;
		this.func_789_a();
		this.worldObj.setBlockMetadataWithNotify(this.field_1165_c, this.field_1164_d, this.field_1163_e, b6);

		for(int i7 = 0; i7 < this.field_1161_g.size(); ++i7) {
			MinecartTrackLogic minecartTrackLogic8 = this.func_795_a((ChunkPosition)this.field_1161_g.get(i7));
			if(minecartTrackLogic8 != null) {
				minecartTrackLogic8.func_785_b();
				if(minecartTrackLogic8.handleKeyPress(this)) {
					minecartTrackLogic8.func_788_d(this);
				}
			}
		}

	}

	static int func_791_a(MinecartTrackLogic minecartTrackLogic0) {
		return minecartTrackLogic0.func_790_c();
	}
}
