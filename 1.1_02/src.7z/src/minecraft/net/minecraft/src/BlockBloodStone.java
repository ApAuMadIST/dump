package net.minecraft.src;

public class BlockBloodStone extends Block {
	public BlockBloodStone(int i1, int i2) {
		super(i1, i2, Material.rock);
	}
}
