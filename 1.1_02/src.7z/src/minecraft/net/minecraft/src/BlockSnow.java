package net.minecraft.src;

import java.util.Random;

public class BlockSnow extends Block {
	protected BlockSnow(int i1, int i2) {
		super(i1, i2, Material.snow);
		this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
		this.setTickOnLoad(true);
	}

	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world1, int i2, int i3, int i4) {
		return null;
	}

	public boolean isOpaqueCube() {
		return false;
	}

	public boolean renderAsNormalBlock() {
		return false;
	}

	public boolean canPlaceBlockAt(World world1, int i2, int i3, int i4) {
		int i5 = world1.getBlockId(i2, i3 - 1, i4);
		return i5 != 0 && Block.blocksList[i5].isOpaqueCube() ? world1.getBlockMaterial(i2, i3 - 1, i4).getIsSolid() : false;
	}

	public void onNeighborBlockChange(World world1, int i2, int i3, int i4, int i5) {
		this.func_314_h(world1, i2, i3, i4);
	}

	private boolean func_314_h(World world1, int i2, int i3, int i4) {
		if(!this.canPlaceBlockAt(world1, i2, i3, i4)) {
			this.dropBlockAsItem(world1, i2, i3, i4, world1.getBlockMetadata(i2, i3, i4));
			world1.setBlockWithNotify(i2, i3, i4, 0);
			return false;
		} else {
			return true;
		}
	}

	public void harvestBlock(World world1, int i2, int i3, int i4, int i5) {
		int i6 = Item.snowball.shiftedIndex;
		float f7 = 0.7F;
		double d8 = (double)(world1.rand.nextFloat() * f7) + (double)(1.0F - f7) * 0.5D;
		double d10 = (double)(world1.rand.nextFloat() * f7) + (double)(1.0F - f7) * 0.5D;
		double d12 = (double)(world1.rand.nextFloat() * f7) + (double)(1.0F - f7) * 0.5D;
		EntityItem entityItem14 = new EntityItem(world1, (double)i2 + d8, (double)i3 + d10, (double)i4 + d12, new ItemStack(i6));
		entityItem14.delayBeforeCanPickup = 10;
		world1.entityJoinedWorld(entityItem14);
		world1.setBlockWithNotify(i2, i3, i4, 0);
	}

	public int idDropped(int i1, Random random2) {
		return Item.snowball.shiftedIndex;
	}

	public int quantityDropped(Random random1) {
		return 0;
	}

	public void updateTick(World world1, int i2, int i3, int i4, Random random5) {
		if(world1.getSavedLightValue(EnumSkyBlock.Block, i2, i3, i4) > 11) {
			this.dropBlockAsItem(world1, i2, i3, i4, world1.getBlockMetadata(i2, i3, i4));
			world1.setBlockWithNotify(i2, i3, i4, 0);
		}

	}

	public boolean shouldSideBeRendered(IBlockAccess iBlockAccess1, int i2, int i3, int i4, int i5) {
		Material material6 = iBlockAccess1.getBlockMaterial(i2, i3, i4);
		return i5 == 1 ? true : (material6 == this.blockMaterial ? false : super.shouldSideBeRendered(iBlockAccess1, i2, i3, i4, i5));
	}
}
