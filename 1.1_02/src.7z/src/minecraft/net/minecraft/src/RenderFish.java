package net.minecraft.src;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

public class RenderFish extends Render {
	public void a(EntityFish entityFish1, double d2, double d4, double d6, float f8, float f9) {
		GL11.glPushMatrix();
		GL11.glTranslatef((float)d2, (float)d4, (float)d6);
		GL11.glEnable(GL12.GL_RESCALE_NORMAL);
		GL11.glScalef(0.5F, 0.5F, 0.5F);
		byte b10 = 1;
		byte b11 = 2;
		this.loadTexture("/particles.png");
		Tessellator tessellator12 = Tessellator.instance;
		float f13 = (float)(b10 * 8 + 0) / 128.0F;
		float f14 = (float)(b10 * 8 + 8) / 128.0F;
		float f15 = (float)(b11 * 8 + 0) / 128.0F;
		float f16 = (float)(b11 * 8 + 8) / 128.0F;
		float f17 = 1.0F;
		float f18 = 0.5F;
		float f19 = 0.5F;
		GL11.glRotatef(180.0F - this.renderManager.field_1225_i, 0.0F, 1.0F, 0.0F);
		GL11.glRotatef(-this.renderManager.field_1224_j, 1.0F, 0.0F, 0.0F);
		tessellator12.startDrawingQuads();
		tessellator12.setNormal(0.0F, 1.0F, 0.0F);
		tessellator12.addVertexWithUV((double)(0.0F - f18), (double)(0.0F - f19), 0.0D, (double)f13, (double)f16);
		tessellator12.addVertexWithUV((double)(f17 - f18), (double)(0.0F - f19), 0.0D, (double)f14, (double)f16);
		tessellator12.addVertexWithUV((double)(f17 - f18), (double)(1.0F - f19), 0.0D, (double)f14, (double)f15);
		tessellator12.addVertexWithUV((double)(0.0F - f18), (double)(1.0F - f19), 0.0D, (double)f13, (double)f15);
		tessellator12.draw();
		GL11.glDisable(GL12.GL_RESCALE_NORMAL);
		GL11.glPopMatrix();
		if(entityFish1.field_4097_b != null) {
			float f20 = (entityFish1.field_4097_b.prevRotationYaw + (entityFish1.field_4097_b.rotationYaw - entityFish1.field_4097_b.prevRotationYaw) * f9) * (float)Math.PI / 180.0F;
			float f21 = (entityFish1.field_4097_b.prevRotationPitch + (entityFish1.field_4097_b.rotationPitch - entityFish1.field_4097_b.prevRotationPitch) * f9) * (float)Math.PI / 180.0F;
			double d22 = (double)MathHelper.sin(f20);
			double d24 = (double)MathHelper.cos(f20);
			double d26 = (double)MathHelper.sin(f21);
			double d28 = (double)MathHelper.cos(f21);
			double d30 = entityFish1.field_4097_b.prevPosX + (entityFish1.field_4097_b.posX - entityFish1.field_4097_b.prevPosX) * (double)f9 - d24 * 0.7D - d22 * 0.5D * d28;
			double d32 = entityFish1.field_4097_b.prevPosY + (entityFish1.field_4097_b.posY - entityFish1.field_4097_b.prevPosY) * (double)f9 - d26 * 0.5D;
			double d34 = entityFish1.field_4097_b.prevPosZ + (entityFish1.field_4097_b.posZ - entityFish1.field_4097_b.prevPosZ) * (double)f9 - d22 * 0.7D + d24 * 0.5D * d28;
			if(this.renderManager.options.thirdPersonView) {
				f20 = (entityFish1.field_4097_b.prevRenderYawOffset + (entityFish1.field_4097_b.renderYawOffset - entityFish1.field_4097_b.prevRenderYawOffset) * f9) * (float)Math.PI / 180.0F;
				d22 = (double)MathHelper.sin(f20);
				d24 = (double)MathHelper.cos(f20);
				d30 = entityFish1.field_4097_b.prevPosX + (entityFish1.field_4097_b.posX - entityFish1.field_4097_b.prevPosX) * (double)f9 - d24 * 0.35D - d22 * 0.85D;
				d32 = entityFish1.field_4097_b.prevPosY + (entityFish1.field_4097_b.posY - entityFish1.field_4097_b.prevPosY) * (double)f9 - 0.45D;
				d34 = entityFish1.field_4097_b.prevPosZ + (entityFish1.field_4097_b.posZ - entityFish1.field_4097_b.prevPosZ) * (double)f9 - d22 * 0.35D + d24 * 0.85D;
			}

			double d36 = entityFish1.prevPosX + (entityFish1.posX - entityFish1.prevPosX) * (double)f9;
			double d38 = entityFish1.prevPosY + (entityFish1.posY - entityFish1.prevPosY) * (double)f9 + 0.25D;
			double d40 = entityFish1.prevPosZ + (entityFish1.posZ - entityFish1.prevPosZ) * (double)f9;
			double d42 = (double)((float)(d30 - d36));
			double d44 = (double)((float)(d32 - d38));
			double d46 = (double)((float)(d34 - d40));
			GL11.glDisable(GL11.GL_TEXTURE_2D);
			GL11.glDisable(GL11.GL_LIGHTING);
			tessellator12.startDrawing(3);
			tessellator12.setColorOpaque_I(0);
			byte b48 = 16;

			for(int i49 = 0; i49 <= b48; ++i49) {
				float f50 = (float)i49 / (float)b48;
				tessellator12.addVertex(d2 + d42 * (double)f50, d4 + d44 * (double)(f50 * f50 + f50) * 0.5D + 0.25D, d6 + d46 * (double)f50);
			}

			tessellator12.draw();
			GL11.glEnable(GL11.GL_LIGHTING);
			GL11.glEnable(GL11.GL_TEXTURE_2D);
		}

	}

	public void doRender(Entity entity1, double d2, double d4, double d6, float f8, float f9) {
		this.a((EntityFish)entity1, d2, d4, d6, f8, f9);
	}
}
