package net.minecraft.src;

import org.lwjgl.opengl.GL11;

public class RenderPlayer extends RenderLiving {
	private ModelBiped field_209_f = (ModelBiped)this.e;
	private ModelBiped field_208_g = new ModelBiped(1.0F);
	private ModelBiped field_207_h = new ModelBiped(0.5F);
	private static final String[] armorFilenamePrefix = new String[]{"cloth", "chain", "iron", "diamond", "gold"};

	public RenderPlayer() {
		super(new ModelBiped(0.0F), 0.5F);
	}

	protected boolean a(EntityPlayer entityPlayer1, int i2) {
		ItemStack itemStack3 = entityPlayer1.inventory.armorItemInSlot(3 - i2);
		if(itemStack3 != null) {
			Item item4 = itemStack3.getItem();
			if(item4 instanceof ItemArmor) {
				ItemArmor itemArmor5 = (ItemArmor)item4;
				this.loadTexture("/armor/" + armorFilenamePrefix[itemArmor5.renderIndex] + "_" + (i2 == 2 ? 2 : 1) + ".png");
				ModelBiped modelBiped6 = i2 == 2 ? this.field_207_h : this.field_208_g;
				modelBiped6.bipedHead.field_1403_h = i2 == 0;
				modelBiped6.field_1285_b.field_1403_h = i2 == 0;
				modelBiped6.field_1284_c.field_1403_h = i2 == 1 || i2 == 2;
				modelBiped6.bipedRightArm.field_1403_h = i2 == 1;
				modelBiped6.bipedLeftArm.field_1403_h = i2 == 1;
				modelBiped6.bipedRightLeg.field_1403_h = i2 == 2 || i2 == 3;
				modelBiped6.bipedLeftLeg.field_1403_h = i2 == 2 || i2 == 3;
				this.setRenderPassModel(modelBiped6);
				return true;
			}
		}

		return false;
	}

	public void a(EntityPlayer entityPlayer1, double d2, double d4, double d6, float f8, float f9) {
		ItemStack itemStack10 = entityPlayer1.inventory.getCurrentItem();
		this.field_208_g.field_1278_i = this.field_207_h.field_1278_i = this.field_209_f.field_1278_i = itemStack10 != null;
		this.field_208_g.field_1277_j = this.field_207_h.field_1277_j = this.field_209_f.field_1277_j = entityPlayer1.isSneaking();
		double d11 = d4 - (double)entityPlayer1.yOffset;
		if(entityPlayer1.field_12240_bw) {
			d11 -= 0.125D;
		}

		super.a(entityPlayer1, d2, d11, d6, f8, f9);
		this.field_208_g.field_1277_j = this.field_207_h.field_1277_j = this.field_209_f.field_1277_j = false;
		this.field_208_g.field_1278_i = this.field_207_h.field_1278_i = this.field_209_f.field_1278_i = false;
		float f13 = 1.6F;
		float f14 = 0.016666668F * f13;
		float f15 = entityPlayer1.getDistanceToEntity(this.renderManager.field_1226_h);
		float f16 = entityPlayer1.isSneaking() ? 32.0F : 64.0F;
		if(f15 < f16) {
			f14 = (float)((double)f14 * (Math.sqrt((double)f15) / 2.0D));
			FontRenderer fontRenderer17 = this.getFontRendererFromRenderManager();
			GL11.glPushMatrix();
			GL11.glTranslatef((float)d2 + 0.0F, (float)d4 + 2.3F, (float)d6);
			GL11.glNormal3f(0.0F, 1.0F, 0.0F);
			GL11.glRotatef(-this.renderManager.field_1225_i, 0.0F, 1.0F, 0.0F);
			GL11.glRotatef(this.renderManager.field_1224_j, 1.0F, 0.0F, 0.0F);
			GL11.glScalef(-f14, -f14, f14);
			String string18 = entityPlayer1.field_771_i;
			GL11.glDisable(GL11.GL_LIGHTING);
			Tessellator tessellator19;
			if(!entityPlayer1.isSneaking()) {
				GL11.glDepthMask(false);
				GL11.glDisable(GL11.GL_DEPTH_TEST);
				GL11.glEnable(GL11.GL_BLEND);
				GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
				tessellator19 = Tessellator.instance;
				byte b20 = 0;
				if(entityPlayer1.field_771_i.equals("deadmau5")) {
					b20 = -10;
				}

				GL11.glDisable(GL11.GL_TEXTURE_2D);
				tessellator19.startDrawingQuads();
				int i21 = fontRenderer17.getStringWidth(string18) / 2;
				tessellator19.setColorRGBA_F(0.0F, 0.0F, 0.0F, 0.25F);
				tessellator19.addVertex((double)(-i21 - 1), (double)(-1 + b20), 0.0D);
				tessellator19.addVertex((double)(-i21 - 1), (double)(8 + b20), 0.0D);
				tessellator19.addVertex((double)(i21 + 1), (double)(8 + b20), 0.0D);
				tessellator19.addVertex((double)(i21 + 1), (double)(-1 + b20), 0.0D);
				tessellator19.draw();
				GL11.glEnable(GL11.GL_TEXTURE_2D);
				fontRenderer17.drawString(string18, -fontRenderer17.getStringWidth(string18) / 2, b20, 553648127);
				GL11.glEnable(GL11.GL_DEPTH_TEST);
				GL11.glDepthMask(true);
				fontRenderer17.drawString(string18, -fontRenderer17.getStringWidth(string18) / 2, b20, -1);
				GL11.glEnable(GL11.GL_LIGHTING);
				GL11.glDisable(GL11.GL_BLEND);
				GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
				GL11.glPopMatrix();
			} else {
				GL11.glTranslatef(0.0F, 0.25F / f14, 0.0F);
				GL11.glDepthMask(false);
				GL11.glEnable(GL11.GL_BLEND);
				GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
				tessellator19 = Tessellator.instance;
				GL11.glDisable(GL11.GL_TEXTURE_2D);
				tessellator19.startDrawingQuads();
				int i22 = fontRenderer17.getStringWidth(string18) / 2;
				tessellator19.setColorRGBA_F(0.0F, 0.0F, 0.0F, 0.25F);
				tessellator19.addVertex((double)(-i22 - 1), -1.0D, 0.0D);
				tessellator19.addVertex((double)(-i22 - 1), 8.0D, 0.0D);
				tessellator19.addVertex((double)(i22 + 1), 8.0D, 0.0D);
				tessellator19.addVertex((double)(i22 + 1), -1.0D, 0.0D);
				tessellator19.draw();
				GL11.glEnable(GL11.GL_TEXTURE_2D);
				GL11.glDepthMask(true);
				fontRenderer17.drawString(string18, -fontRenderer17.getStringWidth(string18) / 2, 0, 553648127);
				GL11.glEnable(GL11.GL_LIGHTING);
				GL11.glDisable(GL11.GL_BLEND);
				GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
				GL11.glPopMatrix();
			}
		}

	}

	protected void a(EntityPlayer entityPlayer1, float f2) {
		ItemStack itemStack3 = entityPlayer1.inventory.armorItemInSlot(3);
		if(itemStack3 != null && itemStack3.getItem().shiftedIndex < 256) {
			GL11.glPushMatrix();
			this.field_209_f.bipedHead.func_926_b(0.0625F);
			if(RenderBlocks.func_1219_a(Block.blocksList[itemStack3.itemID].getRenderType())) {
				float f4 = 0.625F;
				GL11.glTranslatef(0.0F, -0.25F, 0.0F);
				GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
				GL11.glScalef(f4, -f4, f4);
			}

			this.renderManager.field_4236_f.renderItem(itemStack3);
			GL11.glPopMatrix();
		}

		float f5;
		if(entityPlayer1.field_771_i.equals("deadmau5") && this.func_140_a(entityPlayer1.field_20047_bv, (String)null)) {
			for(int i19 = 0; i19 < 2; ++i19) {
				f5 = entityPlayer1.prevRotationYaw + (entityPlayer1.rotationYaw - entityPlayer1.prevRotationYaw) * f2 - (entityPlayer1.prevRenderYawOffset + (entityPlayer1.renderYawOffset - entityPlayer1.prevRenderYawOffset) * f2);
				float f6 = entityPlayer1.prevRotationPitch + (entityPlayer1.rotationPitch - entityPlayer1.prevRotationPitch) * f2;
				GL11.glPushMatrix();
				GL11.glRotatef(f5, 0.0F, 1.0F, 0.0F);
				GL11.glRotatef(f6, 1.0F, 0.0F, 0.0F);
				GL11.glTranslatef(0.375F * (float)(i19 * 2 - 1), 0.0F, 0.0F);
				GL11.glTranslatef(0.0F, -0.375F, 0.0F);
				GL11.glRotatef(-f6, 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(-f5, 0.0F, 1.0F, 0.0F);
				float f7 = 1.3333334F;
				GL11.glScalef(f7, f7, f7);
				this.field_209_f.func_20095_a(0.0625F);
				GL11.glPopMatrix();
			}
		}

		if(this.func_140_a(entityPlayer1.field_20067_q, (String)null)) {
			GL11.glPushMatrix();
			GL11.glTranslatef(0.0F, 0.0F, 0.125F);
			double d20 = entityPlayer1.field_20066_r + (entityPlayer1.field_20063_u - entityPlayer1.field_20066_r) * (double)f2 - (entityPlayer1.prevPosX + (entityPlayer1.posX - entityPlayer1.prevPosX) * (double)f2);
			double d22 = entityPlayer1.field_20065_s + (entityPlayer1.field_20062_v - entityPlayer1.field_20065_s) * (double)f2 - (entityPlayer1.prevPosY + (entityPlayer1.posY - entityPlayer1.prevPosY) * (double)f2);
			double d8 = entityPlayer1.field_20064_t + (entityPlayer1.field_20061_w - entityPlayer1.field_20064_t) * (double)f2 - (entityPlayer1.prevPosZ + (entityPlayer1.posZ - entityPlayer1.prevPosZ) * (double)f2);
			float f10 = entityPlayer1.prevRenderYawOffset + (entityPlayer1.renderYawOffset - entityPlayer1.prevRenderYawOffset) * f2;
			double d11 = (double)MathHelper.sin(f10 * (float)Math.PI / 180.0F);
			double d13 = (double)(-MathHelper.cos(f10 * (float)Math.PI / 180.0F));
			float f15 = (float)d22 * 10.0F;
			if(f15 < -6.0F) {
				f15 = -6.0F;
			}

			if(f15 > 32.0F) {
				f15 = 32.0F;
			}

			float f16 = (float)(d20 * d11 + d8 * d13) * 100.0F;
			float f17 = (float)(d20 * d13 - d8 * d11) * 100.0F;
			if(f16 < 0.0F) {
				f16 = 0.0F;
			}

			float f18 = entityPlayer1.field_775_e + (entityPlayer1.field_774_f - entityPlayer1.field_775_e) * f2;
			f15 += MathHelper.sin((entityPlayer1.prevDistanceWalkedModified + (entityPlayer1.distanceWalkedModified - entityPlayer1.prevDistanceWalkedModified) * f2) * 6.0F) * 32.0F * f18;
			GL11.glRotatef(6.0F + f16 / 2.0F + f15, 1.0F, 0.0F, 0.0F);
			GL11.glRotatef(f17 / 2.0F, 0.0F, 0.0F, 1.0F);
			GL11.glRotatef(-f17 / 2.0F, 0.0F, 1.0F, 0.0F);
			GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
			this.field_209_f.func_20096_b(0.0625F);
			GL11.glPopMatrix();
		}

		ItemStack itemStack21 = entityPlayer1.inventory.getCurrentItem();
		if(itemStack21 != null) {
			GL11.glPushMatrix();
			this.field_209_f.bipedRightArm.func_926_b(0.0625F);
			GL11.glTranslatef(-0.0625F, 0.4375F, 0.0625F);
			if(entityPlayer1.fishEntity != null) {
				itemStack21 = new ItemStack(Item.stick.shiftedIndex);
			}

			if(itemStack21.itemID < 256 && RenderBlocks.func_1219_a(Block.blocksList[itemStack21.itemID].getRenderType())) {
				f5 = 0.5F;
				GL11.glTranslatef(0.0F, 0.1875F, -0.3125F);
				f5 *= 0.75F;
				GL11.glRotatef(20.0F, 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
				GL11.glScalef(f5, -f5, f5);
			} else if(Item.itemsList[itemStack21.itemID].isFull3D()) {
				f5 = 0.625F;
				if(Item.itemsList[itemStack21.itemID].shouldRotateAroundWhenRendering()) {
					GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
					GL11.glTranslatef(0.0F, -0.125F, 0.0F);
				}

				GL11.glTranslatef(0.0F, 0.1875F, 0.0F);
				GL11.glScalef(f5, -f5, f5);
				GL11.glRotatef(-100.0F, 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
			} else {
				f5 = 0.375F;
				GL11.glTranslatef(0.25F, 0.1875F, -0.1875F);
				GL11.glScalef(f5, f5, f5);
				GL11.glRotatef(60.0F, 0.0F, 0.0F, 1.0F);
				GL11.glRotatef(-90.0F, 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(20.0F, 0.0F, 0.0F, 1.0F);
			}

			this.renderManager.field_4236_f.renderItem(itemStack21);
			GL11.glPopMatrix();
		}

	}

	protected void b(EntityPlayer entityPlayer1, float f2) {
		float f3 = 0.9375F;
		GL11.glScalef(f3, f3, f3);
	}

	public void drawFirstPersonHand() {
		this.field_209_f.field_1244_k = 0.0F;
		this.field_209_f.setRotationAngles(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0625F);
		this.field_209_f.bipedRightArm.render(0.0625F);
	}

	protected void preRenderCallback(EntityLiving entityLiving1, float f2) {
		this.b((EntityPlayer)entityLiving1, f2);
	}

	protected boolean shouldRenderPass(EntityLiving entityLiving1, int i2) {
		return this.a((EntityPlayer)entityLiving1, i2);
	}

	protected void renderEquippedItems(EntityLiving entityLiving1, float f2) {
		this.a((EntityPlayer)entityLiving1, f2);
	}

	public void a(EntityLiving entityLiving1, double d2, double d4, double d6, float f8, float f9) {
		this.a((EntityPlayer)entityLiving1, d2, d4, d6, f8, f9);
	}

	public void doRender(Entity entity1, double d2, double d4, double d6, float f8, float f9) {
		this.a((EntityPlayer)entity1, d2, d4, d6, f8, f9);
	}
}
