package net.minecraft.src;

public class GuiConnectFailed extends GuiScreen {
	private String errorMessage;
	private String errorDetail;

	public GuiConnectFailed(String string1, String string2, Object... object3) {
		StringTranslate stringTranslate4 = StringTranslate.func_20162_a();
		this.errorMessage = stringTranslate4.func_20163_a(string1);
		if(object3 != null) {
			this.errorDetail = stringTranslate4.func_20160_a(string2, object3);
		} else {
			this.errorDetail = stringTranslate4.func_20163_a(string2);
		}

	}

	public void updateScreen() {
	}

	protected void keyTyped(char c1, int i2) {
	}

	public void initGui() {
		StringTranslate stringTranslate1 = StringTranslate.func_20162_a();
		this.controlList.clear();
		this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 120 + 12, stringTranslate1.func_20163_a("gui.toMenu")));
	}

	protected void actionPerformed(GuiButton guiButton1) {
		if(guiButton1.id == 0) {
			this.mc.displayGuiScreen(new GuiMainMenu());
		}

	}

	public void drawScreen(int i1, int i2, float f3) {
		this.drawDefaultBackground();
		this.drawCenteredString(this.fontRenderer, this.errorMessage, this.width / 2, this.height / 2 - 50, 0xFFFFFF);
		this.drawCenteredString(this.fontRenderer, this.errorDetail, this.width / 2, this.height / 2 - 10, 0xFFFFFF);
		super.drawScreen(i1, i2, f3);
	}
}
