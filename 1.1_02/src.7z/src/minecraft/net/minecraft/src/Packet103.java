package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet103 extends Packet {
	public int field_20042_a;
	public int field_20041_b;
	public ItemStack field_20043_c;

	public void processPacket(NetHandler netHandler1) {
		netHandler1.func_20088_a(this);
	}

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.field_20042_a = dataInputStream1.readByte();
		this.field_20041_b = dataInputStream1.readShort();
		short s2 = dataInputStream1.readShort();
		if(s2 >= 0) {
			byte b3 = dataInputStream1.readByte();
			byte b4 = dataInputStream1.readByte();
			this.field_20043_c = new ItemStack(s2, b3, b4);
		} else {
			this.field_20043_c = null;
		}

	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeByte(this.field_20042_a);
		dataOutputStream1.writeShort(this.field_20041_b);
		if(this.field_20043_c == null) {
			dataOutputStream1.writeShort(-1);
		} else {
			dataOutputStream1.writeShort(this.field_20043_c.itemID);
			dataOutputStream1.writeByte(this.field_20043_c.stackSize);
			dataOutputStream1.writeByte(this.field_20043_c.itemDamage);
		}

	}

	public int getPacketSize() {
		return 7;
	}
}
