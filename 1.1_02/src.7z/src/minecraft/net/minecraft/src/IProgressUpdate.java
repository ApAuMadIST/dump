package net.minecraft.src;

public interface IProgressUpdate {
	void func_594_b(String string1);

	void displayLoadingString(String string1);

	void setLoadingProgress(int i1);
}
