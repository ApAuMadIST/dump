package net.minecraft.src;

import java.io.File;

import net.minecraft.client.Minecraft;

public class GuiSelectWorld extends GuiScreen {
	protected GuiScreen parentScreen;
	protected String screenTitle = "Select world";
	private boolean selected = false;

	public GuiSelectWorld(GuiScreen guiScreen1) {
		this.parentScreen = guiScreen1;
	}

	public void initGui() {
		StringTranslate stringTranslate1 = StringTranslate.func_20162_a();
		this.screenTitle = stringTranslate1.func_20163_a("selectWorld.title");
		String string2 = stringTranslate1.func_20163_a("selectWorld.empty");
		String string3 = stringTranslate1.func_20163_a("selectWorld.world");
		File file4 = Minecraft.getMinecraftDir();

		for(int i5 = 0; i5 < 5; ++i5) {
			NBTTagCompound nBTTagCompound6 = World.func_629_a(file4, "World" + (i5 + 1));
			if(nBTTagCompound6 == null) {
				this.controlList.add(new GuiButton(i5, this.width / 2 - 100, this.height / 6 + 24 * i5, "- " + string2 + " -"));
			} else {
				String string7 = string3 + " " + (i5 + 1);
				long j8 = nBTTagCompound6.getLong("SizeOnDisk");
				string7 = string7 + " (" + (float)(j8 / 1024L * 100L / 1024L) / 100.0F + " MB)";
				this.controlList.add(new GuiButton(i5, this.width / 2 - 100, this.height / 6 + 24 * i5, string7));
			}
		}

		this.initGui2();
	}

	protected String getWorldName(int i1) {
		File file2 = Minecraft.getMinecraftDir();
		return World.func_629_a(file2, "World" + i1) != null ? "World" + i1 : null;
	}

	public void initGui2() {
		StringTranslate stringTranslate1 = StringTranslate.func_20162_a();
		this.controlList.add(new GuiButton(5, this.width / 2 - 100, this.height / 6 + 120 + 12, stringTranslate1.func_20163_a("selectWorld.delete")));
		this.controlList.add(new GuiButton(6, this.width / 2 - 100, this.height / 6 + 168, stringTranslate1.func_20163_a("gui.cancel")));
	}

	protected void actionPerformed(GuiButton guiButton1) {
		if(guiButton1.enabled) {
			if(guiButton1.id < 5) {
				this.selectWorld(guiButton1.id + 1);
			} else if(guiButton1.id == 5) {
				this.mc.displayGuiScreen(new GuiDeleteWorld(this));
			} else if(guiButton1.id == 6) {
				this.mc.displayGuiScreen(this.parentScreen);
			}

		}
	}

	public void selectWorld(int i1) {
		this.mc.displayGuiScreen((GuiScreen)null);
		if(!this.selected) {
			this.selected = true;
			this.mc.playerController = new PlayerControllerSP(this.mc);
			this.mc.func_6247_b("World" + i1);
			this.mc.displayGuiScreen((GuiScreen)null);
		}
	}

	public void drawScreen(int i1, int i2, float f3) {
		this.drawDefaultBackground();
		this.drawCenteredString(this.fontRenderer, this.screenTitle, this.width / 2, 20, 0xFFFFFF);
		super.drawScreen(i1, i2, f3);
	}
}
