package net.minecraft.src;

import java.util.Comparator;

public class RenderSorter implements Comparator {
	private EntityPlayer field_4274_a;

	public RenderSorter(EntityPlayer entityPlayer1) {
		this.field_4274_a = entityPlayer1;
	}

	public int a(WorldRenderer worldRenderer1, WorldRenderer worldRenderer2) {
		boolean z3 = worldRenderer1.isInFrustrum;
		boolean z4 = worldRenderer2.isInFrustrum;
		if(z3 && !z4) {
			return 1;
		} else if(z4 && !z3) {
			return -1;
		} else {
			double d5 = (double)worldRenderer1.distanceToEntity(this.field_4274_a);
			double d7 = (double)worldRenderer2.distanceToEntity(this.field_4274_a);
			return d5 < d7 ? 1 : (d5 > d7 ? -1 : (worldRenderer1.field_1735_w < worldRenderer2.field_1735_w ? 1 : -1));
		}
	}

	public int compare(Object object1, Object object2) {
		return this.a((WorldRenderer)object1, (WorldRenderer)object2);
	}
}
