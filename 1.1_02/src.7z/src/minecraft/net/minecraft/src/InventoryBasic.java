package net.minecraft.src;

import java.util.List;

public class InventoryBasic implements IInventory {
	private String field_20072_a;
	private int field_20071_b;
	private ItemStack[] field_20074_c;
	private List field_20073_d;

	public InventoryBasic(String string1, int i2) {
		this.field_20072_a = string1;
		this.field_20071_b = i2;
		this.field_20074_c = new ItemStack[i2];
	}

	public ItemStack getStackInSlot(int i1) {
		return this.field_20074_c[i1];
	}

	public ItemStack decrStackSize(int i1, int i2) {
		if(this.field_20074_c[i1] != null) {
			ItemStack itemStack3;
			if(this.field_20074_c[i1].stackSize <= i2) {
				itemStack3 = this.field_20074_c[i1];
				this.field_20074_c[i1] = null;
				this.onInventoryChanged();
				return itemStack3;
			} else {
				itemStack3 = this.field_20074_c[i1].splitStack(i2);
				if(this.field_20074_c[i1].stackSize == 0) {
					this.field_20074_c[i1] = null;
				}

				this.onInventoryChanged();
				return itemStack3;
			}
		} else {
			return null;
		}
	}

	public void setInventorySlotContents(int i1, ItemStack itemStack2) {
		this.field_20074_c[i1] = itemStack2;
		if(itemStack2 != null && itemStack2.stackSize > this.getInventoryStackLimit()) {
			itemStack2.stackSize = this.getInventoryStackLimit();
		}

		this.onInventoryChanged();
	}

	public int getSizeInventory() {
		return this.field_20071_b;
	}

	public String getInvName() {
		return this.field_20072_a;
	}

	public int getInventoryStackLimit() {
		return 64;
	}

	public void onInventoryChanged() {
		if(this.field_20073_d != null) {
			for(int i1 = 0; i1 < this.field_20073_d.size(); ++i1) {
				((IInvBasic)this.field_20073_d.get(i1)).func_20134_a(this);
			}
		}

	}

	public boolean func_20070_a_(EntityPlayer entityPlayer1) {
		return true;
	}
}
