package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class World implements IBlockAccess {
	public boolean field_4214_a;
	private List field_1051_z;
	public List loadedEntityList;
	private List field_1024_A;
	private TreeSet scheduledTickTreeSet;
	private Set scheduledTickSet;
	public List loadedTileEntityList;
	public List playerEntities;
	public long worldTime;
	private long field_1019_F;
	public int skylightSubtracted;
	protected int field_9437_g;
	protected int field_9436_h;
	public boolean field_1043_h;
	private long field_1054_E;
	protected int autosavePeriod;
	public int difficultySetting;
	public Random rand;
	public int spawnX;
	public int spawnY;
	public int spawnZ;
	public boolean field_1033_r;
	public final WorldProvider worldProvider;
	protected List worldAccesses;
	private IChunkProvider chunkProvider;
	public File field_9433_s;
	public File field_9432_t;
	public long randomSeed;
	private NBTTagCompound nbtCompoundPlayer;
	public long sizeOnDisk;
	public final String field_9431_w;
	public boolean field_9430_x;
	private ArrayList field_9428_I;
	private int field_4204_J;
	static int field_9429_y = 0;
	private Set field_9427_K;
	private int field_9426_L;
	private List field_1012_M;
	public boolean multiplayerWorld;

	public static NBTTagCompound func_629_a(File file0, String string1) {
		File file2 = new File(file0, "saves");
		File file3 = new File(file2, string1);
		if(!file3.exists()) {
			return null;
		} else {
			File file4 = new File(file3, "level.dat");
			if(file4.exists()) {
				try {
					NBTTagCompound nBTTagCompound5 = CompressedStreamTools.func_1138_a(new FileInputStream(file4));
					NBTTagCompound nBTTagCompound6 = nBTTagCompound5.getCompoundTag("Data");
					return nBTTagCompound6;
				} catch (Exception exception7) {
					exception7.printStackTrace();
				}
			}

			return null;
		}
	}

	public static void deleteWorld(File file0, String string1) {
		File file2 = new File(file0, "saves");
		File file3 = new File(file2, string1);
		if(file3.exists()) {
			deleteFiles(file3.listFiles());
			file3.delete();
		}
	}

	private static void deleteFiles(File[] file0) {
		for(int i1 = 0; i1 < file0.length; ++i1) {
			if(file0[i1].isDirectory()) {
				deleteFiles(file0[i1].listFiles());
			}

			file0[i1].delete();
		}

	}

	public WorldChunkManager func_4075_a() {
		return this.worldProvider.worldChunkMgr;
	}

	public World(File file1, String string2) {
		this(file1, string2, (new Random()).nextLong());
	}

	public World(String string1, WorldProvider worldProvider2, long j3) {
		this.field_4214_a = false;
		this.field_1051_z = new ArrayList();
		this.loadedEntityList = new ArrayList();
		this.field_1024_A = new ArrayList();
		this.scheduledTickTreeSet = new TreeSet();
		this.scheduledTickSet = new HashSet();
		this.loadedTileEntityList = new ArrayList();
		this.playerEntities = new ArrayList();
		this.worldTime = 0L;
		this.field_1019_F = 16777215L;
		this.skylightSubtracted = 0;
		this.field_9437_g = (new Random()).nextInt();
		this.field_9436_h = 1013904223;
		this.field_1043_h = false;
		this.field_1054_E = System.currentTimeMillis();
		this.autosavePeriod = 40;
		this.rand = new Random();
		this.field_1033_r = false;
		this.worldAccesses = new ArrayList();
		this.randomSeed = 0L;
		this.sizeOnDisk = 0L;
		this.field_9428_I = new ArrayList();
		this.field_4204_J = 0;
		this.field_9427_K = new HashSet();
		this.field_9426_L = this.rand.nextInt(12000);
		this.field_1012_M = new ArrayList();
		this.multiplayerWorld = false;
		this.field_9431_w = string1;
		this.randomSeed = j3;
		this.worldProvider = worldProvider2;
		worldProvider2.registerWorld(this);
		this.chunkProvider = this.func_4081_a(this.field_9432_t);
		this.calculateInitialSkylight();
	}

	public World(World world1, WorldProvider worldProvider2) {
		this.field_4214_a = false;
		this.field_1051_z = new ArrayList();
		this.loadedEntityList = new ArrayList();
		this.field_1024_A = new ArrayList();
		this.scheduledTickTreeSet = new TreeSet();
		this.scheduledTickSet = new HashSet();
		this.loadedTileEntityList = new ArrayList();
		this.playerEntities = new ArrayList();
		this.worldTime = 0L;
		this.field_1019_F = 16777215L;
		this.skylightSubtracted = 0;
		this.field_9437_g = (new Random()).nextInt();
		this.field_9436_h = 1013904223;
		this.field_1043_h = false;
		this.field_1054_E = System.currentTimeMillis();
		this.autosavePeriod = 40;
		this.rand = new Random();
		this.field_1033_r = false;
		this.worldAccesses = new ArrayList();
		this.randomSeed = 0L;
		this.sizeOnDisk = 0L;
		this.field_9428_I = new ArrayList();
		this.field_4204_J = 0;
		this.field_9427_K = new HashSet();
		this.field_9426_L = this.rand.nextInt(12000);
		this.field_1012_M = new ArrayList();
		this.multiplayerWorld = false;
		this.field_1054_E = world1.field_1054_E;
		this.field_9433_s = world1.field_9433_s;
		this.field_9432_t = world1.field_9432_t;
		this.field_9431_w = world1.field_9431_w;
		this.randomSeed = world1.randomSeed;
		this.worldTime = world1.worldTime;
		this.spawnX = world1.spawnX;
		this.spawnY = world1.spawnY;
		this.spawnZ = world1.spawnZ;
		this.sizeOnDisk = world1.sizeOnDisk;
		this.worldProvider = worldProvider2;
		worldProvider2.registerWorld(this);
		this.chunkProvider = this.func_4081_a(this.field_9432_t);
		this.calculateInitialSkylight();
	}

	public World(File file1, String string2, long j3) {
		this(file1, string2, j3, (WorldProvider)null);
	}

	public World(File file1, String string2, long j3, WorldProvider worldProvider5) {
		this.field_4214_a = false;
		this.field_1051_z = new ArrayList();
		this.loadedEntityList = new ArrayList();
		this.field_1024_A = new ArrayList();
		this.scheduledTickTreeSet = new TreeSet();
		this.scheduledTickSet = new HashSet();
		this.loadedTileEntityList = new ArrayList();
		this.playerEntities = new ArrayList();
		this.worldTime = 0L;
		this.field_1019_F = 16777215L;
		this.skylightSubtracted = 0;
		this.field_9437_g = (new Random()).nextInt();
		this.field_9436_h = 1013904223;
		this.field_1043_h = false;
		this.field_1054_E = System.currentTimeMillis();
		this.autosavePeriod = 40;
		this.rand = new Random();
		this.field_1033_r = false;
		this.worldAccesses = new ArrayList();
		this.randomSeed = 0L;
		this.sizeOnDisk = 0L;
		this.field_9428_I = new ArrayList();
		this.field_4204_J = 0;
		this.field_9427_K = new HashSet();
		this.field_9426_L = this.rand.nextInt(12000);
		this.field_1012_M = new ArrayList();
		this.multiplayerWorld = false;
		this.field_9433_s = file1;
		this.field_9431_w = string2;
		file1.mkdirs();
		this.field_9432_t = new File(file1, string2);
		this.field_9432_t.mkdirs();

		try {
			File file6 = new File(this.field_9432_t, "session.lock");
			DataOutputStream dataOutputStream7 = new DataOutputStream(new FileOutputStream(file6));

			try {
				dataOutputStream7.writeLong(this.field_1054_E);
			} finally {
				dataOutputStream7.close();
			}
		} catch (IOException iOException16) {
			iOException16.printStackTrace();
			throw new RuntimeException("Failed to check session lock, aborting");
		}

		Object object17 = new WorldProvider();
		File file18 = new File(this.field_9432_t, "level.dat");
		this.field_1033_r = !file18.exists();
		if(file18.exists()) {
			try {
				NBTTagCompound nBTTagCompound8 = CompressedStreamTools.func_1138_a(new FileInputStream(file18));
				NBTTagCompound nBTTagCompound9 = nBTTagCompound8.getCompoundTag("Data");
				this.randomSeed = nBTTagCompound9.getLong("RandomSeed");
				this.spawnX = nBTTagCompound9.getInteger("SpawnX");
				this.spawnY = nBTTagCompound9.getInteger("SpawnY");
				this.spawnZ = nBTTagCompound9.getInteger("SpawnZ");
				this.worldTime = nBTTagCompound9.getLong("Time");
				this.sizeOnDisk = nBTTagCompound9.getLong("SizeOnDisk");
				if(nBTTagCompound9.hasKey("Player")) {
					this.nbtCompoundPlayer = nBTTagCompound9.getCompoundTag("Player");
					int i10 = this.nbtCompoundPlayer.getInteger("Dimension");
					if(i10 == -1) {
						object17 = new WorldProviderHell();
					}
				}
			} catch (Exception exception14) {
				exception14.printStackTrace();
			}
		}

		if(worldProvider5 != null) {
			object17 = worldProvider5;
		}

		boolean z19 = false;
		if(this.randomSeed == 0L) {
			this.randomSeed = j3;
			z19 = true;
		}

		this.worldProvider = (WorldProvider)object17;
		this.worldProvider.registerWorld(this);
		this.chunkProvider = this.func_4081_a(this.field_9432_t);
		if(z19) {
			this.field_9430_x = true;
			this.spawnX = 0;
			this.spawnY = 64;

			for(this.spawnZ = 0; !this.worldProvider.canCoordinateBeSpawn(this.spawnX, this.spawnZ); this.spawnZ += this.rand.nextInt(64) - this.rand.nextInt(64)) {
				this.spawnX += this.rand.nextInt(64) - this.rand.nextInt(64);
			}

			this.field_9430_x = false;
		}

		this.calculateInitialSkylight();
	}

	protected IChunkProvider func_4081_a(File file1) {
		return new ChunkProviderLoadOrGenerate(this, this.worldProvider.getChunkLoader(file1), this.worldProvider.getChunkProvider());
	}

	public void func_4076_b() {
		if(this.spawnY <= 0) {
			this.spawnY = 64;
		}

		while(this.func_614_g(this.spawnX, this.spawnZ) == 0) {
			this.spawnX += this.rand.nextInt(8) - this.rand.nextInt(8);
			this.spawnZ += this.rand.nextInt(8) - this.rand.nextInt(8);
		}

	}

	public int func_614_g(int i1, int i2) {
		int i3;
		for(i3 = 63; !this.func_20084_d(i1, i3 + 1, i2); ++i3) {
		}

		return this.getBlockId(i1, i3, i2);
	}

	public void func_6464_c() {
	}

	public void func_608_a(EntityPlayer entityPlayer1) {
		try {
			if(this.nbtCompoundPlayer != null) {
				entityPlayer1.readFromNBT(this.nbtCompoundPlayer);
				this.nbtCompoundPlayer = null;
			}

			this.entityJoinedWorld(entityPlayer1);
		} catch (Exception exception3) {
			exception3.printStackTrace();
		}

	}

	public void saveWorld(boolean z1, IProgressUpdate iProgressUpdate2) {
		if(this.chunkProvider.func_536_b()) {
			if(iProgressUpdate2 != null) {
				iProgressUpdate2.func_594_b("Saving level");
			}

			this.saveLevel();
			if(iProgressUpdate2 != null) {
				iProgressUpdate2.displayLoadingString("Saving chunks");
			}

			this.chunkProvider.saveChunks(z1, iProgressUpdate2);
		}
	}

	private void saveLevel() {
		this.func_663_l();
		NBTTagCompound nBTTagCompound1 = new NBTTagCompound();
		nBTTagCompound1.setLong("RandomSeed", this.randomSeed);
		nBTTagCompound1.setInteger("SpawnX", this.spawnX);
		nBTTagCompound1.setInteger("SpawnY", this.spawnY);
		nBTTagCompound1.setInteger("SpawnZ", this.spawnZ);
		nBTTagCompound1.setLong("Time", this.worldTime);
		nBTTagCompound1.setLong("SizeOnDisk", this.sizeOnDisk);
		nBTTagCompound1.setLong("LastPlayed", System.currentTimeMillis());
		EntityPlayer entityPlayer2 = null;
		if(this.playerEntities.size() > 0) {
			entityPlayer2 = (EntityPlayer)this.playerEntities.get(0);
		}

		NBTTagCompound nBTTagCompound3;
		if(entityPlayer2 != null) {
			nBTTagCompound3 = new NBTTagCompound();
			entityPlayer2.writeToNBT(nBTTagCompound3);
			nBTTagCompound1.setCompoundTag("Player", nBTTagCompound3);
		}

		nBTTagCompound3 = new NBTTagCompound();
		nBTTagCompound3.setTag("Data", nBTTagCompound1);

		try {
			File file4 = new File(this.field_9432_t, "level.dat_new");
			File file5 = new File(this.field_9432_t, "level.dat_old");
			File file6 = new File(this.field_9432_t, "level.dat");
			CompressedStreamTools.writeGzippedCompoundToOutputStream(nBTTagCompound3, new FileOutputStream(file4));
			if(file5.exists()) {
				file5.delete();
			}

			file6.renameTo(file5);
			if(file6.exists()) {
				file6.delete();
			}

			file4.renameTo(file6);
			if(file4.exists()) {
				file4.delete();
			}
		} catch (Exception exception7) {
			exception7.printStackTrace();
		}

	}

	public boolean func_650_a(int i1) {
		if(!this.chunkProvider.func_536_b()) {
			return true;
		} else {
			if(i1 == 0) {
				this.saveLevel();
			}

			return this.chunkProvider.saveChunks(false, (IProgressUpdate)null);
		}
	}

	public int getBlockId(int i1, int i2, int i3) {
		return i1 >= -32000000 && i3 >= -32000000 && i1 < 32000000 && i3 <= 32000000 ? (i2 < 0 ? 0 : (i2 >= 128 ? 0 : this.getChunkFromChunkCoords(i1 >> 4, i3 >> 4).getBlockID(i1 & 15, i2, i3 & 15))) : 0;
	}

	public boolean func_20084_d(int i1, int i2, int i3) {
		return this.getBlockId(i1, i2, i3) == 0;
	}

	public boolean blockExists(int i1, int i2, int i3) {
		return i2 >= 0 && i2 < 128 ? this.chunkExists(i1 >> 4, i3 >> 4) : false;
	}

	public boolean checkChunksExist(int i1, int i2, int i3, int i4, int i5, int i6) {
		if(i5 >= 0 && i2 < 128) {
			i1 >>= 4;
			i2 >>= 4;
			i3 >>= 4;
			i4 >>= 4;
			i5 >>= 4;
			i6 >>= 4;

			for(int i7 = i1; i7 <= i4; ++i7) {
				for(int i8 = i3; i8 <= i6; ++i8) {
					if(!this.chunkExists(i7, i8)) {
						return false;
					}
				}
			}

			return true;
		} else {
			return false;
		}
	}

	private boolean chunkExists(int i1, int i2) {
		return this.chunkProvider.chunkExists(i1, i2);
	}

	public Chunk getChunkFromBlockCoords(int i1, int i2) {
		return this.getChunkFromChunkCoords(i1 >> 4, i2 >> 4);
	}

	public Chunk getChunkFromChunkCoords(int i1, int i2) {
		return this.chunkProvider.provideChunk(i1, i2);
	}

	public boolean setBlockAndMetadata(int i1, int i2, int i3, int i4, int i5) {
		if(i1 >= -32000000 && i3 >= -32000000 && i1 < 32000000 && i3 <= 32000000) {
			if(i2 < 0) {
				return false;
			} else if(i2 >= 128) {
				return false;
			} else {
				Chunk chunk6 = this.getChunkFromChunkCoords(i1 >> 4, i3 >> 4);
				return chunk6.setBlockIDWithMetadata(i1 & 15, i2, i3 & 15, i4, i5);
			}
		} else {
			return false;
		}
	}

	public boolean setBlock(int i1, int i2, int i3, int i4) {
		if(i1 >= -32000000 && i3 >= -32000000 && i1 < 32000000 && i3 <= 32000000) {
			if(i2 < 0) {
				return false;
			} else if(i2 >= 128) {
				return false;
			} else {
				Chunk chunk5 = this.getChunkFromChunkCoords(i1 >> 4, i3 >> 4);
				return chunk5.setBlockID(i1 & 15, i2, i3 & 15, i4);
			}
		} else {
			return false;
		}
	}

	public Material getBlockMaterial(int i1, int i2, int i3) {
		int i4 = this.getBlockId(i1, i2, i3);
		return i4 == 0 ? Material.air : Block.blocksList[i4].blockMaterial;
	}

	public int getBlockMetadata(int i1, int i2, int i3) {
		if(i1 >= -32000000 && i3 >= -32000000 && i1 < 32000000 && i3 <= 32000000) {
			if(i2 < 0) {
				return 0;
			} else if(i2 >= 128) {
				return 0;
			} else {
				Chunk chunk4 = this.getChunkFromChunkCoords(i1 >> 4, i3 >> 4);
				i1 &= 15;
				i3 &= 15;
				return chunk4.getBlockMetadata(i1, i2, i3);
			}
		} else {
			return 0;
		}
	}

	public void setBlockMetadataWithNotify(int i1, int i2, int i3, int i4) {
		if(this.setBlockMetadata(i1, i2, i3, i4)) {
			this.notifyBlockChange(i1, i2, i3, this.getBlockId(i1, i2, i3));
		}

	}

	public boolean setBlockMetadata(int i1, int i2, int i3, int i4) {
		if(i1 >= -32000000 && i3 >= -32000000 && i1 < 32000000 && i3 <= 32000000) {
			if(i2 < 0) {
				return false;
			} else if(i2 >= 128) {
				return false;
			} else {
				Chunk chunk5 = this.getChunkFromChunkCoords(i1 >> 4, i3 >> 4);
				i1 &= 15;
				i3 &= 15;
				chunk5.setBlockMetadata(i1, i2, i3, i4);
				return true;
			}
		} else {
			return false;
		}
	}

	public boolean setBlockWithNotify(int i1, int i2, int i3, int i4) {
		if(this.setBlock(i1, i2, i3, i4)) {
			this.notifyBlockChange(i1, i2, i3, i4);
			return true;
		} else {
			return false;
		}
	}

	public boolean setBlockAndMetadataWithNotify(int i1, int i2, int i3, int i4, int i5) {
		if(this.setBlockAndMetadata(i1, i2, i3, i4, i5)) {
			this.notifyBlockChange(i1, i2, i3, i4);
			return true;
		} else {
			return false;
		}
	}

	public void markBlockNeedsUpdate(int i1, int i2, int i3) {
		for(int i4 = 0; i4 < this.worldAccesses.size(); ++i4) {
			((IWorldAccess)this.worldAccesses.get(i4)).func_934_a(i1, i2, i3);
		}

	}

	protected void notifyBlockChange(int i1, int i2, int i3, int i4) {
		this.markBlockNeedsUpdate(i1, i2, i3);
		this.notifyBlocksOfNeighborChange(i1, i2, i3, i4);
	}

	public void func_680_f(int i1, int i2, int i3, int i4) {
		if(i3 > i4) {
			int i5 = i4;
			i4 = i3;
			i3 = i5;
		}

		this.func_701_b(i1, i3, i2, i1, i4, i2);
	}

	public void func_701_b(int i1, int i2, int i3, int i4, int i5, int i6) {
		for(int i7 = 0; i7 < this.worldAccesses.size(); ++i7) {
			((IWorldAccess)this.worldAccesses.get(i7)).markBlockRangeNeedsUpdate(i1, i2, i3, i4, i5, i6);
		}

	}

	public void notifyBlocksOfNeighborChange(int i1, int i2, int i3, int i4) {
		this.notifyBlockOfNeighborChange(i1 - 1, i2, i3, i4);
		this.notifyBlockOfNeighborChange(i1 + 1, i2, i3, i4);
		this.notifyBlockOfNeighborChange(i1, i2 - 1, i3, i4);
		this.notifyBlockOfNeighborChange(i1, i2 + 1, i3, i4);
		this.notifyBlockOfNeighborChange(i1, i2, i3 - 1, i4);
		this.notifyBlockOfNeighborChange(i1, i2, i3 + 1, i4);
	}

	private void notifyBlockOfNeighborChange(int i1, int i2, int i3, int i4) {
		if(!this.field_1043_h && !this.multiplayerWorld) {
			Block block5 = Block.blocksList[this.getBlockId(i1, i2, i3)];
			if(block5 != null) {
				block5.onNeighborBlockChange(this, i1, i2, i3, i4);
			}

		}
	}

	public boolean canBlockSeeTheSky(int i1, int i2, int i3) {
		return this.getChunkFromChunkCoords(i1 >> 4, i3 >> 4).canBlockSeeTheSky(i1 & 15, i2, i3 & 15);
	}

	public int getBlockLightValue(int i1, int i2, int i3) {
		return this.getBlockLightValue_do(i1, i2, i3, true);
	}

	public int getBlockLightValue_do(int i1, int i2, int i3, boolean z4) {
		if(i1 >= -32000000 && i3 >= -32000000 && i1 < 32000000 && i3 <= 32000000) {
			int i5;
			if(z4) {
				i5 = this.getBlockId(i1, i2, i3);
				if(i5 == Block.stairSingle.blockID || i5 == Block.tilledField.blockID) {
					int i6 = this.getBlockLightValue_do(i1, i2 + 1, i3, false);
					int i7 = this.getBlockLightValue_do(i1 + 1, i2, i3, false);
					int i8 = this.getBlockLightValue_do(i1 - 1, i2, i3, false);
					int i9 = this.getBlockLightValue_do(i1, i2, i3 + 1, false);
					int i10 = this.getBlockLightValue_do(i1, i2, i3 - 1, false);
					if(i7 > i6) {
						i6 = i7;
					}

					if(i8 > i6) {
						i6 = i8;
					}

					if(i9 > i6) {
						i6 = i9;
					}

					if(i10 > i6) {
						i6 = i10;
					}

					return i6;
				}
			}

			if(i2 < 0) {
				return 0;
			} else if(i2 >= 128) {
				i5 = 15 - this.skylightSubtracted;
				if(i5 < 0) {
					i5 = 0;
				}

				return i5;
			} else {
				Chunk chunk11 = this.getChunkFromChunkCoords(i1 >> 4, i3 >> 4);
				i1 &= 15;
				i3 &= 15;
				return chunk11.getBlockLightValue(i1, i2, i3, this.skylightSubtracted);
			}
		} else {
			return 15;
		}
	}

	public boolean canExistingBlockSeeTheSky(int i1, int i2, int i3) {
		if(i1 >= -32000000 && i3 >= -32000000 && i1 < 32000000 && i3 <= 32000000) {
			if(i2 < 0) {
				return false;
			} else if(i2 >= 128) {
				return true;
			} else if(!this.chunkExists(i1 >> 4, i3 >> 4)) {
				return false;
			} else {
				Chunk chunk4 = this.getChunkFromChunkCoords(i1 >> 4, i3 >> 4);
				i1 &= 15;
				i3 &= 15;
				return chunk4.canBlockSeeTheSky(i1, i2, i3);
			}
		} else {
			return false;
		}
	}

	public int getHeightValue(int i1, int i2) {
		if(i1 >= -32000000 && i2 >= -32000000 && i1 < 32000000 && i2 <= 32000000) {
			if(!this.chunkExists(i1 >> 4, i2 >> 4)) {
				return 0;
			} else {
				Chunk chunk3 = this.getChunkFromChunkCoords(i1 >> 4, i2 >> 4);
				return chunk3.getHeightValue(i1 & 15, i2 & 15);
			}
		} else {
			return 0;
		}
	}

	public void neighborLightPropagationChanged(EnumSkyBlock enumSkyBlock1, int i2, int i3, int i4, int i5) {
		if(!this.worldProvider.field_6478_e || enumSkyBlock1 != EnumSkyBlock.Sky) {
			if(this.blockExists(i2, i3, i4)) {
				if(enumSkyBlock1 == EnumSkyBlock.Sky) {
					if(this.canExistingBlockSeeTheSky(i2, i3, i4)) {
						i5 = 15;
					}
				} else if(enumSkyBlock1 == EnumSkyBlock.Block) {
					int i6 = this.getBlockId(i2, i3, i4);
					if(Block.lightValue[i6] > i5) {
						i5 = Block.lightValue[i6];
					}
				}

				if(this.getSavedLightValue(enumSkyBlock1, i2, i3, i4) != i5) {
					this.func_616_a(enumSkyBlock1, i2, i3, i4, i2, i3, i4);
				}

			}
		}
	}

	public int getSavedLightValue(EnumSkyBlock enumSkyBlock1, int i2, int i3, int i4) {
		if(i3 >= 0 && i3 < 128 && i2 >= -32000000 && i4 >= -32000000 && i2 < 32000000 && i4 <= 32000000) {
			int i5 = i2 >> 4;
			int i6 = i4 >> 4;
			if(!this.chunkExists(i5, i6)) {
				return 0;
			} else {
				Chunk chunk7 = this.getChunkFromChunkCoords(i5, i6);
				return chunk7.getSavedLightValue(enumSkyBlock1, i2 & 15, i3, i4 & 15);
			}
		} else {
			return enumSkyBlock1.field_1722_c;
		}
	}

	public void setLightValue(EnumSkyBlock enumSkyBlock1, int i2, int i3, int i4, int i5) {
		if(i2 >= -32000000 && i4 >= -32000000 && i2 < 32000000 && i4 <= 32000000) {
			if(i3 >= 0) {
				if(i3 < 128) {
					if(this.chunkExists(i2 >> 4, i4 >> 4)) {
						Chunk chunk6 = this.getChunkFromChunkCoords(i2 >> 4, i4 >> 4);
						chunk6.setLightValue(enumSkyBlock1, i2 & 15, i3, i4 & 15, i5);

						for(int i7 = 0; i7 < this.worldAccesses.size(); ++i7) {
							((IWorldAccess)this.worldAccesses.get(i7)).func_934_a(i2, i3, i4);
						}

					}
				}
			}
		}
	}

	public float getLightBrightness(int i1, int i2, int i3) {
		return this.worldProvider.lightBrightnessTable[this.getBlockLightValue(i1, i2, i3)];
	}

	public boolean isDaytime() {
		return this.skylightSubtracted < 4;
	}

	public MovingObjectPosition rayTraceBlocks(Vec3D vec3D1, Vec3D vec3D2) {
		return this.rayTraceBlocks_do(vec3D1, vec3D2, false);
	}

	public MovingObjectPosition rayTraceBlocks_do(Vec3D vec3D1, Vec3D vec3D2, boolean z3) {
		if(!Double.isNaN(vec3D1.xCoord) && !Double.isNaN(vec3D1.yCoord) && !Double.isNaN(vec3D1.zCoord)) {
			if(!Double.isNaN(vec3D2.xCoord) && !Double.isNaN(vec3D2.yCoord) && !Double.isNaN(vec3D2.zCoord)) {
				int i4 = MathHelper.floor_double(vec3D2.xCoord);
				int i5 = MathHelper.floor_double(vec3D2.yCoord);
				int i6 = MathHelper.floor_double(vec3D2.zCoord);
				int i7 = MathHelper.floor_double(vec3D1.xCoord);
				int i8 = MathHelper.floor_double(vec3D1.yCoord);
				int i9 = MathHelper.floor_double(vec3D1.zCoord);
				int i10 = 200;

				while(i10-- >= 0) {
					if(Double.isNaN(vec3D1.xCoord) || Double.isNaN(vec3D1.yCoord) || Double.isNaN(vec3D1.zCoord)) {
						return null;
					}

					if(i7 == i4 && i8 == i5 && i9 == i6) {
						return null;
					}

					double d11 = 999.0D;
					double d13 = 999.0D;
					double d15 = 999.0D;
					if(i4 > i7) {
						d11 = (double)i7 + 1.0D;
					}

					if(i4 < i7) {
						d11 = (double)i7 + 0.0D;
					}

					if(i5 > i8) {
						d13 = (double)i8 + 1.0D;
					}

					if(i5 < i8) {
						d13 = (double)i8 + 0.0D;
					}

					if(i6 > i9) {
						d15 = (double)i9 + 1.0D;
					}

					if(i6 < i9) {
						d15 = (double)i9 + 0.0D;
					}

					double d17 = 999.0D;
					double d19 = 999.0D;
					double d21 = 999.0D;
					double d23 = vec3D2.xCoord - vec3D1.xCoord;
					double d25 = vec3D2.yCoord - vec3D1.yCoord;
					double d27 = vec3D2.zCoord - vec3D1.zCoord;
					if(d11 != 999.0D) {
						d17 = (d11 - vec3D1.xCoord) / d23;
					}

					if(d13 != 999.0D) {
						d19 = (d13 - vec3D1.yCoord) / d25;
					}

					if(d15 != 999.0D) {
						d21 = (d15 - vec3D1.zCoord) / d27;
					}

					boolean z29 = false;
					byte b35;
					if(d17 < d19 && d17 < d21) {
						if(i4 > i7) {
							b35 = 4;
						} else {
							b35 = 5;
						}

						vec3D1.xCoord = d11;
						vec3D1.yCoord += d25 * d17;
						vec3D1.zCoord += d27 * d17;
					} else if(d19 < d21) {
						if(i5 > i8) {
							b35 = 0;
						} else {
							b35 = 1;
						}

						vec3D1.xCoord += d23 * d19;
						vec3D1.yCoord = d13;
						vec3D1.zCoord += d27 * d19;
					} else {
						if(i6 > i9) {
							b35 = 2;
						} else {
							b35 = 3;
						}

						vec3D1.xCoord += d23 * d21;
						vec3D1.yCoord += d25 * d21;
						vec3D1.zCoord = d15;
					}

					Vec3D vec3D30 = Vec3D.createVector(vec3D1.xCoord, vec3D1.yCoord, vec3D1.zCoord);
					i7 = (int)(vec3D30.xCoord = (double)MathHelper.floor_double(vec3D1.xCoord));
					if(b35 == 5) {
						--i7;
						++vec3D30.xCoord;
					}

					i8 = (int)(vec3D30.yCoord = (double)MathHelper.floor_double(vec3D1.yCoord));
					if(b35 == 1) {
						--i8;
						++vec3D30.yCoord;
					}

					i9 = (int)(vec3D30.zCoord = (double)MathHelper.floor_double(vec3D1.zCoord));
					if(b35 == 3) {
						--i9;
						++vec3D30.zCoord;
					}

					int i31 = this.getBlockId(i7, i8, i9);
					int i32 = this.getBlockMetadata(i7, i8, i9);
					Block block33 = Block.blocksList[i31];
					if(i31 > 0 && block33.canCollideCheck(i32, z3)) {
						MovingObjectPosition movingObjectPosition34 = block33.collisionRayTrace(this, i7, i8, i9, vec3D1, vec3D2);
						if(movingObjectPosition34 != null) {
							return movingObjectPosition34;
						}
					}
				}

				return null;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public void playSoundAtEntity(Entity entity1, String string2, float f3, float f4) {
		for(int i5 = 0; i5 < this.worldAccesses.size(); ++i5) {
			((IWorldAccess)this.worldAccesses.get(i5)).playSound(string2, entity1.posX, entity1.posY - (double)entity1.yOffset, entity1.posZ, f3, f4);
		}

	}

	public void playSoundEffect(double d1, double d3, double d5, String string7, float f8, float f9) {
		for(int i10 = 0; i10 < this.worldAccesses.size(); ++i10) {
			((IWorldAccess)this.worldAccesses.get(i10)).playSound(string7, d1, d3, d5, f8, f9);
		}

	}

	public void playRecord(String string1, int i2, int i3, int i4) {
		for(int i5 = 0; i5 < this.worldAccesses.size(); ++i5) {
			((IWorldAccess)this.worldAccesses.get(i5)).playRecord(string1, i2, i3, i4);
		}

	}

	public void spawnParticle(String string1, double d2, double d4, double d6, double d8, double d10, double d12) {
		for(int i14 = 0; i14 < this.worldAccesses.size(); ++i14) {
			((IWorldAccess)this.worldAccesses.get(i14)).spawnParticle(string1, d2, d4, d6, d8, d10, d12);
		}

	}

	public boolean entityJoinedWorld(Entity entity1) {
		int i2 = MathHelper.floor_double(entity1.posX / 16.0D);
		int i3 = MathHelper.floor_double(entity1.posZ / 16.0D);
		boolean z4 = false;
		if(entity1 instanceof EntityPlayer) {
			z4 = true;
		}

		if(!z4 && !this.chunkExists(i2, i3)) {
			return false;
		} else {
			if(entity1 instanceof EntityPlayer) {
				this.playerEntities.add((EntityPlayer)entity1);
				System.out.println("Player count: " + this.playerEntities.size());
			}

			this.getChunkFromChunkCoords(i2, i3).addEntity(entity1);
			this.loadedEntityList.add(entity1);
			this.obtainEntitySkin(entity1);
			return true;
		}
	}

	protected void obtainEntitySkin(Entity entity1) {
		for(int i2 = 0; i2 < this.worldAccesses.size(); ++i2) {
			((IWorldAccess)this.worldAccesses.get(i2)).obtainEntitySkin(entity1);
		}

	}

	protected void releaseEntitySkin(Entity entity1) {
		for(int i2 = 0; i2 < this.worldAccesses.size(); ++i2) {
			((IWorldAccess)this.worldAccesses.get(i2)).releaseEntitySkin(entity1);
		}

	}

	public void setEntityDead(Entity entity1) {
		entity1.setEntityDead();
		if(entity1 instanceof EntityPlayer) {
			this.playerEntities.remove((EntityPlayer)entity1);
		}

	}

	public void addWorldAccess(IWorldAccess iWorldAccess1) {
		this.worldAccesses.add(iWorldAccess1);
	}

	public void removeWorldAccess(IWorldAccess iWorldAccess1) {
		this.worldAccesses.remove(iWorldAccess1);
	}

	public List getCollidingBoundingBoxes(Entity entity1, AxisAlignedBB axisAlignedBB2) {
		this.field_9428_I.clear();
		int i3 = MathHelper.floor_double(axisAlignedBB2.minX);
		int i4 = MathHelper.floor_double(axisAlignedBB2.maxX + 1.0D);
		int i5 = MathHelper.floor_double(axisAlignedBB2.minY);
		int i6 = MathHelper.floor_double(axisAlignedBB2.maxY + 1.0D);
		int i7 = MathHelper.floor_double(axisAlignedBB2.minZ);
		int i8 = MathHelper.floor_double(axisAlignedBB2.maxZ + 1.0D);

		for(int i9 = i3; i9 < i4; ++i9) {
			for(int i10 = i7; i10 < i8; ++i10) {
				if(this.blockExists(i9, 64, i10)) {
					for(int i11 = i5 - 1; i11 < i6; ++i11) {
						Block block12 = Block.blocksList[this.getBlockId(i9, i11, i10)];
						if(block12 != null) {
							block12.getCollidingBoundingBoxes(this, i9, i11, i10, axisAlignedBB2, this.field_9428_I);
						}
					}
				}
			}
		}

		double d14 = 0.25D;
		List list15 = this.getEntitiesWithinAABBExcludingEntity(entity1, axisAlignedBB2.expand(d14, d14, d14));

		for(int i16 = 0; i16 < list15.size(); ++i16) {
			AxisAlignedBB axisAlignedBB13 = ((Entity)list15.get(i16)).func_372_f_();
			if(axisAlignedBB13 != null && axisAlignedBB13.intersectsWith(axisAlignedBB2)) {
				this.field_9428_I.add(axisAlignedBB13);
			}

			axisAlignedBB13 = entity1.func_383_b_((Entity)list15.get(i16));
			if(axisAlignedBB13 != null && axisAlignedBB13.intersectsWith(axisAlignedBB2)) {
				this.field_9428_I.add(axisAlignedBB13);
			}
		}

		return this.field_9428_I;
	}

	public int calculateSkylightSubtracted(float f1) {
		float f2 = this.getCelestialAngle(f1);
		float f3 = 1.0F - (MathHelper.cos(f2 * (float)Math.PI * 2.0F) * 2.0F + 0.5F);
		if(f3 < 0.0F) {
			f3 = 0.0F;
		}

		if(f3 > 1.0F) {
			f3 = 1.0F;
		}

		return (int)(f3 * 11.0F);
	}

	public Vec3D func_4079_a(Entity entity1, float f2) {
		float f3 = this.getCelestialAngle(f2);
		float f4 = MathHelper.cos(f3 * (float)Math.PI * 2.0F) * 2.0F + 0.5F;
		if(f4 < 0.0F) {
			f4 = 0.0F;
		}

		if(f4 > 1.0F) {
			f4 = 1.0F;
		}

		int i5 = MathHelper.floor_double(entity1.posX);
		int i6 = MathHelper.floor_double(entity1.posZ);
		float f7 = (float)this.func_4075_a().func_4072_b(i5, i6);
		int i8 = this.func_4075_a().func_4073_a(i5, i6).getSkyColorByTemp(f7);
		float f9 = (float)(i8 >> 16 & 255) / 255.0F;
		float f10 = (float)(i8 >> 8 & 255) / 255.0F;
		float f11 = (float)(i8 & 255) / 255.0F;
		f9 *= f4;
		f10 *= f4;
		f11 *= f4;
		return Vec3D.createVector((double)f9, (double)f10, (double)f11);
	}

	public float getCelestialAngle(float f1) {
		return this.worldProvider.calculateCelestialAngle(this.worldTime, f1);
	}

	public Vec3D func_628_d(float f1) {
		float f2 = this.getCelestialAngle(f1);
		float f3 = MathHelper.cos(f2 * (float)Math.PI * 2.0F) * 2.0F + 0.5F;
		if(f3 < 0.0F) {
			f3 = 0.0F;
		}

		if(f3 > 1.0F) {
			f3 = 1.0F;
		}

		float f4 = (float)(this.field_1019_F >> 16 & 255L) / 255.0F;
		float f5 = (float)(this.field_1019_F >> 8 & 255L) / 255.0F;
		float f6 = (float)(this.field_1019_F & 255L) / 255.0F;
		f4 *= f3 * 0.9F + 0.1F;
		f5 *= f3 * 0.9F + 0.1F;
		f6 *= f3 * 0.85F + 0.15F;
		return Vec3D.createVector((double)f4, (double)f5, (double)f6);
	}

	public Vec3D func_4082_d(float f1) {
		float f2 = this.getCelestialAngle(f1);
		return this.worldProvider.func_4096_a(f2, f1);
	}

	public int findTopSolidBlock(int i1, int i2) {
		Chunk chunk3 = this.getChunkFromBlockCoords(i1, i2);

		int i4;
		for(i4 = 127; this.getBlockMaterial(i1, i4, i2).getIsSolid() && i4 > 0; --i4) {
		}

		i1 &= 15;

		for(i2 &= 15; i4 > 0; --i4) {
			int i5 = chunk3.getBlockID(i1, i4, i2);
			if(i5 != 0 && (Block.blocksList[i5].blockMaterial.getIsSolid() || Block.blocksList[i5].blockMaterial.getIsLiquid())) {
				return i4 + 1;
			}
		}

		return -1;
	}

	public int func_696_e(int i1, int i2) {
		return this.getChunkFromBlockCoords(i1, i2).getHeightValue(i1 & 15, i2 & 15);
	}

	public float func_679_f(float f1) {
		float f2 = this.getCelestialAngle(f1);
		float f3 = 1.0F - (MathHelper.cos(f2 * (float)Math.PI * 2.0F) * 2.0F + 0.75F);
		if(f3 < 0.0F) {
			f3 = 0.0F;
		}

		if(f3 > 1.0F) {
			f3 = 1.0F;
		}

		return f3 * f3 * 0.5F;
	}

	public void scheduleBlockUpdate(int i1, int i2, int i3, int i4) {
		NextTickListEntry nextTickListEntry5 = new NextTickListEntry(i1, i2, i3, i4);
		byte b6 = 8;
		if(this.field_4214_a) {
			if(this.checkChunksExist(nextTickListEntry5.xCoord - b6, nextTickListEntry5.yCoord - b6, nextTickListEntry5.zCoord - b6, nextTickListEntry5.xCoord + b6, nextTickListEntry5.yCoord + b6, nextTickListEntry5.zCoord + b6)) {
				int i7 = this.getBlockId(nextTickListEntry5.xCoord, nextTickListEntry5.yCoord, nextTickListEntry5.zCoord);
				if(i7 == nextTickListEntry5.blockID && i7 > 0) {
					Block.blocksList[i7].updateTick(this, nextTickListEntry5.xCoord, nextTickListEntry5.yCoord, nextTickListEntry5.zCoord, this.rand);
				}
			}

		} else {
			if(this.checkChunksExist(i1 - b6, i2 - b6, i3 - b6, i1 + b6, i2 + b6, i3 + b6)) {
				if(i4 > 0) {
					nextTickListEntry5.setScheduledTime((long)Block.blocksList[i4].tickRate() + this.worldTime);
				}

				if(!this.scheduledTickSet.contains(nextTickListEntry5)) {
					this.scheduledTickSet.add(nextTickListEntry5);
					this.scheduledTickTreeSet.add(nextTickListEntry5);
				}
			}

		}
	}

	public void func_633_c() {
		this.loadedEntityList.removeAll(this.field_1024_A);

		int i1;
		Entity entity2;
		int i3;
		int i4;
		for(i1 = 0; i1 < this.field_1024_A.size(); ++i1) {
			entity2 = (Entity)this.field_1024_A.get(i1);
			i3 = entity2.chunkCoordX;
			i4 = entity2.chunkCoordZ;
			if(entity2.addedToChunk && this.chunkExists(i3, i4)) {
				this.getChunkFromChunkCoords(i3, i4).func_1015_b(entity2);
			}
		}

		for(i1 = 0; i1 < this.field_1024_A.size(); ++i1) {
			this.releaseEntitySkin((Entity)this.field_1024_A.get(i1));
		}

		this.field_1024_A.clear();

		for(i1 = 0; i1 < this.loadedEntityList.size(); ++i1) {
			entity2 = (Entity)this.loadedEntityList.get(i1);
			if(entity2.ridingEntity != null) {
				if(!entity2.ridingEntity.isDead && entity2.ridingEntity.riddenByEntity == entity2) {
					continue;
				}

				entity2.ridingEntity.riddenByEntity = null;
				entity2.ridingEntity = null;
			}

			if(!entity2.isDead) {
				this.updateEntity(entity2);
			}

			if(entity2.isDead) {
				i3 = entity2.chunkCoordX;
				i4 = entity2.chunkCoordZ;
				if(entity2.addedToChunk && this.chunkExists(i3, i4)) {
					this.getChunkFromChunkCoords(i3, i4).func_1015_b(entity2);
				}

				this.loadedEntityList.remove(i1--);
				this.releaseEntitySkin(entity2);
			}
		}

		for(i1 = 0; i1 < this.loadedTileEntityList.size(); ++i1) {
			TileEntity tileEntity5 = (TileEntity)this.loadedTileEntityList.get(i1);
			tileEntity5.updateEntity();
		}

	}

	public void updateEntity(Entity entity1) {
		this.updateEntityWithOptionalForce(entity1, true);
	}

	public void updateEntityWithOptionalForce(Entity entity1, boolean z2) {
		int i3 = MathHelper.floor_double(entity1.posX);
		int i4 = MathHelper.floor_double(entity1.posZ);
		byte b5 = 16;
		if(z2 || this.checkChunksExist(i3 - b5, 0, i4 - b5, i3 + b5, 128, i4 + b5)) {
			entity1.lastTickPosX = entity1.posX;
			entity1.lastTickPosY = entity1.posY;
			entity1.lastTickPosZ = entity1.posZ;
			entity1.prevRotationYaw = entity1.rotationYaw;
			entity1.prevRotationPitch = entity1.rotationPitch;
			if(z2 && entity1.addedToChunk) {
				if(entity1.ridingEntity != null) {
					entity1.func_350_p();
				} else {
					entity1.onUpdate();
				}
			}

			if(Double.isNaN(entity1.posX) || Double.isInfinite(entity1.posX)) {
				entity1.posX = entity1.lastTickPosX;
			}

			if(Double.isNaN(entity1.posY) || Double.isInfinite(entity1.posY)) {
				entity1.posY = entity1.lastTickPosY;
			}

			if(Double.isNaN(entity1.posZ) || Double.isInfinite(entity1.posZ)) {
				entity1.posZ = entity1.lastTickPosZ;
			}

			if(Double.isNaN((double)entity1.rotationPitch) || Double.isInfinite((double)entity1.rotationPitch)) {
				entity1.rotationPitch = entity1.prevRotationPitch;
			}

			if(Double.isNaN((double)entity1.rotationYaw) || Double.isInfinite((double)entity1.rotationYaw)) {
				entity1.rotationYaw = entity1.prevRotationYaw;
			}

			int i6 = MathHelper.floor_double(entity1.posX / 16.0D);
			int i7 = MathHelper.floor_double(entity1.posY / 16.0D);
			int i8 = MathHelper.floor_double(entity1.posZ / 16.0D);
			if(!entity1.addedToChunk || entity1.chunkCoordX != i6 || entity1.chunkCoordY != i7 || entity1.chunkCoordZ != i8) {
				if(entity1.addedToChunk && this.chunkExists(entity1.chunkCoordX, entity1.chunkCoordZ)) {
					this.getChunkFromChunkCoords(entity1.chunkCoordX, entity1.chunkCoordZ).func_1016_a(entity1, entity1.chunkCoordY);
				}

				if(this.chunkExists(i6, i8)) {
					entity1.addedToChunk = true;
					this.getChunkFromChunkCoords(i6, i8).addEntity(entity1);
				} else {
					entity1.addedToChunk = false;
				}
			}

			if(z2 && entity1.addedToChunk && entity1.riddenByEntity != null) {
				if(!entity1.riddenByEntity.isDead && entity1.riddenByEntity.ridingEntity == entity1) {
					this.updateEntity(entity1.riddenByEntity);
				} else {
					entity1.riddenByEntity.ridingEntity = null;
					entity1.riddenByEntity = null;
				}
			}

		}
	}

	public boolean checkIfAABBIsClear(AxisAlignedBB axisAlignedBB1) {
		List list2 = this.getEntitiesWithinAABBExcludingEntity((Entity)null, axisAlignedBB1);

		for(int i3 = 0; i3 < list2.size(); ++i3) {
			Entity entity4 = (Entity)list2.get(i3);
			if(!entity4.isDead && entity4.preventEntitySpawning) {
				return false;
			}
		}

		return true;
	}

	public boolean getIsAnyLiquid(AxisAlignedBB axisAlignedBB1) {
		int i2 = MathHelper.floor_double(axisAlignedBB1.minX);
		int i3 = MathHelper.floor_double(axisAlignedBB1.maxX + 1.0D);
		int i4 = MathHelper.floor_double(axisAlignedBB1.minY);
		int i5 = MathHelper.floor_double(axisAlignedBB1.maxY + 1.0D);
		int i6 = MathHelper.floor_double(axisAlignedBB1.minZ);
		int i7 = MathHelper.floor_double(axisAlignedBB1.maxZ + 1.0D);
		if(axisAlignedBB1.minX < 0.0D) {
			--i2;
		}

		if(axisAlignedBB1.minY < 0.0D) {
			--i4;
		}

		if(axisAlignedBB1.minZ < 0.0D) {
			--i6;
		}

		for(int i8 = i2; i8 < i3; ++i8) {
			for(int i9 = i4; i9 < i5; ++i9) {
				for(int i10 = i6; i10 < i7; ++i10) {
					Block block11 = Block.blocksList[this.getBlockId(i8, i9, i10)];
					if(block11 != null && block11.blockMaterial.getIsLiquid()) {
						return true;
					}
				}
			}
		}

		return false;
	}

	public boolean isBoundingBoxBurning(AxisAlignedBB axisAlignedBB1) {
		int i2 = MathHelper.floor_double(axisAlignedBB1.minX);
		int i3 = MathHelper.floor_double(axisAlignedBB1.maxX + 1.0D);
		int i4 = MathHelper.floor_double(axisAlignedBB1.minY);
		int i5 = MathHelper.floor_double(axisAlignedBB1.maxY + 1.0D);
		int i6 = MathHelper.floor_double(axisAlignedBB1.minZ);
		int i7 = MathHelper.floor_double(axisAlignedBB1.maxZ + 1.0D);

		for(int i8 = i2; i8 < i3; ++i8) {
			for(int i9 = i4; i9 < i5; ++i9) {
				for(int i10 = i6; i10 < i7; ++i10) {
					int i11 = this.getBlockId(i8, i9, i10);
					if(i11 == Block.fire.blockID || i11 == Block.lavaStill.blockID || i11 == Block.lavaMoving.blockID) {
						return true;
					}
				}
			}
		}

		return false;
	}

	public boolean func_682_a(AxisAlignedBB axisAlignedBB1, Material material2, Entity entity3) {
		int i4 = MathHelper.floor_double(axisAlignedBB1.minX);
		int i5 = MathHelper.floor_double(axisAlignedBB1.maxX + 1.0D);
		int i6 = MathHelper.floor_double(axisAlignedBB1.minY);
		int i7 = MathHelper.floor_double(axisAlignedBB1.maxY + 1.0D);
		int i8 = MathHelper.floor_double(axisAlignedBB1.minZ);
		int i9 = MathHelper.floor_double(axisAlignedBB1.maxZ + 1.0D);
		boolean z10 = false;
		Vec3D vec3D11 = Vec3D.createVector(0.0D, 0.0D, 0.0D);

		for(int i12 = i4; i12 < i5; ++i12) {
			for(int i13 = i6; i13 < i7; ++i13) {
				for(int i14 = i8; i14 < i9; ++i14) {
					Block block15 = Block.blocksList[this.getBlockId(i12, i13, i14)];
					if(block15 != null && block15.blockMaterial == material2) {
						double d16 = (double)((float)(i13 + 1) - BlockFluids.setFluidHeight(this.getBlockMetadata(i12, i13, i14)));
						if((double)i7 >= d16) {
							z10 = true;
							block15.velocityToAddToEntity(this, i12, i13, i14, entity3, vec3D11);
						}
					}
				}
			}
		}

		if(vec3D11.lengthVector() > 0.0D) {
			vec3D11 = vec3D11.normalize();
			double d18 = 0.004D;
			entity3.motionX += vec3D11.xCoord * d18;
			entity3.motionY += vec3D11.yCoord * d18;
			entity3.motionZ += vec3D11.zCoord * d18;
		}

		return z10;
	}

	public boolean isMaterialInBB(AxisAlignedBB axisAlignedBB1, Material material2) {
		int i3 = MathHelper.floor_double(axisAlignedBB1.minX);
		int i4 = MathHelper.floor_double(axisAlignedBB1.maxX + 1.0D);
		int i5 = MathHelper.floor_double(axisAlignedBB1.minY);
		int i6 = MathHelper.floor_double(axisAlignedBB1.maxY + 1.0D);
		int i7 = MathHelper.floor_double(axisAlignedBB1.minZ);
		int i8 = MathHelper.floor_double(axisAlignedBB1.maxZ + 1.0D);

		for(int i9 = i3; i9 < i4; ++i9) {
			for(int i10 = i5; i10 < i6; ++i10) {
				for(int i11 = i7; i11 < i8; ++i11) {
					Block block12 = Block.blocksList[this.getBlockId(i9, i10, i11)];
					if(block12 != null && block12.blockMaterial == material2) {
						return true;
					}
				}
			}
		}

		return false;
	}

	public boolean func_707_b(AxisAlignedBB axisAlignedBB1, Material material2) {
		int i3 = MathHelper.floor_double(axisAlignedBB1.minX);
		int i4 = MathHelper.floor_double(axisAlignedBB1.maxX + 1.0D);
		int i5 = MathHelper.floor_double(axisAlignedBB1.minY);
		int i6 = MathHelper.floor_double(axisAlignedBB1.maxY + 1.0D);
		int i7 = MathHelper.floor_double(axisAlignedBB1.minZ);
		int i8 = MathHelper.floor_double(axisAlignedBB1.maxZ + 1.0D);

		for(int i9 = i3; i9 < i4; ++i9) {
			for(int i10 = i5; i10 < i6; ++i10) {
				for(int i11 = i7; i11 < i8; ++i11) {
					Block block12 = Block.blocksList[this.getBlockId(i9, i10, i11)];
					if(block12 != null && block12.blockMaterial == material2) {
						int i13 = this.getBlockMetadata(i9, i10, i11);
						double d14 = (double)(i10 + 1);
						if(i13 < 8) {
							d14 = (double)(i10 + 1) - (double)i13 / 8.0D;
						}

						if(d14 >= axisAlignedBB1.minY) {
							return true;
						}
					}
				}
			}
		}

		return false;
	}

	public Explosion createExplosion(Entity entity1, double d2, double d4, double d6, float f8) {
		return this.func_12244_a(entity1, d2, d4, d6, f8, false);
	}

	public Explosion func_12244_a(Entity entity1, double d2, double d4, double d6, float f8, boolean z9) {
		Explosion explosion10 = new Explosion(this, entity1, d2, d4, d6, f8);
		explosion10.field_12257_a = z9;
		explosion10.func_12248_a();
		explosion10.func_12247_b();
		return explosion10;
	}

	public float func_675_a(Vec3D vec3D1, AxisAlignedBB axisAlignedBB2) {
		double d3 = 1.0D / ((axisAlignedBB2.maxX - axisAlignedBB2.minX) * 2.0D + 1.0D);
		double d5 = 1.0D / ((axisAlignedBB2.maxY - axisAlignedBB2.minY) * 2.0D + 1.0D);
		double d7 = 1.0D / ((axisAlignedBB2.maxZ - axisAlignedBB2.minZ) * 2.0D + 1.0D);
		int i9 = 0;
		int i10 = 0;

		for(float f11 = 0.0F; f11 <= 1.0F; f11 = (float)((double)f11 + d3)) {
			for(float f12 = 0.0F; f12 <= 1.0F; f12 = (float)((double)f12 + d5)) {
				for(float f13 = 0.0F; f13 <= 1.0F; f13 = (float)((double)f13 + d7)) {
					double d14 = axisAlignedBB2.minX + (axisAlignedBB2.maxX - axisAlignedBB2.minX) * (double)f11;
					double d16 = axisAlignedBB2.minY + (axisAlignedBB2.maxY - axisAlignedBB2.minY) * (double)f12;
					double d18 = axisAlignedBB2.minZ + (axisAlignedBB2.maxZ - axisAlignedBB2.minZ) * (double)f13;
					if(this.rayTraceBlocks(Vec3D.createVector(d14, d16, d18), vec3D1) == null) {
						++i9;
					}

					++i10;
				}
			}
		}

		return (float)i9 / (float)i10;
	}

	public void onBlockHit(int i1, int i2, int i3, int i4) {
		if(i4 == 0) {
			--i2;
		}

		if(i4 == 1) {
			++i2;
		}

		if(i4 == 2) {
			--i3;
		}

		if(i4 == 3) {
			++i3;
		}

		if(i4 == 4) {
			--i1;
		}

		if(i4 == 5) {
			++i1;
		}

		if(this.getBlockId(i1, i2, i3) == Block.fire.blockID) {
			this.playSoundEffect((double)((float)i1 + 0.5F), (double)((float)i2 + 0.5F), (double)((float)i3 + 0.5F), "random.fizz", 0.5F, 2.6F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.8F);
			this.setBlockWithNotify(i1, i2, i3, 0);
		}

	}

	public Entity func_4085_a(Class class1) {
		return null;
	}

	public String func_687_d() {
		return "All: " + this.loadedEntityList.size();
	}

	public TileEntity getBlockTileEntity(int i1, int i2, int i3) {
		Chunk chunk4 = this.getChunkFromChunkCoords(i1 >> 4, i3 >> 4);
		return chunk4 != null ? chunk4.getChunkBlockTileEntity(i1 & 15, i2, i3 & 15) : null;
	}

	public void setBlockTileEntity(int i1, int i2, int i3, TileEntity tileEntity4) {
		Chunk chunk5 = this.getChunkFromChunkCoords(i1 >> 4, i3 >> 4);
		if(chunk5 != null) {
			chunk5.setChunkBlockTileEntity(i1 & 15, i2, i3 & 15, tileEntity4);
		}

	}

	public void removeBlockTileEntity(int i1, int i2, int i3) {
		Chunk chunk4 = this.getChunkFromChunkCoords(i1 >> 4, i3 >> 4);
		if(chunk4 != null) {
			chunk4.removeChunkBlockTileEntity(i1 & 15, i2, i3 & 15);
		}

	}

	public boolean isBlockOpaqueCube(int i1, int i2, int i3) {
		Block block4 = Block.blocksList[this.getBlockId(i1, i2, i3)];
		return block4 == null ? false : block4.isOpaqueCube();
	}

	public void func_651_a(IProgressUpdate iProgressUpdate1) {
		this.saveWorld(true, iProgressUpdate1);
	}

	public boolean func_6465_g() {
		if(this.field_4204_J >= 50) {
			return false;
		} else {
			++this.field_4204_J;

			try {
				int i1 = 5000;

				boolean z2;
				while(this.field_1051_z.size() > 0) {
					--i1;
					if(i1 <= 0) {
						z2 = true;
						return z2;
					}

					((MetadataChunkBlock)this.field_1051_z.remove(this.field_1051_z.size() - 1)).func_4127_a(this);
				}

				z2 = false;
				return z2;
			} finally {
				--this.field_4204_J;
			}
		}
	}

	public void func_616_a(EnumSkyBlock enumSkyBlock1, int i2, int i3, int i4, int i5, int i6, int i7) {
		this.func_627_a(enumSkyBlock1, i2, i3, i4, i5, i6, i7, true);
	}

	public void func_627_a(EnumSkyBlock enumSkyBlock1, int i2, int i3, int i4, int i5, int i6, int i7, boolean z8) {
		if(!this.worldProvider.field_6478_e || enumSkyBlock1 != EnumSkyBlock.Sky) {
			++field_9429_y;
			if(field_9429_y == 50) {
				--field_9429_y;
			} else {
				int i9 = (i5 + i2) / 2;
				int i10 = (i7 + i4) / 2;
				if(!this.blockExists(i9, 64, i10)) {
					--field_9429_y;
				} else {
					int i11 = this.field_1051_z.size();
					if(z8) {
						int i12 = 4;
						if(i12 > i11) {
							i12 = i11;
						}

						for(int i13 = 0; i13 < i12; ++i13) {
							MetadataChunkBlock metadataChunkBlock14 = (MetadataChunkBlock)this.field_1051_z.get(this.field_1051_z.size() - i13 - 1);
							if(metadataChunkBlock14.field_1299_a == enumSkyBlock1 && metadataChunkBlock14.func_866_a(i2, i3, i4, i5, i6, i7)) {
								--field_9429_y;
								return;
							}
						}
					}

					this.field_1051_z.add(new MetadataChunkBlock(enumSkyBlock1, i2, i3, i4, i5, i6, i7));
					if(this.field_1051_z.size() > 100000) {
						this.field_1051_z.clear();
					}

					--field_9429_y;
				}
			}
		}
	}

	public void calculateInitialSkylight() {
		int i1 = this.calculateSkylightSubtracted(1.0F);
		if(i1 != this.skylightSubtracted) {
			this.skylightSubtracted = i1;
		}

	}

	public void tick() {
		SpawnerAnimals.performSpawning(this);
		this.chunkProvider.func_532_a();
		int i1 = this.calculateSkylightSubtracted(1.0F);
		if(i1 != this.skylightSubtracted) {
			this.skylightSubtracted = i1;

			for(int i2 = 0; i2 < this.worldAccesses.size(); ++i2) {
				((IWorldAccess)this.worldAccesses.get(i2)).updateAllRenderers();
			}
		}

		++this.worldTime;
		if(this.worldTime % (long)this.autosavePeriod == 0L) {
			this.saveWorld(false, (IProgressUpdate)null);
		}

		this.TickUpdates(false);
		this.func_4080_j();
	}

	protected void func_4080_j() {
		this.field_9427_K.clear();

		int i3;
		int i4;
		int i6;
		int i7;
		for(int i1 = 0; i1 < this.playerEntities.size(); ++i1) {
			EntityPlayer entityPlayer2 = (EntityPlayer)this.playerEntities.get(i1);
			i3 = MathHelper.floor_double(entityPlayer2.posX / 16.0D);
			i4 = MathHelper.floor_double(entityPlayer2.posZ / 16.0D);
			byte b5 = 9;

			for(i6 = -b5; i6 <= b5; ++i6) {
				for(i7 = -b5; i7 <= b5; ++i7) {
					this.field_9427_K.add(new ChunkCoordIntPair(i6 + i3, i7 + i4));
				}
			}
		}

		if(this.field_9426_L > 0) {
			--this.field_9426_L;
		}

		Iterator iterator12 = this.field_9427_K.iterator();

		while(iterator12.hasNext()) {
			ChunkCoordIntPair chunkCoordIntPair13 = (ChunkCoordIntPair)iterator12.next();
			i3 = chunkCoordIntPair13.chunkXPos * 16;
			i4 = chunkCoordIntPair13.chunkZPos * 16;
			Chunk chunk14 = this.getChunkFromChunkCoords(chunkCoordIntPair13.chunkXPos, chunkCoordIntPair13.chunkZPos);
			int i8;
			int i9;
			int i10;
			if(this.field_9426_L == 0) {
				this.field_9437_g = this.field_9437_g * 3 + this.field_9436_h;
				i6 = this.field_9437_g >> 2;
				i7 = i6 & 15;
				i8 = i6 >> 8 & 15;
				i9 = i6 >> 16 & 127;
				i10 = chunk14.getBlockID(i7, i9, i8);
				i7 += i3;
				i8 += i4;
				if(i10 == 0 && this.getBlockLightValue(i7, i9, i8) <= this.rand.nextInt(8) && this.getSavedLightValue(EnumSkyBlock.Sky, i7, i9, i8) <= 0) {
					EntityPlayer entityPlayer11 = this.getClosestPlayer((double)i7 + 0.5D, (double)i9 + 0.5D, (double)i8 + 0.5D, 8.0D);
					if(entityPlayer11 != null && entityPlayer11.getDistanceSq((double)i7 + 0.5D, (double)i9 + 0.5D, (double)i8 + 0.5D) > 4.0D) {
						this.playSoundEffect((double)i7 + 0.5D, (double)i9 + 0.5D, (double)i8 + 0.5D, "ambient.cave.cave", 0.7F, 0.8F + this.rand.nextFloat() * 0.2F);
						this.field_9426_L = this.rand.nextInt(12000) + 6000;
					}
				}
			}

			for(i6 = 0; i6 < 80; ++i6) {
				this.field_9437_g = this.field_9437_g * 3 + this.field_9436_h;
				i7 = this.field_9437_g >> 2;
				i8 = i7 & 15;
				i9 = i7 >> 8 & 15;
				i10 = i7 >> 16 & 127;
				byte b15 = chunk14.blocks[i8 << 11 | i9 << 7 | i10];
				if(Block.tickOnLoad[b15]) {
					Block.blocksList[b15].updateTick(this, i8 + i3, i10, i9 + i4, this.rand);
				}
			}
		}

	}

	public boolean TickUpdates(boolean z1) {
		int i2 = this.scheduledTickTreeSet.size();
		if(i2 != this.scheduledTickSet.size()) {
			throw new IllegalStateException("TickNextTick list out of synch");
		} else {
			if(i2 > 1000) {
				i2 = 1000;
			}

			for(int i3 = 0; i3 < i2; ++i3) {
				NextTickListEntry nextTickListEntry4 = (NextTickListEntry)this.scheduledTickTreeSet.first();
				if(!z1 && nextTickListEntry4.scheduledTime > this.worldTime) {
					break;
				}

				this.scheduledTickTreeSet.remove(nextTickListEntry4);
				this.scheduledTickSet.remove(nextTickListEntry4);
				byte b5 = 8;
				if(this.checkChunksExist(nextTickListEntry4.xCoord - b5, nextTickListEntry4.yCoord - b5, nextTickListEntry4.zCoord - b5, nextTickListEntry4.xCoord + b5, nextTickListEntry4.yCoord + b5, nextTickListEntry4.zCoord + b5)) {
					int i6 = this.getBlockId(nextTickListEntry4.xCoord, nextTickListEntry4.yCoord, nextTickListEntry4.zCoord);
					if(i6 == nextTickListEntry4.blockID && i6 > 0) {
						Block.blocksList[i6].updateTick(this, nextTickListEntry4.xCoord, nextTickListEntry4.yCoord, nextTickListEntry4.zCoord, this.rand);
					}
				}
			}

			return this.scheduledTickTreeSet.size() != 0;
		}
	}

	public void randomDisplayUpdates(int i1, int i2, int i3) {
		byte b4 = 16;
		Random random5 = new Random();

		for(int i6 = 0; i6 < 1000; ++i6) {
			int i7 = i1 + this.rand.nextInt(b4) - this.rand.nextInt(b4);
			int i8 = i2 + this.rand.nextInt(b4) - this.rand.nextInt(b4);
			int i9 = i3 + this.rand.nextInt(b4) - this.rand.nextInt(b4);
			int i10 = this.getBlockId(i7, i8, i9);
			if(i10 > 0) {
				Block.blocksList[i10].randomDisplayTick(this, i7, i8, i9, random5);
			}
		}

	}

	public List getEntitiesWithinAABBExcludingEntity(Entity entity1, AxisAlignedBB axisAlignedBB2) {
		this.field_1012_M.clear();
		int i3 = MathHelper.floor_double((axisAlignedBB2.minX - 2.0D) / 16.0D);
		int i4 = MathHelper.floor_double((axisAlignedBB2.maxX + 2.0D) / 16.0D);
		int i5 = MathHelper.floor_double((axisAlignedBB2.minZ - 2.0D) / 16.0D);
		int i6 = MathHelper.floor_double((axisAlignedBB2.maxZ + 2.0D) / 16.0D);

		for(int i7 = i3; i7 <= i4; ++i7) {
			for(int i8 = i5; i8 <= i6; ++i8) {
				if(this.chunkExists(i7, i8)) {
					this.getChunkFromChunkCoords(i7, i8).getEntitiesWithinAABBForEntity(entity1, axisAlignedBB2, this.field_1012_M);
				}
			}
		}

		return this.field_1012_M;
	}

	public List getEntitiesWithinAABB(Class class1, AxisAlignedBB axisAlignedBB2) {
		int i3 = MathHelper.floor_double((axisAlignedBB2.minX - 2.0D) / 16.0D);
		int i4 = MathHelper.floor_double((axisAlignedBB2.maxX + 2.0D) / 16.0D);
		int i5 = MathHelper.floor_double((axisAlignedBB2.minZ - 2.0D) / 16.0D);
		int i6 = MathHelper.floor_double((axisAlignedBB2.maxZ + 2.0D) / 16.0D);
		ArrayList arrayList7 = new ArrayList();

		for(int i8 = i3; i8 <= i4; ++i8) {
			for(int i9 = i5; i9 <= i6; ++i9) {
				if(this.chunkExists(i8, i9)) {
					this.getChunkFromChunkCoords(i8, i9).getEntitiesOfTypeWithinAAAB(class1, axisAlignedBB2, arrayList7);
				}
			}
		}

		return arrayList7;
	}

	public List func_658_i() {
		return this.loadedEntityList;
	}

	public void func_698_b(int i1, int i2, int i3, TileEntity tileEntity4) {
		if(this.blockExists(i1, i2, i3)) {
			this.getChunkFromBlockCoords(i1, i3).setChunkModified();
		}

		for(int i5 = 0; i5 < this.worldAccesses.size(); ++i5) {
			((IWorldAccess)this.worldAccesses.get(i5)).func_935_a(i1, i2, i3, tileEntity4);
		}

	}

	public int countEntities(Class class1) {
		int i2 = 0;

		for(int i3 = 0; i3 < this.loadedEntityList.size(); ++i3) {
			Entity entity4 = (Entity)this.loadedEntityList.get(i3);
			if(class1.isAssignableFrom(entity4.getClass())) {
				++i2;
			}
		}

		return i2;
	}

	public void func_636_a(List list1) {
		this.loadedEntityList.addAll(list1);

		for(int i2 = 0; i2 < list1.size(); ++i2) {
			this.obtainEntitySkin((Entity)list1.get(i2));
		}

	}

	public void func_632_b(List list1) {
		this.field_1024_A.addAll(list1);
	}

	public void func_656_j() {
		while(this.chunkProvider.func_532_a()) {
		}

	}

	public boolean canBlockBePlacedAt(int i1, int i2, int i3, int i4, boolean z5) {
		int i6 = this.getBlockId(i2, i3, i4);
		Block block7 = Block.blocksList[i6];
		Block block8 = Block.blocksList[i1];
		AxisAlignedBB axisAlignedBB9 = block8.getCollisionBoundingBoxFromPool(this, i2, i3, i4);
		if(z5) {
			axisAlignedBB9 = null;
		}

		return axisAlignedBB9 != null && !this.checkIfAABBIsClear(axisAlignedBB9) ? false : (block7 != Block.waterStill && block7 != Block.waterMoving && block7 != Block.lavaStill && block7 != Block.lavaMoving && block7 != Block.fire && block7 != Block.snow ? i1 > 0 && block7 == null && block8.canPlaceBlockAt(this, i2, i3, i4) : true);
	}

	public PathEntity getPathToEntity(Entity entity1, Entity entity2, float f3) {
		int i4 = MathHelper.floor_double(entity1.posX);
		int i5 = MathHelper.floor_double(entity1.posY);
		int i6 = MathHelper.floor_double(entity1.posZ);
		int i7 = (int)(f3 + 16.0F);
		int i8 = i4 - i7;
		int i9 = i5 - i7;
		int i10 = i6 - i7;
		int i11 = i4 + i7;
		int i12 = i5 + i7;
		int i13 = i6 + i7;
		ChunkCache chunkCache14 = new ChunkCache(this, i8, i9, i10, i11, i12, i13);
		return (new Pathfinder(chunkCache14)).createEntityPathTo(entity1, entity2, f3);
	}

	public PathEntity getEntityPathToXYZ(Entity entity1, int i2, int i3, int i4, float f5) {
		int i6 = MathHelper.floor_double(entity1.posX);
		int i7 = MathHelper.floor_double(entity1.posY);
		int i8 = MathHelper.floor_double(entity1.posZ);
		int i9 = (int)(f5 + 8.0F);
		int i10 = i6 - i9;
		int i11 = i7 - i9;
		int i12 = i8 - i9;
		int i13 = i6 + i9;
		int i14 = i7 + i9;
		int i15 = i8 + i9;
		ChunkCache chunkCache16 = new ChunkCache(this, i10, i11, i12, i13, i14, i15);
		return (new Pathfinder(chunkCache16)).createEntityPathTo(entity1, i2, i3, i4, f5);
	}

	public boolean isBlockProvidingPowerTo(int i1, int i2, int i3, int i4) {
		int i5 = this.getBlockId(i1, i2, i3);
		return i5 == 0 ? false : Block.blocksList[i5].isIndirectlyPoweringTo(this, i1, i2, i3, i4);
	}

	public boolean isBlockGettingPowered(int i1, int i2, int i3) {
		return this.isBlockProvidingPowerTo(i1, i2 - 1, i3, 0) ? true : (this.isBlockProvidingPowerTo(i1, i2 + 1, i3, 1) ? true : (this.isBlockProvidingPowerTo(i1, i2, i3 - 1, 2) ? true : (this.isBlockProvidingPowerTo(i1, i2, i3 + 1, 3) ? true : (this.isBlockProvidingPowerTo(i1 - 1, i2, i3, 4) ? true : this.isBlockProvidingPowerTo(i1 + 1, i2, i3, 5)))));
	}

	public boolean isBlockIndirectlyProvidingPowerTo(int i1, int i2, int i3, int i4) {
		if(this.isBlockOpaqueCube(i1, i2, i3)) {
			return this.isBlockGettingPowered(i1, i2, i3);
		} else {
			int i5 = this.getBlockId(i1, i2, i3);
			return i5 == 0 ? false : Block.blocksList[i5].isPoweringTo(this, i1, i2, i3, i4);
		}
	}

	public boolean isBlockIndirectlyGettingPowered(int i1, int i2, int i3) {
		return this.isBlockIndirectlyProvidingPowerTo(i1, i2 - 1, i3, 0) ? true : (this.isBlockIndirectlyProvidingPowerTo(i1, i2 + 1, i3, 1) ? true : (this.isBlockIndirectlyProvidingPowerTo(i1, i2, i3 - 1, 2) ? true : (this.isBlockIndirectlyProvidingPowerTo(i1, i2, i3 + 1, 3) ? true : (this.isBlockIndirectlyProvidingPowerTo(i1 - 1, i2, i3, 4) ? true : this.isBlockIndirectlyProvidingPowerTo(i1 + 1, i2, i3, 5)))));
	}

	public EntityPlayer getClosestPlayerToEntity(Entity entity1, double d2) {
		return this.getClosestPlayer(entity1.posX, entity1.posY, entity1.posZ, d2);
	}

	public EntityPlayer getClosestPlayer(double d1, double d3, double d5, double d7) {
		double d9 = -1.0D;
		EntityPlayer entityPlayer11 = null;

		for(int i12 = 0; i12 < this.playerEntities.size(); ++i12) {
			EntityPlayer entityPlayer13 = (EntityPlayer)this.playerEntities.get(i12);
			double d14 = entityPlayer13.getDistanceSq(d1, d3, d5);
			if((d7 < 0.0D || d14 < d7 * d7) && (d9 == -1.0D || d14 < d9)) {
				d9 = d14;
				entityPlayer11 = entityPlayer13;
			}
		}

		return entityPlayer11;
	}

	public void func_693_a(int i1, int i2, int i3, int i4, int i5, int i6, byte[] b7) {
		int i8 = i1 >> 4;
		int i9 = i3 >> 4;
		int i10 = i1 + i4 - 1 >> 4;
		int i11 = i3 + i6 - 1 >> 4;
		int i12 = 0;
		int i13 = i2;
		int i14 = i2 + i5;
		if(i2 < 0) {
			i13 = 0;
		}

		if(i14 > 128) {
			i14 = 128;
		}

		for(int i15 = i8; i15 <= i10; ++i15) {
			int i16 = i1 - i15 * 16;
			int i17 = i1 + i4 - i15 * 16;
			if(i16 < 0) {
				i16 = 0;
			}

			if(i17 > 16) {
				i17 = 16;
			}

			for(int i18 = i9; i18 <= i11; ++i18) {
				int i19 = i3 - i18 * 16;
				int i20 = i3 + i6 - i18 * 16;
				if(i19 < 0) {
					i19 = 0;
				}

				if(i20 > 16) {
					i20 = 16;
				}

				i12 = this.getChunkFromChunkCoords(i15, i18).func_1004_a(b7, i16, i13, i19, i17, i14, i20, i12);
				this.func_701_b(i15 * 16 + i16, i13, i18 * 16 + i19, i15 * 16 + i17, i14, i18 * 16 + i20);
			}
		}

	}

	public void sendQuittingDisconnectingPacket() {
	}

	public void func_663_l() {
		try {
			File file1 = new File(this.field_9432_t, "session.lock");
			DataInputStream dataInputStream2 = new DataInputStream(new FileInputStream(file1));

			try {
				if(dataInputStream2.readLong() != this.field_1054_E) {
					throw new MinecraftException("The save is being accessed from another location, aborting");
				}
			} finally {
				dataInputStream2.close();
			}

		} catch (IOException iOException7) {
			throw new MinecraftException("Failed to check session lock, aborting");
		}
	}

	public void setWorldTime(long j1) {
		this.worldTime = j1;
	}

	public void func_705_f(Entity entity1) {
		int i2 = MathHelper.floor_double(entity1.posX / 16.0D);
		int i3 = MathHelper.floor_double(entity1.posZ / 16.0D);
		byte b4 = 2;

		for(int i5 = i2 - b4; i5 <= i2 + b4; ++i5) {
			for(int i6 = i3 - b4; i6 <= i3 + b4; ++i6) {
				this.getChunkFromChunkCoords(i5, i6);
			}
		}

		if(!this.loadedEntityList.contains(entity1)) {
			this.loadedEntityList.add(entity1);
		}

	}

	public boolean func_6466_a(EntityPlayer entityPlayer1, int i2, int i3, int i4) {
		return true;
	}

	public void func_9425_a(Entity entity1, byte b2) {
	}

	public void func_9424_o() {
		this.loadedEntityList.removeAll(this.field_1024_A);

		int i1;
		Entity entity2;
		int i3;
		int i4;
		for(i1 = 0; i1 < this.field_1024_A.size(); ++i1) {
			entity2 = (Entity)this.field_1024_A.get(i1);
			i3 = entity2.chunkCoordX;
			i4 = entity2.chunkCoordZ;
			if(entity2.addedToChunk && this.chunkExists(i3, i4)) {
				this.getChunkFromChunkCoords(i3, i4).func_1015_b(entity2);
			}
		}

		for(i1 = 0; i1 < this.field_1024_A.size(); ++i1) {
			this.releaseEntitySkin((Entity)this.field_1024_A.get(i1));
		}

		this.field_1024_A.clear();

		for(i1 = 0; i1 < this.loadedEntityList.size(); ++i1) {
			entity2 = (Entity)this.loadedEntityList.get(i1);
			if(entity2.ridingEntity != null) {
				if(!entity2.ridingEntity.isDead && entity2.ridingEntity.riddenByEntity == entity2) {
					continue;
				}

				entity2.ridingEntity.riddenByEntity = null;
				entity2.ridingEntity = null;
			}

			if(entity2.isDead) {
				i3 = entity2.chunkCoordX;
				i4 = entity2.chunkCoordZ;
				if(entity2.addedToChunk && this.chunkExists(i3, i4)) {
					this.getChunkFromChunkCoords(i3, i4).func_1015_b(entity2);
				}

				this.loadedEntityList.remove(i1--);
				this.releaseEntitySkin(entity2);
			}
		}

	}
}
