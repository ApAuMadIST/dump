package net.minecraft.src;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.lwjgl.opengl.GL11;

public class TileEntityRenderer {
	private Map specialRendererMap = new HashMap();
	public static TileEntityRenderer instance = new TileEntityRenderer();
	private FontRenderer fontRenderer;
	public static double staticPlayerX;
	public static double staticPlayerY;
	public static double staticPlayerZ;
	public RenderEngine renderEngine;
	public World worldObj;
	public EntityPlayer entityPlayer;
	public float playerYaw;
	public float playerPitch;
	public double playerX;
	public double playerY;
	public double playerZ;

	private TileEntityRenderer() {
		this.specialRendererMap.put(TileEntitySign.class, new TileEntitySignRenderer());
		this.specialRendererMap.put(TileEntityMobSpawner.class, new TileEntityMobSpawnerRenderer());
		Iterator iterator1 = this.specialRendererMap.values().iterator();

		while(iterator1.hasNext()) {
			TileEntitySpecialRenderer tileEntitySpecialRenderer2 = (TileEntitySpecialRenderer)iterator1.next();
			tileEntitySpecialRenderer2.setTileEntityRenderer(this);
		}

	}

	public TileEntitySpecialRenderer getSpecialRendererForClass(Class class1) {
		TileEntitySpecialRenderer tileEntitySpecialRenderer2 = (TileEntitySpecialRenderer)this.specialRendererMap.get(class1);
		if(tileEntitySpecialRenderer2 == null && class1 != TileEntity.class) {
			tileEntitySpecialRenderer2 = this.getSpecialRendererForClass(class1.getSuperclass());
			this.specialRendererMap.put(class1, tileEntitySpecialRenderer2);
		}

		return tileEntitySpecialRenderer2;
	}

	public boolean hasSpecialRenderer(TileEntity tileEntity1) {
		return this.getSpecialRendererForEntity(tileEntity1) != null;
	}

	public TileEntitySpecialRenderer getSpecialRendererForEntity(TileEntity tileEntity1) {
		return tileEntity1 == null ? null : this.getSpecialRendererForClass(tileEntity1.getClass());
	}

	public void setRenderingContext(World world1, RenderEngine renderEngine2, FontRenderer fontRenderer3, EntityPlayer entityPlayer4, float f5) {
		this.worldObj = world1;
		this.renderEngine = renderEngine2;
		this.entityPlayer = entityPlayer4;
		this.fontRenderer = fontRenderer3;
		this.playerYaw = entityPlayer4.prevRotationYaw + (entityPlayer4.rotationYaw - entityPlayer4.prevRotationYaw) * f5;
		this.playerPitch = entityPlayer4.prevRotationPitch + (entityPlayer4.rotationPitch - entityPlayer4.prevRotationPitch) * f5;
		this.playerX = entityPlayer4.lastTickPosX + (entityPlayer4.posX - entityPlayer4.lastTickPosX) * (double)f5;
		this.playerY = entityPlayer4.lastTickPosY + (entityPlayer4.posY - entityPlayer4.lastTickPosY) * (double)f5;
		this.playerZ = entityPlayer4.lastTickPosZ + (entityPlayer4.posZ - entityPlayer4.lastTickPosZ) * (double)f5;
	}

	public void renderTileEntity(TileEntity tileEntity1, float f2) {
		if(tileEntity1.getDistanceFrom(this.playerX, this.playerY, this.playerZ) < 4096.0D) {
			float f3 = this.worldObj.getLightBrightness(tileEntity1.xCoord, tileEntity1.yCoord, tileEntity1.zCoord);
			GL11.glColor3f(f3, f3, f3);
			this.renderTileEntityAt(tileEntity1, (double)tileEntity1.xCoord - staticPlayerX, (double)tileEntity1.yCoord - staticPlayerY, (double)tileEntity1.zCoord - staticPlayerZ, f2);
		}

	}

	public void renderTileEntityAt(TileEntity tileEntity1, double d2, double d4, double d6, float f8) {
		TileEntitySpecialRenderer tileEntitySpecialRenderer9 = this.getSpecialRendererForEntity(tileEntity1);
		if(tileEntitySpecialRenderer9 != null) {
			tileEntitySpecialRenderer9.renderTileEntityAt(tileEntity1, d2, d4, d6, f8);
		}

	}

	public FontRenderer getFontRenderer() {
		return this.fontRenderer;
	}
}
