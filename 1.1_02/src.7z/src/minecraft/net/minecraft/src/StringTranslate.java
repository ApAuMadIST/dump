package net.minecraft.src;

import java.io.IOException;
import java.util.Properties;

public class StringTranslate {
	private static StringTranslate field_20165_a = new StringTranslate();
	private Properties field_20164_b = new Properties();

	private StringTranslate() {
		try {
			this.field_20164_b.load(StringTranslate.class.getResourceAsStream("/lang/en_US.lang"));
		} catch (IOException iOException2) {
			iOException2.printStackTrace();
		}

	}

	public static StringTranslate func_20162_a() {
		return field_20165_a;
	}

	public String func_20163_a(String string1) {
		return this.field_20164_b.getProperty(string1, string1);
	}

	public String func_20160_a(String string1, Object... object2) {
		String string3 = this.field_20164_b.getProperty(string1, string1);
		return String.format(string3, object2);
	}

	public String func_20161_b(String string1) {
		return this.field_20164_b.getProperty(string1 + ".name", "");
	}
}
