package net.minecraft.src;

public class ModelBiped extends ModelBase {
	public ModelRenderer bipedHead;
	public ModelRenderer field_1285_b;
	public ModelRenderer field_1284_c;
	public ModelRenderer bipedRightArm;
	public ModelRenderer bipedLeftArm;
	public ModelRenderer bipedRightLeg;
	public ModelRenderer bipedLeftLeg;
	public ModelRenderer field_20098_h;
	public ModelRenderer field_20097_i;
	public boolean field_1279_h;
	public boolean field_1278_i;
	public boolean field_1277_j;

	public ModelBiped() {
		this(0.0F);
	}

	public ModelBiped(float f1) {
		this(f1, 0.0F);
	}

	public ModelBiped(float f1, float f2) {
		this.field_1279_h = false;
		this.field_1278_i = false;
		this.field_1277_j = false;
		this.field_20097_i = new ModelRenderer(0, 0);
		this.field_20097_i.addBox(-5.0F, 0.0F, -1.0F, 10, 16, 1, f1);
		this.field_20098_h = new ModelRenderer(24, 0);
		this.field_20098_h.addBox(-3.0F, -6.0F, -1.0F, 6, 6, 1, f1);
		this.bipedHead = new ModelRenderer(0, 0);
		this.bipedHead.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, f1);
		this.bipedHead.setPosition(0.0F, 0.0F + f2, 0.0F);
		this.field_1285_b = new ModelRenderer(32, 0);
		this.field_1285_b.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, f1 + 0.5F);
		this.field_1285_b.setPosition(0.0F, 0.0F + f2, 0.0F);
		this.field_1284_c = new ModelRenderer(16, 16);
		this.field_1284_c.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, f1);
		this.field_1284_c.setPosition(0.0F, 0.0F + f2, 0.0F);
		this.bipedRightArm = new ModelRenderer(40, 16);
		this.bipedRightArm.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4, f1);
		this.bipedRightArm.setPosition(-5.0F, 2.0F + f2, 0.0F);
		this.bipedLeftArm = new ModelRenderer(40, 16);
		this.bipedLeftArm.mirror = true;
		this.bipedLeftArm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, f1);
		this.bipedLeftArm.setPosition(5.0F, 2.0F + f2, 0.0F);
		this.bipedRightLeg = new ModelRenderer(0, 16);
		this.bipedRightLeg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, f1);
		this.bipedRightLeg.setPosition(-2.0F, 12.0F + f2, 0.0F);
		this.bipedLeftLeg = new ModelRenderer(0, 16);
		this.bipedLeftLeg.mirror = true;
		this.bipedLeftLeg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, f1);
		this.bipedLeftLeg.setPosition(2.0F, 12.0F + f2, 0.0F);
	}

	public void render(float f1, float f2, float f3, float f4, float f5, float f6) {
		this.setRotationAngles(f1, f2, f3, f4, f5, f6);
		this.bipedHead.render(f6);
		this.field_1284_c.render(f6);
		this.bipedRightArm.render(f6);
		this.bipedLeftArm.render(f6);
		this.bipedRightLeg.render(f6);
		this.bipedLeftLeg.render(f6);
		this.field_1285_b.render(f6);
	}

	public void setRotationAngles(float f1, float f2, float f3, float f4, float f5, float f6) {
		this.bipedHead.rotateAngleY = f4 / 57.295776F;
		this.bipedHead.rotateAngleX = f5 / 57.295776F;
		this.field_1285_b.rotateAngleY = this.bipedHead.rotateAngleY;
		this.field_1285_b.rotateAngleX = this.bipedHead.rotateAngleX;
		this.bipedRightArm.rotateAngleX = MathHelper.cos(f1 * 0.6662F + (float)Math.PI) * 2.0F * f2 * 0.5F;
		this.bipedLeftArm.rotateAngleX = MathHelper.cos(f1 * 0.6662F) * 2.0F * f2 * 0.5F;
		this.bipedRightArm.rotateAngleZ = 0.0F;
		this.bipedLeftArm.rotateAngleZ = 0.0F;
		this.bipedRightLeg.rotateAngleX = MathHelper.cos(f1 * 0.6662F) * 1.4F * f2;
		this.bipedLeftLeg.rotateAngleX = MathHelper.cos(f1 * 0.6662F + (float)Math.PI) * 1.4F * f2;
		this.bipedRightLeg.rotateAngleY = 0.0F;
		this.bipedLeftLeg.rotateAngleY = 0.0F;
		if(this.field_1243_l) {
			this.bipedRightArm.rotateAngleX += -0.62831855F;
			this.bipedLeftArm.rotateAngleX += -0.62831855F;
			this.bipedRightLeg.rotateAngleX = -1.2566371F;
			this.bipedLeftLeg.rotateAngleX = -1.2566371F;
			this.bipedRightLeg.rotateAngleY = 0.31415927F;
			this.bipedLeftLeg.rotateAngleY = -0.31415927F;
		}

		if(this.field_1279_h) {
			this.bipedLeftArm.rotateAngleX = this.bipedLeftArm.rotateAngleX * 0.5F - 0.31415927F;
		}

		if(this.field_1278_i) {
			this.bipedRightArm.rotateAngleX = this.bipedRightArm.rotateAngleX * 0.5F - 0.31415927F;
		}

		this.bipedRightArm.rotateAngleY = 0.0F;
		this.bipedLeftArm.rotateAngleY = 0.0F;
		if(this.field_1244_k > -9990.0F) {
			float f7 = this.field_1244_k;
			this.field_1284_c.rotateAngleY = MathHelper.sin(MathHelper.sqrt_float(f7) * (float)Math.PI * 2.0F) * 0.2F;
			this.bipedRightArm.offsetZ = MathHelper.sin(this.field_1284_c.rotateAngleY) * 5.0F;
			this.bipedRightArm.offsetX = -MathHelper.cos(this.field_1284_c.rotateAngleY) * 5.0F;
			this.bipedLeftArm.offsetZ = -MathHelper.sin(this.field_1284_c.rotateAngleY) * 5.0F;
			this.bipedLeftArm.offsetX = MathHelper.cos(this.field_1284_c.rotateAngleY) * 5.0F;
			this.bipedRightArm.rotateAngleY += this.field_1284_c.rotateAngleY;
			this.bipedLeftArm.rotateAngleY += this.field_1284_c.rotateAngleY;
			this.bipedLeftArm.rotateAngleX += this.field_1284_c.rotateAngleY;
			f7 = 1.0F - this.field_1244_k;
			f7 *= f7;
			f7 *= f7;
			f7 = 1.0F - f7;
			float f8 = MathHelper.sin(f7 * (float)Math.PI);
			float f9 = MathHelper.sin(this.field_1244_k * (float)Math.PI) * -(this.bipedHead.rotateAngleX - 0.7F) * 0.75F;
			this.bipedRightArm.rotateAngleX = (float)((double)this.bipedRightArm.rotateAngleX - ((double)f8 * 1.2D + (double)f9));
			this.bipedRightArm.rotateAngleY += this.field_1284_c.rotateAngleY * 2.0F;
			this.bipedRightArm.rotateAngleZ = MathHelper.sin(this.field_1244_k * (float)Math.PI) * -0.4F;
		}

		if(this.field_1277_j) {
			this.field_1284_c.rotateAngleX = 0.5F;
			this.bipedRightLeg.rotateAngleX -= 0.0F;
			this.bipedLeftLeg.rotateAngleX -= 0.0F;
			this.bipedRightArm.rotateAngleX += 0.4F;
			this.bipedLeftArm.rotateAngleX += 0.4F;
			this.bipedRightLeg.offsetZ = 4.0F;
			this.bipedLeftLeg.offsetZ = 4.0F;
			this.bipedRightLeg.offsetY = 9.0F;
			this.bipedLeftLeg.offsetY = 9.0F;
			this.bipedHead.offsetY = 1.0F;
		} else {
			this.field_1284_c.rotateAngleX = 0.0F;
			this.bipedRightLeg.offsetZ = 0.0F;
			this.bipedLeftLeg.offsetZ = 0.0F;
			this.bipedRightLeg.offsetY = 12.0F;
			this.bipedLeftLeg.offsetY = 12.0F;
			this.bipedHead.offsetY = 0.0F;
		}

		this.bipedRightArm.rotateAngleZ += MathHelper.cos(f3 * 0.09F) * 0.05F + 0.05F;
		this.bipedLeftArm.rotateAngleZ -= MathHelper.cos(f3 * 0.09F) * 0.05F + 0.05F;
		this.bipedRightArm.rotateAngleX += MathHelper.sin(f3 * 0.067F) * 0.05F;
		this.bipedLeftArm.rotateAngleX -= MathHelper.sin(f3 * 0.067F) * 0.05F;
	}

	public void func_20095_a(float f1) {
		this.field_20098_h.rotateAngleY = this.bipedHead.rotateAngleY;
		this.field_20098_h.rotateAngleX = this.bipedHead.rotateAngleX;
		this.field_20098_h.offsetX = 0.0F;
		this.field_20098_h.offsetY = 0.0F;
		this.field_20098_h.render(f1);
	}

	public void func_20096_b(float f1) {
		this.field_20097_i.render(f1);
	}
}
