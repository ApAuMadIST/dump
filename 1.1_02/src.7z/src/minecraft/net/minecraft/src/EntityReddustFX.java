package net.minecraft.src;

public class EntityReddustFX extends EntityFX {
	float field_673_a;

	public EntityReddustFX(World world1, double d2, double d4, double d6) {
		this(world1, d2, d4, d6, 1.0F);
	}

	public EntityReddustFX(World world1, double d2, double d4, double d6, float f8) {
		super(world1, d2, d4, d6, 0.0D, 0.0D, 0.0D);
		this.motionX *= (double)0.1F;
		this.motionY *= (double)0.1F;
		this.motionZ *= (double)0.1F;
		this.particleRed = (float)(Math.random() * (double)0.3F) + 0.7F;
		this.particleBlue = this.particleGreen = (float)(Math.random() * (double)0.1F);
		this.field_665_g *= 0.75F;
		this.field_665_g *= f8;
		this.field_673_a = this.field_665_g;
		this.field_666_f = (int)(8.0D / (Math.random() * 0.8D + 0.2D));
		this.field_666_f = (int)((float)this.field_666_f * f8);
		this.noClip = false;
	}

	public void func_406_a(Tessellator tessellator1, float f2, float f3, float f4, float f5, float f6, float f7) {
		float f8 = ((float)this.e + f2) / (float)this.field_666_f * 32.0F;
		if(f8 < 0.0F) {
			f8 = 0.0F;
		}

		if(f8 > 1.0F) {
			f8 = 1.0F;
		}

		this.field_665_g = this.field_673_a * f8;
		super.func_406_a(tessellator1, f2, f3, f4, f5, f6, f7);
	}

	public void onUpdate() {
		this.prevPosX = this.posX;
		this.prevPosY = this.posY;
		this.prevPosZ = this.posZ;
		if(this.e++ >= this.field_666_f) {
			this.setEntityDead();
		}

		this.field_670_b = 7 - this.e * 8 / this.field_666_f;
		this.moveEntity(this.motionX, this.motionY, this.motionZ);
		if(this.posY == this.prevPosY) {
			this.motionX *= 1.1D;
			this.motionZ *= 1.1D;
		}

		this.motionX *= (double)0.96F;
		this.motionY *= (double)0.96F;
		this.motionZ *= (double)0.96F;
		if(this.onGround) {
			this.motionX *= (double)0.7F;
			this.motionZ *= (double)0.7F;
		}

	}
}
