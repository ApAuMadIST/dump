package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet5PlayerInventory extends Packet {
	public int type;
	public int stacks;
	public int field_20044_c;

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.type = dataInputStream1.readInt();
		this.stacks = dataInputStream1.readShort();
		this.field_20044_c = dataInputStream1.readShort();
	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeInt(this.type);
		dataOutputStream1.writeShort(this.stacks);
		dataOutputStream1.writeShort(this.field_20044_c);
	}

	public void processPacket(NetHandler netHandler1) {
		netHandler1.handlePlayerInventory(this);
	}

	public int getPacketSize() {
		return 8;
	}
}
