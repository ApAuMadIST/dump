package net.minecraft.src;

import java.util.List;

public class EntityBoat extends Entity {
	public int field_807_a;
	public int field_806_b;
	public int field_808_c;
	private int field_9394_d;
	private double field_9393_e;
	private double field_9392_f;
	private double field_9391_g;
	private double field_9390_h;
	private double field_9389_i;
	private double field_9388_j;
	private double field_9387_k;
	private double field_9386_l;

	public EntityBoat(World world1) {
		super(world1);
		this.field_807_a = 0;
		this.field_806_b = 0;
		this.field_808_c = 1;
		this.preventEntitySpawning = true;
		this.setSize(1.5F, 0.6F);
		this.yOffset = this.height / 2.0F;
		this.entityWalks = false;
	}

	public AxisAlignedBB func_383_b_(Entity entity1) {
		return entity1.boundingBox;
	}

	public AxisAlignedBB func_372_f_() {
		return this.boundingBox;
	}

	public boolean canBePushed() {
		return true;
	}

	public EntityBoat(World world1, double d2, double d4, double d6) {
		this(world1);
		this.setPosition(d2, d4 + (double)this.yOffset, d6);
		this.motionX = 0.0D;
		this.motionY = 0.0D;
		this.motionZ = 0.0D;
		this.prevPosX = d2;
		this.prevPosY = d4;
		this.prevPosZ = d6;
	}

	public double getMountedYOffset() {
		return (double)this.height * 0.0D - (double)0.3F;
	}

	public boolean attackEntityFrom(Entity entity1, int i2) {
		if(!this.worldObj.multiplayerWorld && !this.isDead) {
			this.field_808_c = -this.field_808_c;
			this.field_806_b = 10;
			this.field_807_a += i2 * 10;
			this.setBeenAttacked();
			if(this.field_807_a > 40) {
				int i3;
				for(i3 = 0; i3 < 3; ++i3) {
					this.dropItemWithOffset(Block.planks.blockID, 1, 0.0F);
				}

				for(i3 = 0; i3 < 2; ++i3) {
					this.dropItemWithOffset(Item.stick.shiftedIndex, 1, 0.0F);
				}

				this.setEntityDead();
			}

			return true;
		} else {
			return true;
		}
	}

	public void performHurtAnimation() {
		this.field_808_c = -this.field_808_c;
		this.field_806_b = 10;
		this.field_807_a += this.field_807_a * 10;
	}

	public boolean canBeCollidedWith() {
		return !this.isDead;
	}

	public void setPositionAndRotation2(double d1, double d3, double d5, float f7, float f8, int i9) {
		this.field_9393_e = d1;
		this.field_9392_f = d3;
		this.field_9391_g = d5;
		this.field_9390_h = (double)f7;
		this.field_9389_i = (double)f8;
		this.field_9394_d = i9 + 4;
		this.motionX = this.field_9388_j;
		this.motionY = this.field_9387_k;
		this.motionZ = this.field_9386_l;
	}

	public void setVelocity(double d1, double d3, double d5) {
		this.field_9388_j = this.motionX = d1;
		this.field_9387_k = this.motionY = d3;
		this.field_9386_l = this.motionZ = d5;
	}

	public void onUpdate() {
		super.onUpdate();
		if(this.field_806_b > 0) {
			--this.field_806_b;
		}

		if(this.field_807_a > 0) {
			--this.field_807_a;
		}

		this.prevPosX = this.posX;
		this.prevPosY = this.posY;
		this.prevPosZ = this.posZ;
		byte b1 = 5;
		double d2 = 0.0D;

		for(int i4 = 0; i4 < b1; ++i4) {
			double d5 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (double)(i4 + 0) / (double)b1 - 0.125D;
			double d7 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (double)(i4 + 1) / (double)b1 - 0.125D;
			AxisAlignedBB axisAlignedBB9 = AxisAlignedBB.getBoundingBoxFromPool(this.boundingBox.minX, d5, this.boundingBox.minZ, this.boundingBox.maxX, d7, this.boundingBox.maxZ);
			if(this.worldObj.func_707_b(axisAlignedBB9, Material.water)) {
				d2 += 1.0D / (double)b1;
			}
		}

		double d6;
		double d8;
		double d10;
		double d23;
		if(this.worldObj.multiplayerWorld) {
			if(this.field_9394_d > 0) {
				d23 = this.posX + (this.field_9393_e - this.posX) / (double)this.field_9394_d;
				d6 = this.posY + (this.field_9392_f - this.posY) / (double)this.field_9394_d;
				d8 = this.posZ + (this.field_9391_g - this.posZ) / (double)this.field_9394_d;

				for(d10 = this.field_9390_h - (double)this.rotationYaw; d10 < -180.0D; d10 += 360.0D) {
				}

				while(d10 >= 180.0D) {
					d10 -= 360.0D;
				}

				this.rotationYaw = (float)((double)this.rotationYaw + d10 / (double)this.field_9394_d);
				this.rotationPitch = (float)((double)this.rotationPitch + (this.field_9389_i - (double)this.rotationPitch) / (double)this.field_9394_d);
				--this.field_9394_d;
				this.setPosition(d23, d6, d8);
				this.setRotation(this.rotationYaw, this.rotationPitch);
			} else {
				d23 = this.posX + this.motionX;
				d6 = this.posY + this.motionY;
				d8 = this.posZ + this.motionZ;
				this.setPosition(d23, d6, d8);
				if(this.onGround) {
					this.motionX *= 0.5D;
					this.motionY *= 0.5D;
					this.motionZ *= 0.5D;
				}

				this.motionX *= (double)0.99F;
				this.motionY *= (double)0.95F;
				this.motionZ *= (double)0.99F;
			}

		} else {
			d23 = d2 * 2.0D - 1.0D;
			this.motionY += (double)0.04F * d23;
			if(this.riddenByEntity != null) {
				this.motionX += this.riddenByEntity.motionX * 0.2D;
				this.motionZ += this.riddenByEntity.motionZ * 0.2D;
			}

			d6 = 0.4D;
			if(this.motionX < -d6) {
				this.motionX = -d6;
			}

			if(this.motionX > d6) {
				this.motionX = d6;
			}

			if(this.motionZ < -d6) {
				this.motionZ = -d6;
			}

			if(this.motionZ > d6) {
				this.motionZ = d6;
			}

			if(this.onGround) {
				this.motionX *= 0.5D;
				this.motionY *= 0.5D;
				this.motionZ *= 0.5D;
			}

			this.moveEntity(this.motionX, this.motionY, this.motionZ);
			d8 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
			double d12;
			if(d8 > 0.15D) {
				d10 = Math.cos((double)this.rotationYaw * Math.PI / 180.0D);
				d12 = Math.sin((double)this.rotationYaw * Math.PI / 180.0D);

				for(int i14 = 0; (double)i14 < 1.0D + d8 * 60.0D; ++i14) {
					double d15 = (double)(this.rand.nextFloat() * 2.0F - 1.0F);
					double d17 = (double)(this.rand.nextInt(2) * 2 - 1) * 0.7D;
					double d19;
					double d21;
					if(this.rand.nextBoolean()) {
						d19 = this.posX - d10 * d15 * 0.8D + d12 * d17;
						d21 = this.posZ - d12 * d15 * 0.8D - d10 * d17;
						this.worldObj.spawnParticle("splash", d19, this.posY - 0.125D, d21, this.motionX, this.motionY, this.motionZ);
					} else {
						d19 = this.posX + d10 + d12 * d15 * 0.7D;
						d21 = this.posZ + d12 - d10 * d15 * 0.7D;
						this.worldObj.spawnParticle("splash", d19, this.posY - 0.125D, d21, this.motionX, this.motionY, this.motionZ);
					}
				}
			}

			if(this.isCollidedHorizontally && d8 > 0.15D) {
				if(!this.worldObj.multiplayerWorld) {
					this.setEntityDead();

					int i24;
					for(i24 = 0; i24 < 3; ++i24) {
						this.dropItemWithOffset(Block.planks.blockID, 1, 0.0F);
					}

					for(i24 = 0; i24 < 2; ++i24) {
						this.dropItemWithOffset(Item.stick.shiftedIndex, 1, 0.0F);
					}
				}
			} else {
				this.motionX *= (double)0.99F;
				this.motionY *= (double)0.95F;
				this.motionZ *= (double)0.99F;
			}

			this.rotationPitch = 0.0F;
			d10 = (double)this.rotationYaw;
			d12 = this.prevPosX - this.posX;
			double d25 = this.prevPosZ - this.posZ;
			if(d12 * d12 + d25 * d25 > 0.001D) {
				d10 = (double)((float)(Math.atan2(d25, d12) * 180.0D / Math.PI));
			}

			double d16;
			for(d16 = d10 - (double)this.rotationYaw; d16 >= 180.0D; d16 -= 360.0D) {
			}

			while(d16 < -180.0D) {
				d16 += 360.0D;
			}

			if(d16 > 20.0D) {
				d16 = 20.0D;
			}

			if(d16 < -20.0D) {
				d16 = -20.0D;
			}

			this.rotationYaw = (float)((double)this.rotationYaw + d16);
			this.setRotation(this.rotationYaw, this.rotationPitch);
			List list18 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand((double)0.2F, 0.0D, (double)0.2F));
			if(list18 != null && list18.size() > 0) {
				for(int i26 = 0; i26 < list18.size(); ++i26) {
					Entity entity20 = (Entity)list18.get(i26);
					if(entity20 != this.riddenByEntity && entity20.canBePushed() && entity20 instanceof EntityBoat) {
						entity20.applyEntityCollision(this);
					}
				}
			}

			if(this.riddenByEntity != null && this.riddenByEntity.isDead) {
				this.riddenByEntity = null;
			}

		}
	}

	public void func_366_i_() {
		if(this.riddenByEntity != null) {
			double d1 = Math.cos((double)this.rotationYaw * Math.PI / 180.0D) * 0.4D;
			double d3 = Math.sin((double)this.rotationYaw * Math.PI / 180.0D) * 0.4D;
			this.riddenByEntity.setPosition(this.posX + d1, this.posY + this.getMountedYOffset() + this.riddenByEntity.getYOffset(), this.posZ + d3);
		}
	}

	protected void writeEntityToNBT(NBTTagCompound nBTTagCompound1) {
	}

	protected void readEntityFromNBT(NBTTagCompound nBTTagCompound1) {
	}

	public float func_392_h_() {
		return 0.0F;
	}

	public boolean interact(EntityPlayer entityPlayer1) {
		if(this.riddenByEntity != null && this.riddenByEntity instanceof EntityPlayer && this.riddenByEntity != entityPlayer1) {
			return true;
		} else {
			if(!this.worldObj.multiplayerWorld) {
				entityPlayer1.mountEntity(this);
			}

			return true;
		}
	}
}
