package net.minecraft.src;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class ColorizerFoliage {
	private static final int[] field_6529_a = new int[65536];

	public static int func_4146_a(double d0, double d2) {
		d2 *= d0;
		int i4 = (int)((1.0D - d0) * 255.0D);
		int i5 = (int)((1.0D - d2) * 255.0D);
		return field_6529_a[i5 << 8 | i4];
	}

	static {
		try {
			BufferedImage bufferedImage0 = ImageIO.read(ColorizerFoliage.class.getResource("/misc/foliagecolor.png"));
			bufferedImage0.getRGB(0, 0, 256, 256, field_6529_a, 0, 256);
		} catch (Exception exception1) {
			exception1.printStackTrace();
		}

	}
}
