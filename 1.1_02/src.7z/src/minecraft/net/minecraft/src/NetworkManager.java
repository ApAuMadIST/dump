package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class NetworkManager {
	public static final Object threadSyncObject = new Object();
	public static int numReadThreads;
	public static int numWriteThreads;
	private Object sendQueueLock = new Object();
	private Socket field_12258_e;
	private final SocketAddress networkSocket;
	private DataInputStream socketInputStream;
	private DataOutputStream socketOutputStream;
	private boolean isRunning = true;
	private List readPackets = Collections.synchronizedList(new ArrayList());
	private List dataPackets = Collections.synchronizedList(new ArrayList());
	private List chunkDataPackets = Collections.synchronizedList(new ArrayList());
	private NetHandler netHandler;
	private boolean isServerTerminating = false;
	private Thread writeThread;
	private Thread readThread;
	private boolean isTerminating = false;
	private String terminationReason = "";
	private Object[] field_20101_t;
	private int timeSinceLastRead = 0;
	private int sendQueueByteLength = 0;
	public int chunkDataSendCounter = 0;
	private int field_20100_w = 0;

	public NetworkManager(Socket socket1, String string2, NetHandler netHandler3) throws IOException {
		this.field_12258_e = socket1;
		this.networkSocket = socket1.getRemoteSocketAddress();
		this.netHandler = netHandler3;
		socket1.setTrafficClass(24);
		this.socketInputStream = new DataInputStream(socket1.getInputStream());
		this.socketOutputStream = new DataOutputStream(socket1.getOutputStream());
		this.readThread = new NetworkReaderThread(this, string2 + " read thread");
		this.writeThread = new NetworkWriterThread(this, string2 + " write thread");
		this.readThread.start();
		this.writeThread.start();
	}

	public void addToSendQueue(Packet packet1) {
		if(!this.isServerTerminating) {
			Object object2 = this.sendQueueLock;
			synchronized(this.sendQueueLock) {
				this.sendQueueByteLength += packet1.getPacketSize() + 1;
				if(packet1.isChunkDataPacket) {
					this.chunkDataPackets.add(packet1);
				} else {
					this.dataPackets.add(packet1);
				}

			}
		}
	}

	private void sendPacket() {
		try {
			boolean z1 = true;
			Packet packet2;
			Object object3;
			if(!this.dataPackets.isEmpty() && (this.chunkDataSendCounter == 0 || System.currentTimeMillis() - ((Packet)this.dataPackets.get(0)).field_20018_j >= (long)this.chunkDataSendCounter)) {
				z1 = false;
				object3 = this.sendQueueLock;
				synchronized(this.sendQueueLock) {
					packet2 = (Packet)this.dataPackets.remove(0);
					this.sendQueueByteLength -= packet2.getPacketSize() + 1;
				}

				Packet.writePacket(packet2, this.socketOutputStream);
			}

			if((z1 || this.field_20100_w-- <= 0) && !this.chunkDataPackets.isEmpty() && (this.chunkDataSendCounter == 0 || System.currentTimeMillis() - ((Packet)this.chunkDataPackets.get(0)).field_20018_j >= (long)this.chunkDataSendCounter)) {
				z1 = false;
				object3 = this.sendQueueLock;
				synchronized(this.sendQueueLock) {
					packet2 = (Packet)this.chunkDataPackets.remove(0);
					this.sendQueueByteLength -= packet2.getPacketSize() + 1;
				}

				Packet.writePacket(packet2, this.socketOutputStream);
				this.field_20100_w = 50;
			}

			if(z1) {
				Thread.sleep(10L);
			}
		} catch (InterruptedException interruptedException8) {
		} catch (Exception exception9) {
			if(!this.isTerminating) {
				this.onNetworkError(exception9);
			}
		}

	}

	private void readPacket() {
		try {
			Packet packet1 = Packet.readPacket(this.socketInputStream);
			if(packet1 != null) {
				this.readPackets.add(packet1);
			} else {
				this.networkShutdown("disconnect.endOfStream", new Object[0]);
			}
		} catch (Exception exception2) {
			if(!this.isTerminating) {
				this.onNetworkError(exception2);
			}
		}

	}

	private void onNetworkError(Exception exception1) {
		exception1.printStackTrace();
		this.networkShutdown("disconnect.genericReason", new Object[]{"Internal exception: " + exception1.toString()});
	}

	public void networkShutdown(String string1, Object... object2) {
		if(this.isRunning) {
			this.isTerminating = true;
			this.terminationReason = string1;
			this.field_20101_t = object2;
			(new NetworkMasterThread(this)).start();
			this.isRunning = false;

			try {
				this.socketInputStream.close();
				this.socketInputStream = null;
			} catch (Throwable throwable6) {
			}

			try {
				this.socketOutputStream.close();
				this.socketOutputStream = null;
			} catch (Throwable throwable5) {
			}

			try {
				this.field_12258_e.close();
				this.field_12258_e = null;
			} catch (Throwable throwable4) {
			}

		}
	}

	public void processReadPackets() {
		if(this.sendQueueByteLength > 1048576) {
			this.networkShutdown("disconnect.overflow", new Object[0]);
		}

		if(this.readPackets.isEmpty()) {
			if(this.timeSinceLastRead++ == 1200) {
				this.networkShutdown("disconnect.timeout", new Object[0]);
			}
		} else {
			this.timeSinceLastRead = 0;
		}

		int i1 = 100;

		while(!this.readPackets.isEmpty() && i1-- >= 0) {
			Packet packet2 = (Packet)this.readPackets.remove(0);
			packet2.processPacket(this.netHandler);
		}

		if(this.isTerminating && this.readPackets.isEmpty()) {
			this.netHandler.handleErrorMessage(this.terminationReason, this.field_20101_t);
		}

	}

	static boolean isRunning(NetworkManager networkManager0) {
		return networkManager0.isRunning;
	}

	static boolean isServerTerminating(NetworkManager networkManager0) {
		return networkManager0.isServerTerminating;
	}

	static void readNetworkPacket(NetworkManager networkManager0) {
		networkManager0.readPacket();
	}

	static void sendNetworkPacket(NetworkManager networkManager0) {
		networkManager0.sendPacket();
	}

	static Thread getReadThread(NetworkManager networkManager0) {
		return networkManager0.readThread;
	}

	static Thread getWriteThread(NetworkManager networkManager0) {
		return networkManager0.writeThread;
	}
}
