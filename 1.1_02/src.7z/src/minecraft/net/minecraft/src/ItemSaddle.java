package net.minecraft.src;

public class ItemSaddle extends Item {
	public ItemSaddle(int i1) {
		super(i1);
		this.maxStackSize = 1;
		this.maxDamage = 64;
	}

	public void func_4019_b(ItemStack itemStack1, EntityLiving entityLiving2) {
		if(entityLiving2 instanceof EntityPig) {
			EntityPig entityPig3 = (EntityPig)entityLiving2;
			if(!entityPig3.rideable) {
				entityPig3.rideable = true;
				--itemStack1.stackSize;
			}
		}

	}

	public void hitEntity(ItemStack itemStack1, EntityLiving entityLiving2) {
		this.func_4019_b(itemStack1, entityLiving2);
	}
}
