package net.minecraft.src;

public class EntityGhast extends EntityFlying implements IMobs {
	public int field_4121_a = 0;
	public double field_4120_b;
	public double field_4127_c;
	public double field_4126_d;
	private Entity field_4123_g = null;
	private int field_4122_h = 0;
	public int field_4125_e = 0;
	public int field_4124_f = 0;

	public EntityGhast(World world1) {
		super(world1);
		this.texture = "/mob/ghast.png";
		this.setSize(4.0F, 4.0F);
		this.isImmuneToFire = true;
	}

	protected void updatePlayerActionState() {
		if(this.worldObj.difficultySetting == 0) {
			this.setEntityDead();
		}

		this.field_4125_e = this.field_4124_f;
		double d1 = this.field_4120_b - this.posX;
		double d3 = this.field_4127_c - this.posY;
		double d5 = this.field_4126_d - this.posZ;
		double d7 = (double)MathHelper.sqrt_double(d1 * d1 + d3 * d3 + d5 * d5);
		if(d7 < 1.0D || d7 > 60.0D) {
			this.field_4120_b = this.posX + (double)((this.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
			this.field_4127_c = this.posY + (double)((this.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
			this.field_4126_d = this.posZ + (double)((this.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
		}

		if(this.field_4121_a-- <= 0) {
			this.field_4121_a += this.rand.nextInt(5) + 2;
			if(this.func_4050_a(this.field_4120_b, this.field_4127_c, this.field_4126_d, d7)) {
				this.motionX += d1 / d7 * 0.1D;
				this.motionY += d3 / d7 * 0.1D;
				this.motionZ += d5 / d7 * 0.1D;
			} else {
				this.field_4120_b = this.posX;
				this.field_4127_c = this.posY;
				this.field_4126_d = this.posZ;
			}
		}

		if(this.field_4123_g != null && this.field_4123_g.isDead) {
			this.field_4123_g = null;
		}

		if(this.field_4123_g == null || this.field_4122_h-- <= 0) {
			this.field_4123_g = this.worldObj.getClosestPlayerToEntity(this, 100.0D);
			if(this.field_4123_g != null) {
				this.field_4122_h = 20;
			}
		}

		double d9 = 64.0D;
		if(this.field_4123_g != null && this.field_4123_g.getDistanceSqToEntity(this) < d9 * d9) {
			double d11 = this.field_4123_g.posX - this.posX;
			double d13 = this.field_4123_g.boundingBox.minY + (double)(this.field_4123_g.height / 2.0F) - (this.posY + (double)(this.height / 2.0F));
			double d15 = this.field_4123_g.posZ - this.posZ;
			this.renderYawOffset = this.rotationYaw = -((float)Math.atan2(d11, d15)) * 180.0F / (float)Math.PI;
			if(this.canEntityBeSeen(this.field_4123_g)) {
				if(this.field_4124_f == 10) {
					this.worldObj.playSoundAtEntity(this, "mob.ghast.charge", this.getSoundVolume(), (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
				}

				++this.field_4124_f;
				if(this.field_4124_f == 20) {
					this.worldObj.playSoundAtEntity(this, "mob.ghast.fireball", this.getSoundVolume(), (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
					EntityFireball entityFireball17 = new EntityFireball(this.worldObj, this, d11, d13, d15);
					double d18 = 4.0D;
					Vec3D vec3D20 = this.getLook(1.0F);
					entityFireball17.posX = this.posX + vec3D20.xCoord * d18;
					entityFireball17.posY = this.posY + (double)(this.height / 2.0F) + 0.5D;
					entityFireball17.posZ = this.posZ + vec3D20.zCoord * d18;
					this.worldObj.entityJoinedWorld(entityFireball17);
					this.field_4124_f = -40;
				}
			} else if(this.field_4124_f > 0) {
				--this.field_4124_f;
			}
		} else {
			this.renderYawOffset = this.rotationYaw = -((float)Math.atan2(this.motionX, this.motionZ)) * 180.0F / (float)Math.PI;
			if(this.field_4124_f > 0) {
				--this.field_4124_f;
			}
		}

		this.texture = this.field_4124_f > 10 ? "/mob/ghast_fire.png" : "/mob/ghast.png";
	}

	private boolean func_4050_a(double d1, double d3, double d5, double d7) {
		double d9 = (this.field_4120_b - this.posX) / d7;
		double d11 = (this.field_4127_c - this.posY) / d7;
		double d13 = (this.field_4126_d - this.posZ) / d7;
		AxisAlignedBB axisAlignedBB15 = this.boundingBox.copy();

		for(int i16 = 1; (double)i16 < d7; ++i16) {
			axisAlignedBB15.offset(d9, d11, d13);
			if(this.worldObj.getCollidingBoundingBoxes(this, axisAlignedBB15).size() > 0) {
				return false;
			}
		}

		return true;
	}

	protected String getLivingSound() {
		return "mob.ghast.moan";
	}

	protected String getHurtSound() {
		return "mob.ghast.scream";
	}

	protected String getDeathSound() {
		return "mob.ghast.death";
	}

	protected int getDropItemId() {
		return Item.gunpowder.shiftedIndex;
	}

	protected float getSoundVolume() {
		return 10.0F;
	}

	public boolean getCanSpawnHere() {
		return this.rand.nextInt(20) == 0 && super.getCanSpawnHere() && this.worldObj.difficultySetting > 0;
	}

	public int getMaxSpawnedInChunk() {
		return 1;
	}
}
