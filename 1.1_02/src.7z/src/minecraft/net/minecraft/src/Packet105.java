package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet105 extends Packet {
	public int field_20032_a;
	public int field_20031_b;
	public int field_20033_c;

	public void processPacket(NetHandler netHandler1) {
		netHandler1.func_20090_a(this);
	}

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.field_20032_a = dataInputStream1.readByte();
		this.field_20031_b = dataInputStream1.readShort();
		this.field_20033_c = dataInputStream1.readShort();
	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeByte(this.field_20032_a);
		dataOutputStream1.writeShort(this.field_20031_b);
		dataOutputStream1.writeShort(this.field_20033_c);
	}

	public int getPacketSize() {
		return 5;
	}
}
