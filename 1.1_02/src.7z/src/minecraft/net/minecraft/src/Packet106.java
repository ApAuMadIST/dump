package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet106 extends Packet {
	public int field_20029_a;
	public short field_20028_b;
	public boolean field_20030_c;

	public Packet106() {
	}

	public Packet106(int i1, short s2, boolean z3) {
		this.field_20029_a = i1;
		this.field_20028_b = s2;
		this.field_20030_c = z3;
	}

	public void processPacket(NetHandler netHandler1) {
		netHandler1.func_20089_a(this);
	}

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.field_20029_a = dataInputStream1.readByte();
		this.field_20028_b = dataInputStream1.readShort();
		this.field_20030_c = dataInputStream1.readByte() != 0;
	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeByte(this.field_20029_a);
		dataOutputStream1.writeShort(this.field_20028_b);
		dataOutputStream1.writeByte(this.field_20030_c ? 1 : 0);
	}

	public int getPacketSize() {
		return 4;
	}
}
