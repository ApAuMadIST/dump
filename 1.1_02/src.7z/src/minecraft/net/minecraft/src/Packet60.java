package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Packet60 extends Packet {
	public double field_12236_a;
	public double field_12235_b;
	public double field_12239_c;
	public float field_12238_d;
	public Set field_12237_e;

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.field_12236_a = dataInputStream1.readDouble();
		this.field_12235_b = dataInputStream1.readDouble();
		this.field_12239_c = dataInputStream1.readDouble();
		this.field_12238_d = dataInputStream1.readFloat();
		int i2 = dataInputStream1.readInt();
		this.field_12237_e = new HashSet();
		int i3 = (int)this.field_12236_a;
		int i4 = (int)this.field_12235_b;
		int i5 = (int)this.field_12239_c;

		for(int i6 = 0; i6 < i2; ++i6) {
			int i7 = dataInputStream1.readByte() + i3;
			int i8 = dataInputStream1.readByte() + i4;
			int i9 = dataInputStream1.readByte() + i5;
			this.field_12237_e.add(new ChunkPosition(i7, i8, i9));
		}

	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeDouble(this.field_12236_a);
		dataOutputStream1.writeDouble(this.field_12235_b);
		dataOutputStream1.writeDouble(this.field_12239_c);
		dataOutputStream1.writeFloat(this.field_12238_d);
		dataOutputStream1.writeInt(this.field_12237_e.size());
		int i2 = (int)this.field_12236_a;
		int i3 = (int)this.field_12235_b;
		int i4 = (int)this.field_12239_c;
		Iterator iterator5 = this.field_12237_e.iterator();

		while(iterator5.hasNext()) {
			ChunkPosition chunkPosition6 = (ChunkPosition)iterator5.next();
			int i7 = chunkPosition6.x - i2;
			int i8 = chunkPosition6.y - i3;
			int i9 = chunkPosition6.z - i4;
			dataOutputStream1.writeByte(i7);
			dataOutputStream1.writeByte(i8);
			dataOutputStream1.writeByte(i9);
		}

	}

	public void processPacket(NetHandler netHandler1) {
		netHandler1.func_12245_a(this);
	}

	public int getPacketSize() {
		return 32 + this.field_12237_e.size() * 3;
	}
}
