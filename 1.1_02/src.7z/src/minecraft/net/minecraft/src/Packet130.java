package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet130 extends Packet {
	public int field_20020_a;
	public int field_20019_b;
	public int field_20022_c;
	public String[] field_20021_d;

	public Packet130() {
		this.isChunkDataPacket = true;
	}

	public Packet130(int i1, int i2, int i3, String[] string4) {
		this.isChunkDataPacket = true;
		this.field_20020_a = i1;
		this.field_20019_b = i2;
		this.field_20022_c = i3;
		this.field_20021_d = string4;
	}

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.field_20020_a = dataInputStream1.readInt();
		this.field_20019_b = dataInputStream1.readShort();
		this.field_20022_c = dataInputStream1.readInt();
		this.field_20021_d = new String[4];

		for(int i2 = 0; i2 < 4; ++i2) {
			this.field_20021_d[i2] = dataInputStream1.readUTF();
		}

	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeInt(this.field_20020_a);
		dataOutputStream1.writeShort(this.field_20019_b);
		dataOutputStream1.writeInt(this.field_20022_c);

		for(int i2 = 0; i2 < 4; ++i2) {
			dataOutputStream1.writeUTF(this.field_20021_d[i2]);
		}

	}

	public void processPacket(NetHandler netHandler1) {
		netHandler1.func_20093_a(this);
	}

	public int getPacketSize() {
		int i1 = 0;

		for(int i2 = 0; i2 < 4; ++i2) {
			i1 += this.field_20021_d[i2].length();
		}

		return i1;
	}
}
