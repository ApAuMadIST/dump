package net.minecraft.src;

public class ModelSlime extends ModelBase {
	ModelRenderer field_1258_a;
	ModelRenderer field_1257_b;
	ModelRenderer field_1260_c;
	ModelRenderer field_1259_d;

	public ModelSlime(int i1) {
		this.field_1258_a = new ModelRenderer(0, i1);
		this.field_1258_a.func_921_a(-4.0F, 16.0F, -4.0F, 8, 8, 8);
		if(i1 > 0) {
			this.field_1258_a = new ModelRenderer(0, i1);
			this.field_1258_a.func_921_a(-3.0F, 17.0F, -3.0F, 6, 6, 6);
			this.field_1257_b = new ModelRenderer(32, 0);
			this.field_1257_b.func_921_a(-3.25F, 18.0F, -3.5F, 2, 2, 2);
			this.field_1260_c = new ModelRenderer(32, 4);
			this.field_1260_c.func_921_a(1.25F, 18.0F, -3.5F, 2, 2, 2);
			this.field_1259_d = new ModelRenderer(32, 8);
			this.field_1259_d.func_921_a(0.0F, 21.0F, -3.5F, 1, 1, 1);
		}

	}

	public void setRotationAngles(float f1, float f2, float f3, float f4, float f5, float f6) {
	}

	public void render(float f1, float f2, float f3, float f4, float f5, float f6) {
		this.setRotationAngles(f1, f2, f3, f4, f5, f6);
		this.field_1258_a.render(f6);
		if(this.field_1257_b != null) {
			this.field_1257_b.render(f6);
			this.field_1260_c.render(f6);
			this.field_1259_d.render(f6);
		}

	}
}
