package net.minecraft.src;

public final class ItemStack {
	public int stackSize;
	public int animationsToGo;
	public int itemID;
	public int itemDamage;

	public ItemStack(Block block1) {
		this((Block)block1, 1);
	}

	public ItemStack(Block block1, int i2) {
		this(block1.blockID, i2);
	}

	public ItemStack(Item item1) {
		this((Item)item1, 1);
	}

	public ItemStack(Item item1, int i2) {
		this(item1.shiftedIndex, i2);
	}

	public ItemStack(int i1) {
		this(i1, 1);
	}

	public ItemStack(int i1, int i2) {
		this.stackSize = 0;
		this.itemID = i1;
		this.stackSize = i2;
	}

	public ItemStack(int i1, int i2, int i3) {
		this.stackSize = 0;
		this.itemID = i1;
		this.stackSize = i2;
		this.itemDamage = i3;
	}

	public ItemStack(NBTTagCompound nBTTagCompound1) {
		this.stackSize = 0;
		this.readFromNBT(nBTTagCompound1);
	}

	public ItemStack splitStack(int i1) {
		this.stackSize -= i1;
		return new ItemStack(this.itemID, i1, this.itemDamage);
	}

	public Item getItem() {
		return Item.itemsList[this.itemID];
	}

	public int getIconIndex() {
		return this.getItem().getIconIndex(this);
	}

	public boolean useItem(EntityPlayer entityPlayer1, World world2, int i3, int i4, int i5, int i6) {
		return this.getItem().onItemUse(this, entityPlayer1, world2, i3, i4, i5, i6);
	}

	public float getStrVsBlock(Block block1) {
		return this.getItem().getStrVsBlock(this, block1);
	}

	public ItemStack useItemRightClick(World world1, EntityPlayer entityPlayer2) {
		return this.getItem().onItemRightClick(this, world1, entityPlayer2);
	}

	public NBTTagCompound writeToNBT(NBTTagCompound nBTTagCompound1) {
		nBTTagCompound1.setShort("id", (short)this.itemID);
		nBTTagCompound1.setByte("Count", (byte)this.stackSize);
		nBTTagCompound1.setShort("Damage", (short)this.itemDamage);
		return nBTTagCompound1;
	}

	public void readFromNBT(NBTTagCompound nBTTagCompound1) {
		this.itemID = nBTTagCompound1.getShort("id");
		this.stackSize = nBTTagCompound1.getByte("Count");
		this.itemDamage = nBTTagCompound1.getShort("Damage");
	}

	public int getMaxStackSize() {
		return this.getItem().getItemStackLimit();
	}

	public int getMaxDamage() {
		return Item.itemsList[this.itemID].getMaxDamage();
	}

	public void damageItem(int i1) {
		this.itemDamage += i1;
		if(this.itemDamage > this.getMaxDamage()) {
			--this.stackSize;
			if(this.stackSize < 0) {
				this.stackSize = 0;
			}

			this.itemDamage = 0;
		}

	}

	public void hitEntity(EntityLiving entityLiving1) {
		Item.itemsList[this.itemID].hitEntity(this, entityLiving1);
	}

	public void hitBlock(int i1, int i2, int i3, int i4) {
		Item.itemsList[this.itemID].hitBlock(this, i1, i2, i3, i4);
	}

	public int getDamageVsEntity(Entity entity1) {
		return Item.itemsList[this.itemID].getDamageVsEntity(entity1);
	}

	public boolean canHarvestBlock(Block block1) {
		return Item.itemsList[this.itemID].canHarvestBlock(block1);
	}

	public void func_1097_a(EntityPlayer entityPlayer1) {
	}

	public void useItemOnEntity(EntityLiving entityLiving1) {
		Item.itemsList[this.itemID].func_4019_b(this, entityLiving1);
	}

	public ItemStack copy() {
		return new ItemStack(this.itemID, this.stackSize, this.itemDamage);
	}

	public static boolean func_20107_a(ItemStack itemStack0, ItemStack itemStack1) {
		return itemStack0 == null && itemStack1 == null ? true : (itemStack0 != null && itemStack1 != null ? itemStack0.func_20108_a(itemStack1) : false);
	}

	private boolean func_20108_a(ItemStack itemStack1) {
		return this.stackSize != itemStack1.stackSize ? false : (this.itemID != itemStack1.itemID ? false : this.itemDamage == itemStack1.itemDamage);
	}

	public String func_20109_f() {
		return Item.itemsList[this.itemID].func_20009_a();
	}

	public String toString() {
		return this.stackSize + "x" + Item.itemsList[this.itemID].func_20009_a() + "@" + this.itemDamage;
	}
}
