package net.minecraft.src;

public enum EnumOS2 {
	a,
	b,
	c,
	d,
	e;
}
