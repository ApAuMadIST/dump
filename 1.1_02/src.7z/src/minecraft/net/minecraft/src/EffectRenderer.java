package net.minecraft.src;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.lwjgl.opengl.GL11;

public class EffectRenderer {
	protected World worldObj;
	private List[] field_1728_b = new List[4];
	private RenderEngine field_1731_c;
	private Random rand = new Random();

	public EffectRenderer(World world1, RenderEngine renderEngine2) {
		if(world1 != null) {
			this.worldObj = world1;
		}

		this.field_1731_c = renderEngine2;

		for(int i3 = 0; i3 < 4; ++i3) {
			this.field_1728_b[i3] = new ArrayList();
		}

	}

	public void func_1192_a(EntityFX entityFX1) {
		int i2 = entityFX1.func_404_c();
		this.field_1728_b[i2].add(entityFX1);
	}

	public void func_1193_a() {
		for(int i1 = 0; i1 < 4; ++i1) {
			for(int i2 = 0; i2 < this.field_1728_b[i1].size(); ++i2) {
				EntityFX entityFX3 = (EntityFX)this.field_1728_b[i1].get(i2);
				entityFX3.onUpdate();
				if(entityFX3.isDead) {
					this.field_1728_b[i1].remove(i2--);
				}
			}
		}

	}

	public void func_1189_a(Entity entity1, float f2) {
		float f3 = MathHelper.cos(entity1.rotationYaw * (float)Math.PI / 180.0F);
		float f4 = MathHelper.sin(entity1.rotationYaw * (float)Math.PI / 180.0F);
		float f5 = -f4 * MathHelper.sin(entity1.rotationPitch * (float)Math.PI / 180.0F);
		float f6 = f3 * MathHelper.sin(entity1.rotationPitch * (float)Math.PI / 180.0F);
		float f7 = MathHelper.cos(entity1.rotationPitch * (float)Math.PI / 180.0F);
		EntityFX.field_660_l = entity1.lastTickPosX + (entity1.posX - entity1.lastTickPosX) * (double)f2;
		EntityFX.field_659_m = entity1.lastTickPosY + (entity1.posY - entity1.lastTickPosY) * (double)f2;
		EntityFX.field_658_n = entity1.lastTickPosZ + (entity1.posZ - entity1.lastTickPosZ) * (double)f2;

		for(int i8 = 0; i8 < 3; ++i8) {
			if(this.field_1728_b[i8].size() != 0) {
				int i9 = 0;
				if(i8 == 0) {
					i9 = this.field_1731_c.getTexture("/particles.png");
				}

				if(i8 == 1) {
					i9 = this.field_1731_c.getTexture("/terrain.png");
				}

				if(i8 == 2) {
					i9 = this.field_1731_c.getTexture("/gui/items.png");
				}

				GL11.glBindTexture(GL11.GL_TEXTURE_2D, i9);
				Tessellator tessellator10 = Tessellator.instance;
				tessellator10.startDrawingQuads();

				for(int i11 = 0; i11 < this.field_1728_b[i8].size(); ++i11) {
					EntityFX entityFX12 = (EntityFX)this.field_1728_b[i8].get(i11);
					entityFX12.func_406_a(tessellator10, f2, f3, f7, f4, f5, f6);
				}

				tessellator10.draw();
			}
		}

	}

	public void func_1187_b(Entity entity1, float f2) {
		byte b3 = 3;
		if(this.field_1728_b[b3].size() != 0) {
			Tessellator tessellator4 = Tessellator.instance;

			for(int i5 = 0; i5 < this.field_1728_b[b3].size(); ++i5) {
				EntityFX entityFX6 = (EntityFX)this.field_1728_b[b3].get(i5);
				entityFX6.func_406_a(tessellator4, f2, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
			}

		}
	}

	public void func_1188_a(World world1) {
		this.worldObj = world1;

		for(int i2 = 0; i2 < 4; ++i2) {
			this.field_1728_b[i2].clear();
		}

	}

	public void func_1186_a(int i1, int i2, int i3) {
		int i4 = this.worldObj.getBlockId(i1, i2, i3);
		if(i4 != 0) {
			Block block5 = Block.blocksList[i4];
			byte b6 = 4;

			for(int i7 = 0; i7 < b6; ++i7) {
				for(int i8 = 0; i8 < b6; ++i8) {
					for(int i9 = 0; i9 < b6; ++i9) {
						double d10 = (double)i1 + ((double)i7 + 0.5D) / (double)b6;
						double d12 = (double)i2 + ((double)i8 + 0.5D) / (double)b6;
						double d14 = (double)i3 + ((double)i9 + 0.5D) / (double)b6;
						this.func_1192_a((new EntityDiggingFX(this.worldObj, d10, d12, d14, d10 - (double)i1 - 0.5D, d12 - (double)i2 - 0.5D, d14 - (double)i3 - 0.5D, block5)).func_4041_a(i1, i2, i3));
					}
				}
			}

		}
	}

	public void func_1191_a(int i1, int i2, int i3, int i4) {
		int i5 = this.worldObj.getBlockId(i1, i2, i3);
		if(i5 != 0) {
			Block block6 = Block.blocksList[i5];
			float f7 = 0.1F;
			double d8 = (double)i1 + this.rand.nextDouble() * (block6.maxX - block6.minX - (double)(f7 * 2.0F)) + (double)f7 + block6.minX;
			double d10 = (double)i2 + this.rand.nextDouble() * (block6.maxY - block6.minY - (double)(f7 * 2.0F)) + (double)f7 + block6.minY;
			double d12 = (double)i3 + this.rand.nextDouble() * (block6.maxZ - block6.minZ - (double)(f7 * 2.0F)) + (double)f7 + block6.minZ;
			if(i4 == 0) {
				d10 = (double)i2 + block6.minY - (double)f7;
			}

			if(i4 == 1) {
				d10 = (double)i2 + block6.maxY + (double)f7;
			}

			if(i4 == 2) {
				d12 = (double)i3 + block6.minZ - (double)f7;
			}

			if(i4 == 3) {
				d12 = (double)i3 + block6.maxZ + (double)f7;
			}

			if(i4 == 4) {
				d8 = (double)i1 + block6.minX - (double)f7;
			}

			if(i4 == 5) {
				d8 = (double)i1 + block6.maxX + (double)f7;
			}

			this.func_1192_a((new EntityDiggingFX(this.worldObj, d8, d10, d12, 0.0D, 0.0D, 0.0D, block6)).func_4041_a(i1, i2, i3).func_407_b(0.2F).func_405_d(0.6F));
		}
	}

	public String func_1190_b() {
		return "" + (this.field_1728_b[0].size() + this.field_1728_b[1].size() + this.field_1728_b[2].size());
	}
}
