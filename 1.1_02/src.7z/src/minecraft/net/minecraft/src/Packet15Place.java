package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet15Place extends Packet {
	public int id;
	public int xPosition;
	public int yPosition;
	public int zPosition;
	public ItemStack direction;

	public Packet15Place() {
	}

	public Packet15Place(int i1, int i2, int i3, int i4, ItemStack itemStack5) {
		this.id = i1;
		this.xPosition = i2;
		this.yPosition = i3;
		this.zPosition = i4;
		this.direction = itemStack5;
	}

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.id = dataInputStream1.readInt();
		this.xPosition = dataInputStream1.read();
		this.yPosition = dataInputStream1.readInt();
		this.zPosition = dataInputStream1.read();
		short s2 = dataInputStream1.readShort();
		if(s2 >= 0) {
			byte b3 = dataInputStream1.readByte();
			byte b4 = dataInputStream1.readByte();
			this.direction = new ItemStack(s2, b3, b4);
		} else {
			this.direction = null;
		}

	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeInt(this.id);
		dataOutputStream1.write(this.xPosition);
		dataOutputStream1.writeInt(this.yPosition);
		dataOutputStream1.write(this.zPosition);
		if(this.direction == null) {
			dataOutputStream1.writeShort(-1);
		} else {
			dataOutputStream1.writeShort(this.direction.itemID);
			dataOutputStream1.writeByte(this.direction.stackSize);
			dataOutputStream1.writeByte(this.direction.itemDamage);
		}

	}

	public void processPacket(NetHandler netHandler1) {
		netHandler1.handlePlace(this);
	}

	public int getPacketSize() {
		return 14;
	}
}
