package net.minecraft.src;

public class TexturedQuad {
	public PositionTexureVertex[] field_1195_a;
	public int field_1194_b;
	private boolean field_1196_c;

	public TexturedQuad(PositionTexureVertex[] positionTexureVertex1) {
		this.field_1194_b = 0;
		this.field_1196_c = false;
		this.field_1195_a = positionTexureVertex1;
		this.field_1194_b = positionTexureVertex1.length;
	}

	public TexturedQuad(PositionTexureVertex[] positionTexureVertex1, int i2, int i3, int i4, int i5) {
		this(positionTexureVertex1);
		float f6 = 0.0015625F;
		float f7 = 0.003125F;
		positionTexureVertex1[0] = positionTexureVertex1[0].setTexturePosition((float)i4 / 64.0F - f6, (float)i3 / 32.0F + f7);
		positionTexureVertex1[1] = positionTexureVertex1[1].setTexturePosition((float)i2 / 64.0F + f6, (float)i3 / 32.0F + f7);
		positionTexureVertex1[2] = positionTexureVertex1[2].setTexturePosition((float)i2 / 64.0F + f6, (float)i5 / 32.0F - f7);
		positionTexureVertex1[3] = positionTexureVertex1[3].setTexturePosition((float)i4 / 64.0F - f6, (float)i5 / 32.0F - f7);
	}

	public void func_809_a() {
		PositionTexureVertex[] positionTexureVertex1 = new PositionTexureVertex[this.field_1195_a.length];

		for(int i2 = 0; i2 < this.field_1195_a.length; ++i2) {
			positionTexureVertex1[i2] = this.field_1195_a[this.field_1195_a.length - i2 - 1];
		}

		this.field_1195_a = positionTexureVertex1;
	}

	public void func_808_a(Tessellator tessellator1, float f2) {
		Vec3D vec3D3 = this.field_1195_a[1].vector3D.subtract(this.field_1195_a[0].vector3D);
		Vec3D vec3D4 = this.field_1195_a[1].vector3D.subtract(this.field_1195_a[2].vector3D);
		Vec3D vec3D5 = vec3D4.crossProduct(vec3D3).normalize();
		tessellator1.startDrawingQuads();
		if(this.field_1196_c) {
			tessellator1.setNormal(-((float)vec3D5.xCoord), -((float)vec3D5.yCoord), -((float)vec3D5.zCoord));
		} else {
			tessellator1.setNormal((float)vec3D5.xCoord, (float)vec3D5.yCoord, (float)vec3D5.zCoord);
		}

		for(int i6 = 0; i6 < 4; ++i6) {
			PositionTexureVertex positionTexureVertex7 = this.field_1195_a[i6];
			tessellator1.addVertexWithUV((double)((float)positionTexureVertex7.vector3D.xCoord * f2), (double)((float)positionTexureVertex7.vector3D.yCoord * f2), (double)((float)positionTexureVertex7.vector3D.zCoord * f2), (double)positionTexureVertex7.texturePositionX, (double)positionTexureVertex7.texturePositionY);
		}

		tessellator1.draw();
	}
}
