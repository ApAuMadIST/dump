package net.minecraft.src;

public class MetadataChunkBlock {
	public final EnumSkyBlock field_1299_a;
	public int field_1298_b;
	public int field_1304_c;
	public int field_1303_d;
	public int field_1302_e;
	public int field_1301_f;
	public int field_1300_g;

	public MetadataChunkBlock(EnumSkyBlock enumSkyBlock1, int i2, int i3, int i4, int i5, int i6, int i7) {
		this.field_1299_a = enumSkyBlock1;
		this.field_1298_b = i2;
		this.field_1304_c = i3;
		this.field_1303_d = i4;
		this.field_1302_e = i5;
		this.field_1301_f = i6;
		this.field_1300_g = i7;
	}

	public void func_4127_a(World world1) {
		int i2 = this.field_1302_e - this.field_1298_b + 1;
		int i3 = this.field_1301_f - this.field_1304_c + 1;
		int i4 = this.field_1300_g - this.field_1303_d + 1;
		int i5 = i2 * i3 * i4;
		if(i5 <= 32768) {
			for(int i6 = this.field_1298_b; i6 <= this.field_1302_e; ++i6) {
				for(int i7 = this.field_1303_d; i7 <= this.field_1300_g; ++i7) {
					if(world1.blockExists(i6, 0, i7)) {
						for(int i8 = this.field_1304_c; i8 <= this.field_1301_f; ++i8) {
							if(i8 >= 0 && i8 < 128) {
								int i9 = world1.getSavedLightValue(this.field_1299_a, i6, i8, i7);
								boolean z10 = false;
								int i11 = world1.getBlockId(i6, i8, i7);
								int i12 = Block.lightOpacity[i11];
								if(i12 == 0) {
									i12 = 1;
								}

								int i13 = 0;
								if(this.field_1299_a == EnumSkyBlock.Sky) {
									if(world1.canExistingBlockSeeTheSky(i6, i8, i7)) {
										i13 = 15;
									}
								} else if(this.field_1299_a == EnumSkyBlock.Block) {
									i13 = Block.lightValue[i11];
								}

								int i14;
								int i20;
								if(i12 >= 15 && i13 == 0) {
									i20 = 0;
								} else {
									i14 = world1.getSavedLightValue(this.field_1299_a, i6 - 1, i8, i7);
									int i15 = world1.getSavedLightValue(this.field_1299_a, i6 + 1, i8, i7);
									int i16 = world1.getSavedLightValue(this.field_1299_a, i6, i8 - 1, i7);
									int i17 = world1.getSavedLightValue(this.field_1299_a, i6, i8 + 1, i7);
									int i18 = world1.getSavedLightValue(this.field_1299_a, i6, i8, i7 - 1);
									int i19 = world1.getSavedLightValue(this.field_1299_a, i6, i8, i7 + 1);
									i20 = i14;
									if(i15 > i14) {
										i20 = i15;
									}

									if(i16 > i20) {
										i20 = i16;
									}

									if(i17 > i20) {
										i20 = i17;
									}

									if(i18 > i20) {
										i20 = i18;
									}

									if(i19 > i20) {
										i20 = i19;
									}

									i20 -= i12;
									if(i20 < 0) {
										i20 = 0;
									}

									if(i13 > i20) {
										i20 = i13;
									}
								}

								if(i9 != i20) {
									world1.setLightValue(this.field_1299_a, i6, i8, i7, i20);
									i14 = i20 - 1;
									if(i14 < 0) {
										i14 = 0;
									}

									world1.neighborLightPropagationChanged(this.field_1299_a, i6 - 1, i8, i7, i14);
									world1.neighborLightPropagationChanged(this.field_1299_a, i6, i8 - 1, i7, i14);
									world1.neighborLightPropagationChanged(this.field_1299_a, i6, i8, i7 - 1, i14);
									if(i6 + 1 >= this.field_1302_e) {
										world1.neighborLightPropagationChanged(this.field_1299_a, i6 + 1, i8, i7, i14);
									}

									if(i8 + 1 >= this.field_1301_f) {
										world1.neighborLightPropagationChanged(this.field_1299_a, i6, i8 + 1, i7, i14);
									}

									if(i7 + 1 >= this.field_1300_g) {
										world1.neighborLightPropagationChanged(this.field_1299_a, i6, i8, i7 + 1, i14);
									}
								}
							}
						}
					}
				}
			}

		}
	}

	public boolean func_866_a(int i1, int i2, int i3, int i4, int i5, int i6) {
		if(i1 >= this.field_1298_b && i2 >= this.field_1304_c && i3 >= this.field_1303_d && i4 <= this.field_1302_e && i5 <= this.field_1301_f && i6 <= this.field_1300_g) {
			return true;
		} else {
			byte b7 = 1;
			if(i1 >= this.field_1298_b - b7 && i2 >= this.field_1304_c - b7 && i3 >= this.field_1303_d - b7 && i4 <= this.field_1302_e + b7 && i5 <= this.field_1301_f + b7 && i6 <= this.field_1300_g + b7) {
				int i8 = this.field_1302_e - this.field_1298_b;
				int i9 = this.field_1301_f - this.field_1304_c;
				int i10 = this.field_1300_g - this.field_1303_d;
				if(i1 > this.field_1298_b) {
					i1 = this.field_1298_b;
				}

				if(i2 > this.field_1304_c) {
					i2 = this.field_1304_c;
				}

				if(i3 > this.field_1303_d) {
					i3 = this.field_1303_d;
				}

				if(i4 < this.field_1302_e) {
					i4 = this.field_1302_e;
				}

				if(i5 < this.field_1301_f) {
					i5 = this.field_1301_f;
				}

				if(i6 < this.field_1300_g) {
					i6 = this.field_1300_g;
				}

				int i11 = i4 - i1;
				int i12 = i5 - i2;
				int i13 = i6 - i3;
				int i14 = i8 * i9 * i10;
				int i15 = i11 * i12 * i13;
				if(i15 - i14 <= 2) {
					this.field_1298_b = i1;
					this.field_1304_c = i2;
					this.field_1303_d = i3;
					this.field_1302_e = i4;
					this.field_1301_f = i5;
					this.field_1300_g = i6;
					return true;
				}
			}

			return false;
		}
	}
}
