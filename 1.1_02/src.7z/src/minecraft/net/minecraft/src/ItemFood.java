package net.minecraft.src;

public class ItemFood extends Item {
	private int a;

	public ItemFood(int i1, int i2) {
		super(i1);
		this.a = i2;
		this.maxStackSize = 1;
	}

	public ItemStack onItemRightClick(ItemStack itemStack1, World world2, EntityPlayer entityPlayer3) {
		--itemStack1.stackSize;
		entityPlayer3.heal(this.a);
		return itemStack1;
	}
}
