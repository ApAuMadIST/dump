package net.minecraft.src;

import org.lwjgl.opengl.GL11;

public class RenderZombieSimple extends RenderLiving {
	private float field_204_f;

	public RenderZombieSimple(ModelBase modelBase1, float f2, float f3) {
		super(modelBase1, f2 * f3);
		this.field_204_f = f3;
	}

	protected void a(EntityZombieSimple entityZombieSimple1, float f2) {
		GL11.glScalef(this.field_204_f, this.field_204_f, this.field_204_f);
	}

	protected void preRenderCallback(EntityLiving entityLiving1, float f2) {
		this.a((EntityZombieSimple)entityLiving1, f2);
	}
}
