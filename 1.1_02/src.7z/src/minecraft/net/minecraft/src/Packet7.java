package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet7 extends Packet {
	public int field_9277_a;
	public int field_9276_b;
	public int field_9278_c;

	public Packet7() {
	}

	public Packet7(int i1, int i2, int i3) {
		this.field_9277_a = i1;
		this.field_9276_b = i2;
		this.field_9278_c = i3;
	}

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.field_9277_a = dataInputStream1.readInt();
		this.field_9276_b = dataInputStream1.readInt();
		this.field_9278_c = dataInputStream1.readByte();
	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeInt(this.field_9277_a);
		dataOutputStream1.writeInt(this.field_9276_b);
		dataOutputStream1.writeByte(this.field_9278_c);
	}

	public void processPacket(NetHandler netHandler1) {
		netHandler1.func_6499_a(this);
	}

	public int getPacketSize() {
		return 9;
	}
}
