package net.minecraft.src;

public class EntityDiggingFX extends EntityFX {
	private Block field_4082_a;

	public EntityDiggingFX(World world1, double d2, double d4, double d6, double d8, double d10, double d12, Block block14) {
		super(world1, d2, d4, d6, d8, d10, d12);
		this.field_4082_a = block14;
		this.field_670_b = block14.blockIndexInTexture;
		this.field_664_h = block14.field_357_bm;
		this.particleRed = this.particleBlue = this.particleGreen = 0.6F;
		this.field_665_g /= 2.0F;
	}

	public EntityDiggingFX func_4041_a(int i1, int i2, int i3) {
		if(this.field_4082_a == Block.grass) {
			return this;
		} else {
			int i4 = this.field_4082_a.colorMultiplier(this.worldObj, i1, i2, i3);
			this.particleRed *= (float)(i4 >> 16 & 255) / 255.0F;
			this.particleBlue *= (float)(i4 >> 8 & 255) / 255.0F;
			this.particleGreen *= (float)(i4 & 255) / 255.0F;
			return this;
		}
	}

	public int func_404_c() {
		return 1;
	}

	public void func_406_a(Tessellator tessellator1, float f2, float f3, float f4, float f5, float f6, float f7) {
		float f8 = ((float)(this.field_670_b % 16) + this.field_669_c / 4.0F) / 16.0F;
		float f9 = f8 + 0.015609375F;
		float f10 = ((float)(this.field_670_b / 16) + this.field_668_d / 4.0F) / 16.0F;
		float f11 = f10 + 0.015609375F;
		float f12 = 0.1F * this.field_665_g;
		float f13 = (float)(this.prevPosX + (this.posX - this.prevPosX) * (double)f2 - field_660_l);
		float f14 = (float)(this.prevPosY + (this.posY - this.prevPosY) * (double)f2 - field_659_m);
		float f15 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * (double)f2 - field_658_n);
		float f16 = this.getEntityBrightness(f2);
		tessellator1.setColorOpaque_F(f16 * this.particleRed, f16 * this.particleBlue, f16 * this.particleGreen);
		tessellator1.addVertexWithUV((double)(f13 - f3 * f12 - f6 * f12), (double)(f14 - f4 * f12), (double)(f15 - f5 * f12 - f7 * f12), (double)f8, (double)f11);
		tessellator1.addVertexWithUV((double)(f13 - f3 * f12 + f6 * f12), (double)(f14 + f4 * f12), (double)(f15 - f5 * f12 + f7 * f12), (double)f8, (double)f10);
		tessellator1.addVertexWithUV((double)(f13 + f3 * f12 + f6 * f12), (double)(f14 + f4 * f12), (double)(f15 + f5 * f12 + f7 * f12), (double)f9, (double)f10);
		tessellator1.addVertexWithUV((double)(f13 + f3 * f12 - f6 * f12), (double)(f14 - f4 * f12), (double)(f15 + f5 * f12 - f7 * f12), (double)f9, (double)f11);
	}
}
