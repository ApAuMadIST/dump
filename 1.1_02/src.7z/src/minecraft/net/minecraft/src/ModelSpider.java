package net.minecraft.src;

public class ModelSpider extends ModelBase {
	public ModelRenderer field_1255_a;
	public ModelRenderer field_1254_b;
	public ModelRenderer field_1253_c;
	public ModelRenderer field_1252_d;
	public ModelRenderer field_1251_e;
	public ModelRenderer field_1250_f;
	public ModelRenderer field_1249_g;
	public ModelRenderer field_1248_h;
	public ModelRenderer field_1247_i;
	public ModelRenderer field_1246_j;
	public ModelRenderer field_1245_m;

	public ModelSpider() {
		float f1 = 0.0F;
		byte b2 = 15;
		this.field_1255_a = new ModelRenderer(32, 4);
		this.field_1255_a.addBox(-4.0F, -4.0F, -8.0F, 8, 8, 8, f1);
		this.field_1255_a.setPosition(0.0F, (float)(0 + b2), -3.0F);
		this.field_1254_b = new ModelRenderer(0, 0);
		this.field_1254_b.addBox(-3.0F, -3.0F, -3.0F, 6, 6, 6, f1);
		this.field_1254_b.setPosition(0.0F, (float)b2, 0.0F);
		this.field_1253_c = new ModelRenderer(0, 12);
		this.field_1253_c.addBox(-5.0F, -4.0F, -6.0F, 10, 8, 12, f1);
		this.field_1253_c.setPosition(0.0F, (float)(0 + b2), 9.0F);
		this.field_1252_d = new ModelRenderer(18, 0);
		this.field_1252_d.addBox(-15.0F, -1.0F, -1.0F, 16, 2, 2, f1);
		this.field_1252_d.setPosition(-4.0F, (float)(0 + b2), 2.0F);
		this.field_1251_e = new ModelRenderer(18, 0);
		this.field_1251_e.addBox(-1.0F, -1.0F, -1.0F, 16, 2, 2, f1);
		this.field_1251_e.setPosition(4.0F, (float)(0 + b2), 2.0F);
		this.field_1250_f = new ModelRenderer(18, 0);
		this.field_1250_f.addBox(-15.0F, -1.0F, -1.0F, 16, 2, 2, f1);
		this.field_1250_f.setPosition(-4.0F, (float)(0 + b2), 1.0F);
		this.field_1249_g = new ModelRenderer(18, 0);
		this.field_1249_g.addBox(-1.0F, -1.0F, -1.0F, 16, 2, 2, f1);
		this.field_1249_g.setPosition(4.0F, (float)(0 + b2), 1.0F);
		this.field_1248_h = new ModelRenderer(18, 0);
		this.field_1248_h.addBox(-15.0F, -1.0F, -1.0F, 16, 2, 2, f1);
		this.field_1248_h.setPosition(-4.0F, (float)(0 + b2), 0.0F);
		this.field_1247_i = new ModelRenderer(18, 0);
		this.field_1247_i.addBox(-1.0F, -1.0F, -1.0F, 16, 2, 2, f1);
		this.field_1247_i.setPosition(4.0F, (float)(0 + b2), 0.0F);
		this.field_1246_j = new ModelRenderer(18, 0);
		this.field_1246_j.addBox(-15.0F, -1.0F, -1.0F, 16, 2, 2, f1);
		this.field_1246_j.setPosition(-4.0F, (float)(0 + b2), -1.0F);
		this.field_1245_m = new ModelRenderer(18, 0);
		this.field_1245_m.addBox(-1.0F, -1.0F, -1.0F, 16, 2, 2, f1);
		this.field_1245_m.setPosition(4.0F, (float)(0 + b2), -1.0F);
	}

	public void render(float f1, float f2, float f3, float f4, float f5, float f6) {
		this.setRotationAngles(f1, f2, f3, f4, f5, f6);
		this.field_1255_a.render(f6);
		this.field_1254_b.render(f6);
		this.field_1253_c.render(f6);
		this.field_1252_d.render(f6);
		this.field_1251_e.render(f6);
		this.field_1250_f.render(f6);
		this.field_1249_g.render(f6);
		this.field_1248_h.render(f6);
		this.field_1247_i.render(f6);
		this.field_1246_j.render(f6);
		this.field_1245_m.render(f6);
	}

	public void setRotationAngles(float f1, float f2, float f3, float f4, float f5, float f6) {
		this.field_1255_a.rotateAngleY = f4 / 57.295776F;
		this.field_1255_a.rotateAngleX = f5 / 57.295776F;
		float f7 = 0.7853982F;
		this.field_1252_d.rotateAngleZ = -f7;
		this.field_1251_e.rotateAngleZ = f7;
		this.field_1250_f.rotateAngleZ = -f7 * 0.74F;
		this.field_1249_g.rotateAngleZ = f7 * 0.74F;
		this.field_1248_h.rotateAngleZ = -f7 * 0.74F;
		this.field_1247_i.rotateAngleZ = f7 * 0.74F;
		this.field_1246_j.rotateAngleZ = -f7;
		this.field_1245_m.rotateAngleZ = f7;
		float f8 = -0.0F;
		float f9 = 0.3926991F;
		this.field_1252_d.rotateAngleY = f9 * 2.0F + f8;
		this.field_1251_e.rotateAngleY = -f9 * 2.0F - f8;
		this.field_1250_f.rotateAngleY = f9 * 1.0F + f8;
		this.field_1249_g.rotateAngleY = -f9 * 1.0F - f8;
		this.field_1248_h.rotateAngleY = -f9 * 1.0F + f8;
		this.field_1247_i.rotateAngleY = f9 * 1.0F - f8;
		this.field_1246_j.rotateAngleY = -f9 * 2.0F + f8;
		this.field_1245_m.rotateAngleY = f9 * 2.0F - f8;
		float f10 = -(MathHelper.cos(f1 * 0.6662F * 2.0F + 0.0F) * 0.4F) * f2;
		float f11 = -(MathHelper.cos(f1 * 0.6662F * 2.0F + (float)Math.PI) * 0.4F) * f2;
		float f12 = -(MathHelper.cos(f1 * 0.6662F * 2.0F + (float)Math.PI / 2F) * 0.4F) * f2;
		float f13 = -(MathHelper.cos(f1 * 0.6662F * 2.0F + 4.712389F) * 0.4F) * f2;
		float f14 = Math.abs(MathHelper.sin(f1 * 0.6662F + 0.0F) * 0.4F) * f2;
		float f15 = Math.abs(MathHelper.sin(f1 * 0.6662F + (float)Math.PI) * 0.4F) * f2;
		float f16 = Math.abs(MathHelper.sin(f1 * 0.6662F + (float)Math.PI / 2F) * 0.4F) * f2;
		float f17 = Math.abs(MathHelper.sin(f1 * 0.6662F + 4.712389F) * 0.4F) * f2;
		this.field_1252_d.rotateAngleY += f10;
		this.field_1251_e.rotateAngleY += -f10;
		this.field_1250_f.rotateAngleY += f11;
		this.field_1249_g.rotateAngleY += -f11;
		this.field_1248_h.rotateAngleY += f12;
		this.field_1247_i.rotateAngleY += -f12;
		this.field_1246_j.rotateAngleY += f13;
		this.field_1245_m.rotateAngleY += -f13;
		this.field_1252_d.rotateAngleZ += f14;
		this.field_1251_e.rotateAngleZ += -f14;
		this.field_1250_f.rotateAngleZ += f15;
		this.field_1249_g.rotateAngleZ += -f15;
		this.field_1248_h.rotateAngleZ += f16;
		this.field_1247_i.rotateAngleZ += -f16;
		this.field_1246_j.rotateAngleZ += f17;
		this.field_1245_m.rotateAngleZ += -f17;
	}
}
