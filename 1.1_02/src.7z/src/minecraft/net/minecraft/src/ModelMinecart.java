package net.minecraft.src;

public class ModelMinecart extends ModelBase {
	public ModelRenderer[] field_1256_a = new ModelRenderer[7];

	public ModelMinecart() {
		this.field_1256_a[0] = new ModelRenderer(0, 10);
		this.field_1256_a[1] = new ModelRenderer(0, 0);
		this.field_1256_a[2] = new ModelRenderer(0, 0);
		this.field_1256_a[3] = new ModelRenderer(0, 0);
		this.field_1256_a[4] = new ModelRenderer(0, 0);
		this.field_1256_a[5] = new ModelRenderer(44, 10);
		byte b1 = 20;
		byte b2 = 8;
		byte b3 = 16;
		byte b4 = 4;
		this.field_1256_a[0].addBox((float)(-b1 / 2), (float)(-b3 / 2), -1.0F, b1, b3, 2, 0.0F);
		this.field_1256_a[0].setPosition(0.0F, (float)(0 + b4), 0.0F);
		this.field_1256_a[5].addBox((float)(-b1 / 2 + 1), (float)(-b3 / 2 + 1), -1.0F, b1 - 2, b3 - 2, 1, 0.0F);
		this.field_1256_a[5].setPosition(0.0F, (float)(0 + b4), 0.0F);
		this.field_1256_a[1].addBox((float)(-b1 / 2 + 2), (float)(-b2 - 1), -1.0F, b1 - 4, b2, 2, 0.0F);
		this.field_1256_a[1].setPosition((float)(-b1 / 2 + 1), (float)(0 + b4), 0.0F);
		this.field_1256_a[2].addBox((float)(-b1 / 2 + 2), (float)(-b2 - 1), -1.0F, b1 - 4, b2, 2, 0.0F);
		this.field_1256_a[2].setPosition((float)(b1 / 2 - 1), (float)(0 + b4), 0.0F);
		this.field_1256_a[3].addBox((float)(-b1 / 2 + 2), (float)(-b2 - 1), -1.0F, b1 - 4, b2, 2, 0.0F);
		this.field_1256_a[3].setPosition(0.0F, (float)(0 + b4), (float)(-b3 / 2 + 1));
		this.field_1256_a[4].addBox((float)(-b1 / 2 + 2), (float)(-b2 - 1), -1.0F, b1 - 4, b2, 2, 0.0F);
		this.field_1256_a[4].setPosition(0.0F, (float)(0 + b4), (float)(b3 / 2 - 1));
		this.field_1256_a[0].rotateAngleX = (float)Math.PI / 2F;
		this.field_1256_a[1].rotateAngleY = 4.712389F;
		this.field_1256_a[2].rotateAngleY = (float)Math.PI / 2F;
		this.field_1256_a[3].rotateAngleY = (float)Math.PI;
		this.field_1256_a[5].rotateAngleX = -1.5707964F;
	}

	public void render(float f1, float f2, float f3, float f4, float f5, float f6) {
		this.field_1256_a[5].offsetY = 4.0F - f3;

		for(int i7 = 0; i7 < 6; ++i7) {
			this.field_1256_a[i7].render(f6);
		}

	}

	public void setRotationAngles(float f1, float f2, float f3, float f4, float f5, float f6) {
	}
}
