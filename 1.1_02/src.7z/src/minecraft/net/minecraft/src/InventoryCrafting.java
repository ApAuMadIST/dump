package net.minecraft.src;

public class InventoryCrafting implements IInventory {
	private ItemStack[] stackList;
	private int nbrSlots;
	private CraftingInventoryCB eventHandler;

	public InventoryCrafting(CraftingInventoryCB craftingInventoryCB1, int i2, int i3) {
		this.nbrSlots = i2 * i3;
		this.stackList = new ItemStack[this.nbrSlots];
		this.eventHandler = craftingInventoryCB1;
	}

	public int getSizeInventory() {
		return this.nbrSlots;
	}

	public ItemStack getStackInSlot(int i1) {
		return this.stackList[i1];
	}

	public String getInvName() {
		return "Crafting";
	}

	public ItemStack decrStackSize(int i1, int i2) {
		if(this.stackList[i1] != null) {
			ItemStack itemStack3;
			if(this.stackList[i1].stackSize <= i2) {
				itemStack3 = this.stackList[i1];
				this.stackList[i1] = null;
				this.eventHandler.onCraftMatrixChanged(this);
				return itemStack3;
			} else {
				itemStack3 = this.stackList[i1].splitStack(i2);
				if(this.stackList[i1].stackSize == 0) {
					this.stackList[i1] = null;
				}

				this.eventHandler.onCraftMatrixChanged(this);
				return itemStack3;
			}
		} else {
			return null;
		}
	}

	public void setInventorySlotContents(int i1, ItemStack itemStack2) {
		this.stackList[i1] = itemStack2;
		this.eventHandler.onCraftMatrixChanged(this);
	}

	public int getInventoryStackLimit() {
		return 64;
	}

	public void onInventoryChanged() {
	}

	public boolean func_20070_a_(EntityPlayer entityPlayer1) {
		return true;
	}
}
