package net.minecraft.src;

public class CraftingInventoryWorkbenchCB extends CraftingInventoryCB {
	public InventoryCrafting a = new InventoryCrafting(this, 3, 3);
	public IInventory b = new InventoryCraftResult();
	private World field_20133_c;
	private int field_20132_h;
	private int field_20131_i;
	private int field_20130_j;

	public CraftingInventoryWorkbenchCB(InventoryPlayer inventoryPlayer1, World world2, int i3, int i4, int i5) {
		this.field_20133_c = world2;
		this.field_20132_h = i3;
		this.field_20131_i = i4;
		this.field_20130_j = i5;
		this.func_20117_a(new SlotCrafting(this.a, this.b, 0, 124, 35));

		int i6;
		int i7;
		for(i6 = 0; i6 < 3; ++i6) {
			for(i7 = 0; i7 < 3; ++i7) {
				this.func_20117_a(new Slot(this.a, i7 + i6 * 3, 30 + i7 * 18, 17 + i6 * 18));
			}
		}

		for(i6 = 0; i6 < 3; ++i6) {
			for(i7 = 0; i7 < 9; ++i7) {
				this.func_20117_a(new Slot(inventoryPlayer1, i7 + i6 * 9 + 9, 8 + i7 * 18, 84 + i6 * 18));
			}
		}

		for(i6 = 0; i6 < 9; ++i6) {
			this.func_20117_a(new Slot(inventoryPlayer1, i6, 8 + i6 * 18, 142));
		}

		this.onCraftMatrixChanged(this.a);
	}

	public void onCraftMatrixChanged(IInventory iInventory1) {
		int[] i2 = new int[9];

		for(int i3 = 0; i3 < 3; ++i3) {
			for(int i4 = 0; i4 < 3; ++i4) {
				int i5 = i3 + i4 * 3;
				ItemStack itemStack6 = this.a.getStackInSlot(i5);
				if(itemStack6 == null) {
					i2[i5] = -1;
				} else {
					i2[i5] = itemStack6.itemID;
				}
			}
		}

		this.b.setInventorySlotContents(0, CraftingManager.getInstance().craft(i2));
	}

	public void onCraftGuiClosed(EntityPlayer entityPlayer1) {
		super.onCraftGuiClosed(entityPlayer1);

		for(int i2 = 0; i2 < 9; ++i2) {
			ItemStack itemStack3 = this.a.getStackInSlot(i2);
			if(itemStack3 != null) {
				entityPlayer1.dropPlayerItem(itemStack3);
			}
		}

	}

	public boolean func_20120_b(EntityPlayer entityPlayer1) {
		return this.field_20133_c.getBlockId(this.field_20132_h, this.field_20131_i, this.field_20130_j) != Block.workbench.blockID ? false : entityPlayer1.getDistanceSq((double)this.field_20132_h + 0.5D, (double)this.field_20131_i + 0.5D, (double)this.field_20130_j + 0.5D) <= 64.0D;
	}
}
