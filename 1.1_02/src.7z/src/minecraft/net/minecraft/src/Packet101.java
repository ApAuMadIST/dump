package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet101 extends Packet {
	public int field_20034_a;

	public Packet101() {
	}

	public Packet101(int i1) {
		this.field_20034_a = i1;
	}

	public void processPacket(NetHandler netHandler1) {
		netHandler1.func_20092_a(this);
	}

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.field_20034_a = dataInputStream1.readByte();
	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeByte(this.field_20034_a);
	}

	public int getPacketSize() {
		return 1;
	}
}
