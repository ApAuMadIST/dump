package net.minecraft.src;

public class MovementInput {
	public float moveStrafe = 0.0F;
	public float moveForward = 0.0F;
	public boolean field_1177_c = false;
	public boolean jump = false;
	public boolean sneak = false;

	public void updatePlayerMoveState(EntityPlayer entityPlayer1) {
	}

	public void resetKeyState() {
	}

	public void checkKeyForMovementInput(int i1, boolean z2) {
	}
}
