package net.minecraft.src;

import java.nio.FloatBuffer;
import java.util.List;
import java.util.Random;

import net.minecraft.client.Minecraft;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.util.glu.GLU;

public class EntityRenderer {
	private Minecraft mc;
	private float farPlaneDistance = 0.0F;
	public ItemRenderer itemRenderer;
	private int field_1386_j;
	private Entity field_1385_k = null;
	private long field_1384_l = System.currentTimeMillis();
	private Random random = new Random();
	volatile int field_1394_b = 0;
	volatile int field_1393_c = 0;
	FloatBuffer field_1392_d = GLAllocation.createDirectFloatBuffer(16);
	float field_4270_e;
	float field_4269_f;
	float field_4268_g;
	private float field_1382_n;
	private float field_1381_o;

	public EntityRenderer(Minecraft minecraft1) {
		this.mc = minecraft1;
		this.itemRenderer = new ItemRenderer(minecraft1);
	}

	public void func_911_a() {
		this.field_1382_n = this.field_1381_o;
		float f1 = this.mc.theWorld.getLightBrightness(MathHelper.floor_double(this.mc.thePlayer.posX), MathHelper.floor_double(this.mc.thePlayer.posY), MathHelper.floor_double(this.mc.thePlayer.posZ));
		float f2 = (float)(3 - this.mc.gameSettings.renderDistance) / 3.0F;
		float f3 = f1 * (1.0F - f2) + f2;
		this.field_1381_o += (f3 - this.field_1381_o) * 0.1F;
		++this.field_1386_j;
		this.itemRenderer.func_895_a();
		if(this.mc.isFancyGraphics) {
			this.renderFancyGraphics();
		}

	}

	public void getMouseOver(float f1) {
		if(this.mc.thePlayer != null) {
			double d2 = (double)this.mc.playerController.getBlockReachDistance();
			this.mc.objectMouseOver = this.mc.thePlayer.rayTrace(d2, f1);
			double d4 = d2;
			Vec3D vec3D6 = this.mc.thePlayer.getPosition(f1);
			if(this.mc.objectMouseOver != null) {
				d4 = this.mc.objectMouseOver.hitVec.distanceTo(vec3D6);
			}

			if(this.mc.playerController instanceof PlayerControllerTest) {
				d2 = 32.0D;
				d4 = 32.0D;
			} else {
				if(d4 > 3.0D) {
					d4 = 3.0D;
				}

				d2 = d4;
			}

			Vec3D vec3D7 = this.mc.thePlayer.getLook(f1);
			Vec3D vec3D8 = vec3D6.addVector(vec3D7.xCoord * d2, vec3D7.yCoord * d2, vec3D7.zCoord * d2);
			this.field_1385_k = null;
			float f9 = 1.0F;
			List list10 = this.mc.theWorld.getEntitiesWithinAABBExcludingEntity(this.mc.thePlayer, this.mc.thePlayer.boundingBox.addCoord(vec3D7.xCoord * d2, vec3D7.yCoord * d2, vec3D7.zCoord * d2).expand((double)f9, (double)f9, (double)f9));
			double d11 = 0.0D;

			for(int i13 = 0; i13 < list10.size(); ++i13) {
				Entity entity14 = (Entity)list10.get(i13);
				if(entity14.canBeCollidedWith()) {
					float f15 = entity14.func_4035_j_();
					AxisAlignedBB axisAlignedBB16 = entity14.boundingBox.expand((double)f15, (double)f15, (double)f15);
					MovingObjectPosition movingObjectPosition17 = axisAlignedBB16.func_1169_a(vec3D6, vec3D8);
					if(axisAlignedBB16.isVecInside(vec3D6)) {
						if(0.0D < d11 || d11 == 0.0D) {
							this.field_1385_k = entity14;
							d11 = 0.0D;
						}
					} else if(movingObjectPosition17 != null) {
						double d18 = vec3D6.distanceTo(movingObjectPosition17.hitVec);
						if(d18 < d11 || d11 == 0.0D) {
							this.field_1385_k = entity14;
							d11 = d18;
						}
					}
				}
			}

			if(this.field_1385_k != null && !(this.mc.playerController instanceof PlayerControllerTest)) {
				this.mc.objectMouseOver = new MovingObjectPosition(this.field_1385_k);
			}

		}
	}

	private float func_914_d(float f1) {
		EntityPlayerSP entityPlayerSP2 = this.mc.thePlayer;
		float f3 = 70.0F;
		if(entityPlayerSP2.isInsideOfMaterial(Material.water)) {
			f3 = 60.0F;
		}

		if(entityPlayerSP2.health <= 0) {
			float f4 = (float)entityPlayerSP2.deathTime + f1;
			f3 /= (1.0F - 500.0F / (f4 + 500.0F)) * 2.0F + 1.0F;
		}

		return f3;
	}

	private void hurtCameraEffect(float f1) {
		EntityPlayerSP entityPlayerSP2 = this.mc.thePlayer;
		float f3 = (float)entityPlayerSP2.hurtTime - f1;
		float f4;
		if(entityPlayerSP2.health <= 0) {
			f4 = (float)entityPlayerSP2.deathTime + f1;
			GL11.glRotatef(40.0F - 8000.0F / (f4 + 200.0F), 0.0F, 0.0F, 1.0F);
		}

		if(f3 >= 0.0F) {
			f3 /= (float)entityPlayerSP2.maxHurtTime;
			f3 = MathHelper.sin(f3 * f3 * f3 * f3 * (float)Math.PI);
			f4 = entityPlayerSP2.attackedAtYaw;
			GL11.glRotatef(-f4, 0.0F, 1.0F, 0.0F);
			GL11.glRotatef(-f3 * 14.0F, 0.0F, 0.0F, 1.0F);
			GL11.glRotatef(f4, 0.0F, 1.0F, 0.0F);
		}
	}

	private void setupViewBobbing(float f1) {
		if(!this.mc.gameSettings.thirdPersonView) {
			EntityPlayerSP entityPlayerSP2 = this.mc.thePlayer;
			float f3 = entityPlayerSP2.distanceWalkedModified - entityPlayerSP2.prevDistanceWalkedModified;
			float f4 = entityPlayerSP2.distanceWalkedModified + f3 * f1;
			float f5 = entityPlayerSP2.field_775_e + (entityPlayerSP2.field_774_f - entityPlayerSP2.field_775_e) * f1;
			float f6 = entityPlayerSP2.field_9329_Q + (entityPlayerSP2.field_9328_R - entityPlayerSP2.field_9329_Q) * f1;
			GL11.glTranslatef(MathHelper.sin(f4 * (float)Math.PI) * f5 * 0.5F, -Math.abs(MathHelper.cos(f4 * (float)Math.PI) * f5), 0.0F);
			GL11.glRotatef(MathHelper.sin(f4 * (float)Math.PI) * f5 * 3.0F, 0.0F, 0.0F, 1.0F);
			GL11.glRotatef(Math.abs(MathHelper.cos(f4 * (float)Math.PI + 0.2F) * f5) * 5.0F, 1.0F, 0.0F, 0.0F);
			GL11.glRotatef(f6, 1.0F, 0.0F, 0.0F);
		}
	}

	private void orientCamera(float f1) {
		EntityPlayerSP entityPlayerSP2 = this.mc.thePlayer;
		double d3 = entityPlayerSP2.prevPosX + (entityPlayerSP2.posX - entityPlayerSP2.prevPosX) * (double)f1;
		double d5 = entityPlayerSP2.prevPosY + (entityPlayerSP2.posY - entityPlayerSP2.prevPosY) * (double)f1;
		double d7 = entityPlayerSP2.prevPosZ + (entityPlayerSP2.posZ - entityPlayerSP2.prevPosZ) * (double)f1;
		if(this.mc.gameSettings.thirdPersonView) {
			double d9 = 4.0D;
			float f11 = entityPlayerSP2.rotationYaw;
			float f12 = entityPlayerSP2.rotationPitch;
			if(Keyboard.isKeyDown(Keyboard.KEY_F1)) {
				f12 += 180.0F;
				d9 += 2.0D;
			}

			double d13 = (double)(-MathHelper.sin(f11 / 180.0F * (float)Math.PI) * MathHelper.cos(f12 / 180.0F * (float)Math.PI)) * d9;
			double d15 = (double)(MathHelper.cos(f11 / 180.0F * (float)Math.PI) * MathHelper.cos(f12 / 180.0F * (float)Math.PI)) * d9;
			double d17 = (double)(-MathHelper.sin(f12 / 180.0F * (float)Math.PI)) * d9;

			for(int i19 = 0; i19 < 8; ++i19) {
				float f20 = (float)((i19 & 1) * 2 - 1);
				float f21 = (float)((i19 >> 1 & 1) * 2 - 1);
				float f22 = (float)((i19 >> 2 & 1) * 2 - 1);
				f20 *= 0.1F;
				f21 *= 0.1F;
				f22 *= 0.1F;
				MovingObjectPosition movingObjectPosition23 = this.mc.theWorld.rayTraceBlocks(Vec3D.createVector(d3 + (double)f20, d5 + (double)f21, d7 + (double)f22), Vec3D.createVector(d3 - d13 + (double)f20 + (double)f22, d5 - d17 + (double)f21, d7 - d15 + (double)f22));
				if(movingObjectPosition23 != null) {
					double d24 = movingObjectPosition23.hitVec.distanceTo(Vec3D.createVector(d3, d5, d7));
					if(d24 < d9) {
						d9 = d24;
					}
				}
			}

			if(Keyboard.isKeyDown(Keyboard.KEY_F1)) {
				GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
			}

			GL11.glRotatef(entityPlayerSP2.rotationPitch - f12, 1.0F, 0.0F, 0.0F);
			GL11.glRotatef(entityPlayerSP2.rotationYaw - f11, 0.0F, 1.0F, 0.0F);
			GL11.glTranslatef(0.0F, 0.0F, (float)(-d9));
			GL11.glRotatef(f11 - entityPlayerSP2.rotationYaw, 0.0F, 1.0F, 0.0F);
			GL11.glRotatef(f12 - entityPlayerSP2.rotationPitch, 1.0F, 0.0F, 0.0F);
		} else {
			GL11.glTranslatef(0.0F, 0.0F, -0.1F);
		}

		GL11.glRotatef(entityPlayerSP2.prevRotationPitch + (entityPlayerSP2.rotationPitch - entityPlayerSP2.prevRotationPitch) * f1, 1.0F, 0.0F, 0.0F);
		GL11.glRotatef(entityPlayerSP2.prevRotationYaw + (entityPlayerSP2.rotationYaw - entityPlayerSP2.prevRotationYaw) * f1 + 180.0F, 0.0F, 1.0F, 0.0F);
	}

	private void setupCameraTransform(float f1, int i2) {
		this.farPlaneDistance = (float)(256 >> this.mc.gameSettings.renderDistance);
		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glLoadIdentity();
		float f3 = 0.07F;
		if(this.mc.gameSettings.anaglyph) {
			GL11.glTranslatef((float)(-(i2 * 2 - 1)) * f3, 0.0F, 0.0F);
		}

		GLU.gluPerspective(this.func_914_d(f1), (float)this.mc.displayWidth / (float)this.mc.displayHeight, 0.05F, this.farPlaneDistance);
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
		GL11.glLoadIdentity();
		if(this.mc.gameSettings.anaglyph) {
			GL11.glTranslatef((float)(i2 * 2 - 1) * 0.1F, 0.0F, 0.0F);
		}

		this.hurtCameraEffect(f1);
		if(this.mc.gameSettings.viewBobbing) {
			this.setupViewBobbing(f1);
		}

		float f4 = this.mc.thePlayer.prevTimeInPortal + (this.mc.thePlayer.timeInPortal - this.mc.thePlayer.prevTimeInPortal) * f1;
		if(f4 > 0.0F) {
			float f5 = 5.0F / (f4 * f4 + 5.0F) - f4 * 0.04F;
			f5 *= f5;
			GL11.glRotatef(f4 * f4 * 1500.0F, 0.0F, 1.0F, 1.0F);
			GL11.glScalef(1.0F / f5, 1.0F, 1.0F);
			GL11.glRotatef(-f4 * f4 * 1500.0F, 0.0F, 1.0F, 1.0F);
		}

		this.orientCamera(f1);
	}

	private void func_4135_b(float f1, int i2) {
		GL11.glLoadIdentity();
		if(this.mc.gameSettings.anaglyph) {
			GL11.glTranslatef((float)(i2 * 2 - 1) * 0.1F, 0.0F, 0.0F);
		}

		GL11.glPushMatrix();
		this.hurtCameraEffect(f1);
		if(this.mc.gameSettings.viewBobbing) {
			this.setupViewBobbing(f1);
		}

		if(!this.mc.gameSettings.thirdPersonView && !Keyboard.isKeyDown(Keyboard.KEY_F1)) {
			this.itemRenderer.renderItemInFirstPerson(f1);
		}

		GL11.glPopMatrix();
		if(!this.mc.gameSettings.thirdPersonView) {
			this.itemRenderer.renderOverlays(f1);
			this.hurtCameraEffect(f1);
		}

		if(this.mc.gameSettings.viewBobbing) {
			this.setupViewBobbing(f1);
		}

	}

	public void func_4136_b(float f1) {
		if(!Display.isActive()) {
			if(System.currentTimeMillis() - this.field_1384_l > 500L) {
				this.mc.func_6252_g();
			}
		} else {
			this.field_1384_l = System.currentTimeMillis();
		}

		if(this.mc.field_6289_L) {
			this.mc.mouseHelper.mouseXYChange();
			float f2 = this.mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
			float f3 = f2 * f2 * f2 * 8.0F;
			float f4 = (float)this.mc.mouseHelper.field_1114_a * f3;
			float f5 = (float)this.mc.mouseHelper.field_1113_b * f3;
			byte b6 = 1;
			if(this.mc.gameSettings.invertMouse) {
				b6 = -1;
			}

			this.mc.thePlayer.func_346_d(f4, f5 * (float)b6);
		}

		if(!this.mc.field_6307_v) {
			ScaledResolution scaledResolution7 = new ScaledResolution(this.mc.displayWidth, this.mc.displayHeight);
			int i8 = scaledResolution7.getScaledWidth();
			int i9 = scaledResolution7.getScaledHeight();
			int i10 = Mouse.getX() * i8 / this.mc.displayWidth;
			int i11 = i9 - Mouse.getY() * i9 / this.mc.displayHeight - 1;
			if(this.mc.theWorld != null) {
				this.renderWorld(f1);
				if(!Keyboard.isKeyDown(Keyboard.KEY_F1)) {
					this.mc.ingameGUI.renderGameOverlay(f1, this.mc.currentScreen != null, i10, i11);
				}
			} else {
				GL11.glViewport(0, 0, this.mc.displayWidth, this.mc.displayHeight);
				GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
				GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
				GL11.glMatrixMode(GL11.GL_PROJECTION);
				GL11.glLoadIdentity();
				GL11.glMatrixMode(GL11.GL_MODELVIEW);
				GL11.glLoadIdentity();
				this.func_905_b();
			}

			if(this.mc.currentScreen != null) {
				GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);
				this.mc.currentScreen.drawScreen(i10, i11, f1);
			}

		}
	}

	public void renderWorld(float f1) {
		this.getMouseOver(f1);
		EntityPlayerSP entityPlayerSP2 = this.mc.thePlayer;
		RenderGlobal renderGlobal3 = this.mc.renderGlobal;
		EffectRenderer effectRenderer4 = this.mc.effectRenderer;
		double d5 = entityPlayerSP2.lastTickPosX + (entityPlayerSP2.posX - entityPlayerSP2.lastTickPosX) * (double)f1;
		double d7 = entityPlayerSP2.lastTickPosY + (entityPlayerSP2.posY - entityPlayerSP2.lastTickPosY) * (double)f1;
		double d9 = entityPlayerSP2.lastTickPosZ + (entityPlayerSP2.posZ - entityPlayerSP2.lastTickPosZ) * (double)f1;

		for(int i11 = 0; i11 < 2; ++i11) {
			if(this.mc.gameSettings.anaglyph) {
				if(i11 == 0) {
					GL11.glColorMask(false, true, true, false);
				} else {
					GL11.glColorMask(true, false, false, false);
				}
			}

			GL11.glViewport(0, 0, this.mc.displayWidth, this.mc.displayHeight);
			this.updateFogColor(f1);
			GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
			GL11.glEnable(GL11.GL_CULL_FACE);
			this.setupCameraTransform(f1, i11);
			ClippingHelperImplementation.getInstance();
			if(this.mc.gameSettings.renderDistance < 2) {
				this.func_4140_a(-1);
				renderGlobal3.func_4142_a(f1);
			}

			GL11.glEnable(GL11.GL_FOG);
			this.func_4140_a(1);
			Frustrum frustrum12 = new Frustrum();
			frustrum12.setPosition(d5, d7, d9);
			this.mc.renderGlobal.func_960_a(frustrum12, f1);
			this.mc.renderGlobal.updateRenderers(entityPlayerSP2, false);
			this.func_4140_a(0);
			GL11.glEnable(GL11.GL_FOG);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("/terrain.png"));
			RenderHelper.disableStandardItemLighting();
			renderGlobal3.func_943_a(entityPlayerSP2, 0, (double)f1);
			RenderHelper.enableStandardItemLighting();
			renderGlobal3.func_951_a(entityPlayerSP2.getPosition(f1), frustrum12, f1);
			effectRenderer4.func_1187_b(entityPlayerSP2, f1);
			RenderHelper.disableStandardItemLighting();
			this.func_4140_a(0);
			effectRenderer4.func_1189_a(entityPlayerSP2, f1);
			if(this.mc.objectMouseOver != null && entityPlayerSP2.isInsideOfMaterial(Material.water)) {
				GL11.glDisable(GL11.GL_ALPHA_TEST);
				renderGlobal3.func_959_a(entityPlayerSP2, this.mc.objectMouseOver, 0, entityPlayerSP2.inventory.getCurrentItem(), f1);
				renderGlobal3.drawSelectionBox(entityPlayerSP2, this.mc.objectMouseOver, 0, entityPlayerSP2.inventory.getCurrentItem(), f1);
				GL11.glEnable(GL11.GL_ALPHA_TEST);
			}

			GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
			this.func_4140_a(0);
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glDisable(GL11.GL_CULL_FACE);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("/terrain.png"));
			if(this.mc.gameSettings.fancyGraphics) {
				GL11.glColorMask(false, false, false, false);
				int i13 = renderGlobal3.func_943_a(entityPlayerSP2, 1, (double)f1);
				GL11.glColorMask(true, true, true, true);
				if(this.mc.gameSettings.anaglyph) {
					if(i11 == 0) {
						GL11.glColorMask(false, true, true, false);
					} else {
						GL11.glColorMask(true, false, false, false);
					}
				}

				if(i13 > 0) {
					renderGlobal3.func_944_a(1, (double)f1);
				}
			} else {
				renderGlobal3.func_943_a(entityPlayerSP2, 1, (double)f1);
			}

			GL11.glDepthMask(true);
			GL11.glEnable(GL11.GL_CULL_FACE);
			GL11.glDisable(GL11.GL_BLEND);
			if(this.mc.objectMouseOver != null && !entityPlayerSP2.isInsideOfMaterial(Material.water)) {
				GL11.glDisable(GL11.GL_ALPHA_TEST);
				renderGlobal3.func_959_a(entityPlayerSP2, this.mc.objectMouseOver, 0, entityPlayerSP2.inventory.getCurrentItem(), f1);
				renderGlobal3.drawSelectionBox(entityPlayerSP2, this.mc.objectMouseOver, 0, entityPlayerSP2.inventory.getCurrentItem(), f1);
				GL11.glEnable(GL11.GL_ALPHA_TEST);
			}

			GL11.glDisable(GL11.GL_FOG);
			if(this.field_1385_k != null) {
				;
			}

			this.func_4140_a(0);
			GL11.glEnable(GL11.GL_FOG);
			renderGlobal3.func_4141_b(f1);
			GL11.glDisable(GL11.GL_FOG);
			this.func_4140_a(1);
			GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);
			this.func_4135_b(f1, i11);
			if(!this.mc.gameSettings.anaglyph) {
				return;
			}
		}

		GL11.glColorMask(true, true, true, false);
	}

	private void renderFancyGraphics() {
		if(this.mc.gameSettings.fancyGraphics) {
			EntityPlayerSP entityPlayerSP1 = this.mc.thePlayer;
			World world2 = this.mc.theWorld;
			int i3 = MathHelper.floor_double(entityPlayerSP1.posX);
			int i4 = MathHelper.floor_double(entityPlayerSP1.posY);
			int i5 = MathHelper.floor_double(entityPlayerSP1.posZ);
			byte b6 = 16;

			for(int i7 = 0; i7 < 150; ++i7) {
				int i8 = i3 + this.random.nextInt(b6) - this.random.nextInt(b6);
				int i9 = i5 + this.random.nextInt(b6) - this.random.nextInt(b6);
				int i10 = world2.func_696_e(i8, i9);
				int i11 = world2.getBlockId(i8, i10 - 1, i9);
				if(i10 <= i4 + b6 && i10 >= i4 - b6) {
					float f12 = this.random.nextFloat();
					float f13 = this.random.nextFloat();
					if(i11 > 0) {
						this.mc.effectRenderer.func_1192_a(new EntityRainFX(world2, (double)((float)i8 + f12), (double)((float)i10 + 0.1F) - Block.blocksList[i11].minY, (double)((float)i9 + f13)));
					}
				}
			}

		}
	}

	public void func_905_b() {
		ScaledResolution scaledResolution1 = new ScaledResolution(this.mc.displayWidth, this.mc.displayHeight);
		int i2 = scaledResolution1.getScaledWidth();
		int i3 = scaledResolution1.getScaledHeight();
		GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);
		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glLoadIdentity();
		GL11.glOrtho(0.0D, (double)i2, (double)i3, 0.0D, 1000.0D, 3000.0D);
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
		GL11.glLoadIdentity();
		GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
	}

	private void updateFogColor(float f1) {
		World world2 = this.mc.theWorld;
		EntityPlayerSP entityPlayerSP3 = this.mc.thePlayer;
		float f4 = 1.0F / (float)(4 - this.mc.gameSettings.renderDistance);
		f4 = 1.0F - (float)Math.pow((double)f4, 0.25D);
		Vec3D vec3D5 = world2.func_4079_a(this.mc.thePlayer, f1);
		float f6 = (float)vec3D5.xCoord;
		float f7 = (float)vec3D5.yCoord;
		float f8 = (float)vec3D5.zCoord;
		Vec3D vec3D9 = world2.func_4082_d(f1);
		this.field_4270_e = (float)vec3D9.xCoord;
		this.field_4269_f = (float)vec3D9.yCoord;
		this.field_4268_g = (float)vec3D9.zCoord;
		this.field_4270_e += (f6 - this.field_4270_e) * f4;
		this.field_4269_f += (f7 - this.field_4269_f) * f4;
		this.field_4268_g += (f8 - this.field_4268_g) * f4;
		if(entityPlayerSP3.isInsideOfMaterial(Material.water)) {
			this.field_4270_e = 0.02F;
			this.field_4269_f = 0.02F;
			this.field_4268_g = 0.2F;
		} else if(entityPlayerSP3.isInsideOfMaterial(Material.lava)) {
			this.field_4270_e = 0.6F;
			this.field_4269_f = 0.1F;
			this.field_4268_g = 0.0F;
		}

		float f10 = this.field_1382_n + (this.field_1381_o - this.field_1382_n) * f1;
		this.field_4270_e *= f10;
		this.field_4269_f *= f10;
		this.field_4268_g *= f10;
		if(this.mc.gameSettings.anaglyph) {
			float f11 = (this.field_4270_e * 30.0F + this.field_4269_f * 59.0F + this.field_4268_g * 11.0F) / 100.0F;
			float f12 = (this.field_4270_e * 30.0F + this.field_4269_f * 70.0F) / 100.0F;
			float f13 = (this.field_4270_e * 30.0F + this.field_4268_g * 70.0F) / 100.0F;
			this.field_4270_e = f11;
			this.field_4269_f = f12;
			this.field_4268_g = f13;
		}

		GL11.glClearColor(this.field_4270_e, this.field_4269_f, this.field_4268_g, 0.0F);
	}

	private void func_4140_a(int i1) {
		EntityPlayerSP entityPlayerSP2 = this.mc.thePlayer;
		GL11.glFog(GL11.GL_FOG_COLOR, this.func_908_a(this.field_4270_e, this.field_4269_f, this.field_4268_g, 1.0F));
		GL11.glNormal3f(0.0F, -1.0F, 0.0F);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		float f3;
		float f4;
		float f5;
		float f6;
		float f7;
		float f8;
		if(entityPlayerSP2.isInsideOfMaterial(Material.water)) {
			GL11.glFogi(GL11.GL_FOG_MODE, GL11.GL_EXP);
			GL11.glFogf(GL11.GL_FOG_DENSITY, 0.1F);
			f3 = 0.4F;
			f4 = 0.4F;
			f5 = 0.9F;
			if(this.mc.gameSettings.anaglyph) {
				f6 = (f3 * 30.0F + f4 * 59.0F + f5 * 11.0F) / 100.0F;
				f7 = (f3 * 30.0F + f4 * 70.0F) / 100.0F;
				f8 = (f3 * 30.0F + f5 * 70.0F) / 100.0F;
			}
		} else if(entityPlayerSP2.isInsideOfMaterial(Material.lava)) {
			GL11.glFogi(GL11.GL_FOG_MODE, GL11.GL_EXP);
			GL11.glFogf(GL11.GL_FOG_DENSITY, 2.0F);
			f3 = 0.4F;
			f4 = 0.3F;
			f5 = 0.3F;
			if(this.mc.gameSettings.anaglyph) {
				f6 = (f3 * 30.0F + f4 * 59.0F + f5 * 11.0F) / 100.0F;
				f7 = (f3 * 30.0F + f4 * 70.0F) / 100.0F;
				f8 = (f3 * 30.0F + f5 * 70.0F) / 100.0F;
			}
		} else {
			GL11.glFogi(GL11.GL_FOG_MODE, GL11.GL_LINEAR);
			GL11.glFogf(GL11.GL_FOG_START, this.farPlaneDistance * 0.25F);
			GL11.glFogf(GL11.GL_FOG_END, this.farPlaneDistance);
			if(i1 < 0) {
				GL11.glFogf(GL11.GL_FOG_START, 0.0F);
				GL11.glFogf(GL11.GL_FOG_END, this.farPlaneDistance * 0.8F);
			}

			if(GLContext.getCapabilities().GL_NV_fog_distance) {
				GL11.glFogi(34138, 34139);
			}

			if(this.mc.theWorld.worldProvider.field_4220_c) {
				GL11.glFogf(GL11.GL_FOG_START, 0.0F);
			}
		}

		GL11.glEnable(GL11.GL_COLOR_MATERIAL);
		GL11.glColorMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT);
	}

	private FloatBuffer func_908_a(float f1, float f2, float f3, float f4) {
		this.field_1392_d.clear();
		this.field_1392_d.put(f1).put(f2).put(f3).put(f4);
		this.field_1392_d.flip();
		return this.field_1392_d;
	}
}
