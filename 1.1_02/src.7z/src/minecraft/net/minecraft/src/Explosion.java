package net.minecraft.src;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class Explosion {
	public boolean field_12257_a = false;
	private Random field_12250_h = new Random();
	private World field_12249_i;
	public double field_12256_b;
	public double field_12255_c;
	public double field_12254_d;
	public Entity field_12253_e;
	public float field_12252_f;
	public Set field_12251_g = new HashSet();

	public Explosion(World world1, Entity entity2, double d3, double d5, double d7, float f9) {
		this.field_12249_i = world1;
		this.field_12253_e = entity2;
		this.field_12252_f = f9;
		this.field_12256_b = d3;
		this.field_12255_c = d5;
		this.field_12254_d = d7;
	}

	public void func_12248_a() {
		float f1 = this.field_12252_f;
		byte b2 = 16;

		int i3;
		int i4;
		int i5;
		double d15;
		double d17;
		double d19;
		for(i3 = 0; i3 < b2; ++i3) {
			for(i4 = 0; i4 < b2; ++i4) {
				for(i5 = 0; i5 < b2; ++i5) {
					if(i3 == 0 || i3 == b2 - 1 || i4 == 0 || i4 == b2 - 1 || i5 == 0 || i5 == b2 - 1) {
						double d6 = (double)((float)i3 / ((float)b2 - 1.0F) * 2.0F - 1.0F);
						double d8 = (double)((float)i4 / ((float)b2 - 1.0F) * 2.0F - 1.0F);
						double d10 = (double)((float)i5 / ((float)b2 - 1.0F) * 2.0F - 1.0F);
						double d12 = Math.sqrt(d6 * d6 + d8 * d8 + d10 * d10);
						d6 /= d12;
						d8 /= d12;
						d10 /= d12;
						float f14 = this.field_12252_f * (0.7F + this.field_12249_i.rand.nextFloat() * 0.6F);
						d15 = this.field_12256_b;
						d17 = this.field_12255_c;
						d19 = this.field_12254_d;

						for(float f21 = 0.3F; f14 > 0.0F; f14 -= f21 * 0.75F) {
							int i22 = MathHelper.floor_double(d15);
							int i23 = MathHelper.floor_double(d17);
							int i24 = MathHelper.floor_double(d19);
							int i25 = this.field_12249_i.getBlockId(i22, i23, i24);
							if(i25 > 0) {
								f14 -= (Block.blocksList[i25].getExplosionResistance(this.field_12253_e) + 0.3F) * f21;
							}

							if(f14 > 0.0F) {
								this.field_12251_g.add(new ChunkPosition(i22, i23, i24));
							}

							d15 += d6 * (double)f21;
							d17 += d8 * (double)f21;
							d19 += d10 * (double)f21;
						}
					}
				}
			}
		}

		this.field_12252_f *= 2.0F;
		i3 = MathHelper.floor_double(this.field_12256_b - (double)this.field_12252_f - 1.0D);
		i4 = MathHelper.floor_double(this.field_12256_b + (double)this.field_12252_f + 1.0D);
		i5 = MathHelper.floor_double(this.field_12255_c - (double)this.field_12252_f - 1.0D);
		int i29 = MathHelper.floor_double(this.field_12255_c + (double)this.field_12252_f + 1.0D);
		int i7 = MathHelper.floor_double(this.field_12254_d - (double)this.field_12252_f - 1.0D);
		int i30 = MathHelper.floor_double(this.field_12254_d + (double)this.field_12252_f + 1.0D);
		List list9 = this.field_12249_i.getEntitiesWithinAABBExcludingEntity(this.field_12253_e, AxisAlignedBB.getBoundingBoxFromPool((double)i3, (double)i5, (double)i7, (double)i4, (double)i29, (double)i30));
		Vec3D vec3D31 = Vec3D.createVector(this.field_12256_b, this.field_12255_c, this.field_12254_d);

		for(int i11 = 0; i11 < list9.size(); ++i11) {
			Entity entity33 = (Entity)list9.get(i11);
			double d13 = entity33.getDistance(this.field_12256_b, this.field_12255_c, this.field_12254_d) / (double)this.field_12252_f;
			if(d13 <= 1.0D) {
				d15 = entity33.posX - this.field_12256_b;
				d17 = entity33.posY - this.field_12255_c;
				d19 = entity33.posZ - this.field_12254_d;
				double d39 = (double)MathHelper.sqrt_double(d15 * d15 + d17 * d17 + d19 * d19);
				d15 /= d39;
				d17 /= d39;
				d19 /= d39;
				double d40 = (double)this.field_12249_i.func_675_a(vec3D31, entity33.boundingBox);
				double d41 = (1.0D - d13) * d40;
				entity33.attackEntityFrom(this.field_12253_e, (int)((d41 * d41 + d41) / 2.0D * 8.0D * (double)this.field_12252_f + 1.0D));
				entity33.motionX += d15 * d41;
				entity33.motionY += d17 * d41;
				entity33.motionZ += d19 * d41;
			}
		}

		this.field_12252_f = f1;
		ArrayList arrayList32 = new ArrayList();
		arrayList32.addAll(this.field_12251_g);
		if(this.field_12257_a) {
			for(int i34 = arrayList32.size() - 1; i34 >= 0; --i34) {
				ChunkPosition chunkPosition35 = (ChunkPosition)arrayList32.get(i34);
				int i36 = chunkPosition35.x;
				int i37 = chunkPosition35.y;
				int i16 = chunkPosition35.z;
				int i38 = this.field_12249_i.getBlockId(i36, i37, i16);
				int i18 = this.field_12249_i.getBlockId(i36, i37 - 1, i16);
				if(i38 == 0 && Block.opaqueCubeLookup[i18] && this.field_12250_h.nextInt(3) == 0) {
					this.field_12249_i.setBlockWithNotify(i36, i37, i16, Block.fire.blockID);
				}
			}
		}

	}

	public void func_12247_b() {
		this.field_12249_i.playSoundEffect(this.field_12256_b, this.field_12255_c, this.field_12254_d, "random.explode", 4.0F, (1.0F + (this.field_12249_i.rand.nextFloat() - this.field_12249_i.rand.nextFloat()) * 0.2F) * 0.7F);
		ArrayList arrayList1 = new ArrayList();
		arrayList1.addAll(this.field_12251_g);

		for(int i2 = arrayList1.size() - 1; i2 >= 0; --i2) {
			ChunkPosition chunkPosition3 = (ChunkPosition)arrayList1.get(i2);
			int i4 = chunkPosition3.x;
			int i5 = chunkPosition3.y;
			int i6 = chunkPosition3.z;
			int i7 = this.field_12249_i.getBlockId(i4, i5, i6);

			for(int i8 = 0; i8 < 1; ++i8) {
				double d9 = (double)((float)i4 + this.field_12249_i.rand.nextFloat());
				double d11 = (double)((float)i5 + this.field_12249_i.rand.nextFloat());
				double d13 = (double)((float)i6 + this.field_12249_i.rand.nextFloat());
				double d15 = d9 - this.field_12256_b;
				double d17 = d11 - this.field_12255_c;
				double d19 = d13 - this.field_12254_d;
				double d21 = (double)MathHelper.sqrt_double(d15 * d15 + d17 * d17 + d19 * d19);
				d15 /= d21;
				d17 /= d21;
				d19 /= d21;
				double d23 = 0.5D / (d21 / (double)this.field_12252_f + 0.1D);
				d23 *= (double)(this.field_12249_i.rand.nextFloat() * this.field_12249_i.rand.nextFloat() + 0.3F);
				d15 *= d23;
				d17 *= d23;
				d19 *= d23;
				this.field_12249_i.spawnParticle("explode", (d9 + this.field_12256_b * 1.0D) / 2.0D, (d11 + this.field_12255_c * 1.0D) / 2.0D, (d13 + this.field_12254_d * 1.0D) / 2.0D, d15, d17, d19);
				this.field_12249_i.spawnParticle("smoke", d9, d11, d13, d15, d17, d19);
			}

			if(i7 > 0) {
				Block.blocksList[i7].dropBlockAsItemWithChance(this.field_12249_i, i4, i5, i6, this.field_12249_i.getBlockMetadata(i4, i5, i6), 0.3F);
				this.field_12249_i.setBlockWithNotify(i4, i5, i6, 0);
				Block.blocksList[i7].onBlockDestroyedByExplosion(this.field_12249_i, i4, i5, i6);
			}
		}

	}
}
