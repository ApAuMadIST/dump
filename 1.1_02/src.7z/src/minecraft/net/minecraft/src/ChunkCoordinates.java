package net.minecraft.src;

final class ChunkCoordinates {
	public final int field_1518_a;
	public final int field_1517_b;

	public ChunkCoordinates(int i1, int i2) {
		this.field_1518_a = i1;
		this.field_1517_b = i2;
	}

	public boolean equals(Object object1) {
		if(!(object1 instanceof ChunkCoordinates)) {
			return false;
		} else {
			ChunkCoordinates chunkCoordinates2 = (ChunkCoordinates)object1;
			return this.field_1518_a == chunkCoordinates2.field_1518_a && this.field_1517_b == chunkCoordinates2.field_1517_b;
		}
	}

	public int hashCode() {
		return this.field_1518_a << 16 ^ this.field_1517_b;
	}
}
