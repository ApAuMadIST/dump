package net.minecraft.src;

import net.minecraft.client.Minecraft;

public class PlayerControllerMP extends PlayerController {
	private int field_9445_c = -1;
	private int field_9444_d = -1;
	private int field_9443_e = -1;
	private float field_9442_f = 0.0F;
	private float field_1080_g = 0.0F;
	private float field_9441_h = 0.0F;
	private int field_9440_i = 0;
	private boolean field_9439_j = false;
	private NetClientHandler field_9438_k;
	private int field_1075_l = 0;

	public PlayerControllerMP(Minecraft minecraft1, NetClientHandler netClientHandler2) {
		super(minecraft1);
		this.field_9438_k = netClientHandler2;
	}

	public void flipPlayer(EntityPlayer entityPlayer1) {
		entityPlayer1.rotationYaw = -180.0F;
	}

	public boolean sendBlockRemoved(int i1, int i2, int i3, int i4) {
		this.field_9438_k.addToSendQueue(new Packet14BlockDig(3, i1, i2, i3, i4));
		int i5 = this.mc.theWorld.getBlockId(i1, i2, i3);
		boolean z6 = super.sendBlockRemoved(i1, i2, i3, i4);
		ItemStack itemStack7 = this.mc.thePlayer.getCurrentEquippedItem();
		if(itemStack7 != null) {
			itemStack7.hitBlock(i5, i1, i2, i3);
			if(itemStack7.stackSize == 0) {
				itemStack7.func_1097_a(this.mc.thePlayer);
				this.mc.thePlayer.destroyCurrentEquippedItem();
			}
		}

		return z6;
	}

	public void clickBlock(int i1, int i2, int i3, int i4) {
		this.field_9439_j = true;
		this.field_9438_k.addToSendQueue(new Packet14BlockDig(0, i1, i2, i3, i4));
		int i5 = this.mc.theWorld.getBlockId(i1, i2, i3);
		if(i5 > 0 && this.field_9442_f == 0.0F) {
			Block.blocksList[i5].onBlockClicked(this.mc.theWorld, i1, i2, i3, this.mc.thePlayer);
		}

		if(i5 > 0 && Block.blocksList[i5].blockStrength(this.mc.thePlayer) >= 1.0F) {
			this.sendBlockRemoved(i1, i2, i3, i4);
		}

	}

	public void func_6468_a() {
		if(this.field_9439_j) {
			this.field_9439_j = false;
			this.field_9438_k.addToSendQueue(new Packet14BlockDig(2, 0, 0, 0, 0));
			this.field_9442_f = 0.0F;
			this.field_9440_i = 0;
		}
	}

	public void sendBlockRemoving(int i1, int i2, int i3, int i4) {
		this.field_9439_j = true;
		this.func_730_e();
		this.field_9438_k.addToSendQueue(new Packet14BlockDig(1, i1, i2, i3, i4));
		if(this.field_9440_i > 0) {
			--this.field_9440_i;
		} else {
			if(i1 == this.field_9445_c && i2 == this.field_9444_d && i3 == this.field_9443_e) {
				int i5 = this.mc.theWorld.getBlockId(i1, i2, i3);
				if(i5 == 0) {
					return;
				}

				Block block6 = Block.blocksList[i5];
				this.field_9442_f += block6.blockStrength(this.mc.thePlayer);
				if(this.field_9441_h % 4.0F == 0.0F && block6 != null) {
					this.mc.sndManager.playSound(block6.stepSound.func_1145_d(), (float)i1 + 0.5F, (float)i2 + 0.5F, (float)i3 + 0.5F, (block6.stepSound.func_1147_b() + 1.0F) / 8.0F, block6.stepSound.func_1144_c() * 0.5F);
				}

				++this.field_9441_h;
				if(this.field_9442_f >= 1.0F) {
					this.sendBlockRemoved(i1, i2, i3, i4);
					this.field_9442_f = 0.0F;
					this.field_1080_g = 0.0F;
					this.field_9441_h = 0.0F;
					this.field_9440_i = 5;
				}
			} else {
				this.field_9442_f = 0.0F;
				this.field_1080_g = 0.0F;
				this.field_9441_h = 0.0F;
				this.field_9445_c = i1;
				this.field_9444_d = i2;
				this.field_9443_e = i3;
			}

		}
	}

	public void setPartialTime(float f1) {
		if(this.field_9442_f <= 0.0F) {
			this.mc.ingameGUI.field_6446_b = 0.0F;
			this.mc.renderGlobal.field_1450_i = 0.0F;
		} else {
			float f2 = this.field_1080_g + (this.field_9442_f - this.field_1080_g) * f1;
			this.mc.ingameGUI.field_6446_b = f2;
			this.mc.renderGlobal.field_1450_i = f2;
		}

	}

	public float getBlockReachDistance() {
		return 4.0F;
	}

	public void func_717_a(World world1) {
		super.func_717_a(world1);
	}

	public void updateController() {
		this.func_730_e();
		this.field_1080_g = this.field_9442_f;
		this.mc.sndManager.func_4033_c();
	}

	private void func_730_e() {
		int i1 = this.mc.thePlayer.inventory.currentItem;
		if(i1 != this.field_1075_l) {
			this.field_1075_l = i1;
			this.field_9438_k.addToSendQueue(new Packet16BlockItemSwitch(this.field_1075_l));
		}

	}

	public boolean sendPlaceBlock(EntityPlayer entityPlayer1, World world2, ItemStack itemStack3, int i4, int i5, int i6, int i7) {
		this.func_730_e();
		boolean z8 = super.sendPlaceBlock(entityPlayer1, world2, itemStack3, i4, i5, i6, i7);
		this.field_9438_k.addToSendQueue(new Packet15Place(i4, i5, i6, i7, entityPlayer1.inventory.getCurrentItem()));
		return z8;
	}

	public boolean sendUseItem(EntityPlayer entityPlayer1, World world2, ItemStack itemStack3) {
		this.func_730_e();
		boolean z4 = super.sendUseItem(entityPlayer1, world2, itemStack3);
		this.field_9438_k.addToSendQueue(new Packet15Place(-1, -1, -1, 255, entityPlayer1.inventory.getCurrentItem()));
		return z4;
	}

	public EntityPlayer func_4087_b(World world1) {
		return new EntityClientPlayerMP(this.mc, world1, this.mc.session, this.field_9438_k);
	}

	public void func_6472_b(EntityPlayer entityPlayer1, Entity entity2) {
		this.func_730_e();
		this.field_9438_k.addToSendQueue(new Packet7(entityPlayer1.field_620_ab, entity2.field_620_ab, 1));
		entityPlayer1.attackTargetEntityWithCurrentItem(entity2);
	}

	public void func_6475_a(EntityPlayer entityPlayer1, Entity entity2) {
		this.func_730_e();
		this.field_9438_k.addToSendQueue(new Packet7(entityPlayer1.field_620_ab, entity2.field_620_ab, 0));
		entityPlayer1.useCurrentItemOnEntity(entity2);
	}

	public ItemStack func_20085_a(int i1, int i2, int i3, EntityPlayer entityPlayer4) {
		short s5 = entityPlayer4.field_20068_h.func_20111_a(entityPlayer4.inventory);
		ItemStack itemStack6 = super.func_20085_a(i1, i2, i3, entityPlayer4);
		this.field_9438_k.addToSendQueue(new Packet102(i1, i2, i3, itemStack6, s5));
		return itemStack6;
	}

	public void func_20086_a(int i1, EntityPlayer entityPlayer2) {
		if(i1 != -9999) {
			;
		}
	}
}
