package net.minecraft.src;

import net.minecraft.client.Minecraft;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

public class ItemRenderer {
	private Minecraft mc;
	private ItemStack field_9451_b = null;
	private float field_9453_c = 0.0F;
	private float field_9452_d = 0.0F;
	private RenderBlocks field_1357_e = new RenderBlocks();
	private int field_20099_f = -1;

	public ItemRenderer(Minecraft minecraft1) {
		this.mc = minecraft1;
	}

	public void renderItem(ItemStack itemStack1) {
		GL11.glPushMatrix();
		if(itemStack1.itemID < 256 && RenderBlocks.func_1219_a(Block.blocksList[itemStack1.itemID].getRenderType())) {
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("/terrain.png"));
			this.field_1357_e.func_1227_a(Block.blocksList[itemStack1.itemID]);
		} else {
			if(itemStack1.itemID < 256) {
				GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("/terrain.png"));
			} else {
				GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("/gui/items.png"));
			}

			Tessellator tessellator2 = Tessellator.instance;
			float f3 = ((float)(itemStack1.getIconIndex() % 16 * 16) + 0.0F) / 256.0F;
			float f4 = ((float)(itemStack1.getIconIndex() % 16 * 16) + 15.99F) / 256.0F;
			float f5 = ((float)(itemStack1.getIconIndex() / 16 * 16) + 0.0F) / 256.0F;
			float f6 = ((float)(itemStack1.getIconIndex() / 16 * 16) + 15.99F) / 256.0F;
			float f7 = 1.0F;
			float f8 = 0.0F;
			float f9 = 0.3F;
			GL11.glEnable(GL12.GL_RESCALE_NORMAL);
			GL11.glTranslatef(-f8, -f9, 0.0F);
			float f10 = 1.5F;
			GL11.glScalef(f10, f10, f10);
			GL11.glRotatef(50.0F, 0.0F, 1.0F, 0.0F);
			GL11.glRotatef(335.0F, 0.0F, 0.0F, 1.0F);
			GL11.glTranslatef(-0.9375F, -0.0625F, 0.0F);
			float f11 = 0.0625F;
			tessellator2.startDrawingQuads();
			tessellator2.setNormal(0.0F, 0.0F, 1.0F);
			tessellator2.addVertexWithUV(0.0D, 0.0D, 0.0D, (double)f4, (double)f6);
			tessellator2.addVertexWithUV((double)f7, 0.0D, 0.0D, (double)f3, (double)f6);
			tessellator2.addVertexWithUV((double)f7, 1.0D, 0.0D, (double)f3, (double)f5);
			tessellator2.addVertexWithUV(0.0D, 1.0D, 0.0D, (double)f4, (double)f5);
			tessellator2.draw();
			tessellator2.startDrawingQuads();
			tessellator2.setNormal(0.0F, 0.0F, -1.0F);
			tessellator2.addVertexWithUV(0.0D, 1.0D, (double)(0.0F - f11), (double)f4, (double)f5);
			tessellator2.addVertexWithUV((double)f7, 1.0D, (double)(0.0F - f11), (double)f3, (double)f5);
			tessellator2.addVertexWithUV((double)f7, 0.0D, (double)(0.0F - f11), (double)f3, (double)f6);
			tessellator2.addVertexWithUV(0.0D, 0.0D, (double)(0.0F - f11), (double)f4, (double)f6);
			tessellator2.draw();
			tessellator2.startDrawingQuads();
			tessellator2.setNormal(-1.0F, 0.0F, 0.0F);

			int i12;
			float f13;
			float f14;
			float f15;
			for(i12 = 0; i12 < 16; ++i12) {
				f13 = (float)i12 / 16.0F;
				f14 = f4 + (f3 - f4) * f13 - 0.001953125F;
				f15 = f7 * f13;
				tessellator2.addVertexWithUV((double)f15, 0.0D, (double)(0.0F - f11), (double)f14, (double)f6);
				tessellator2.addVertexWithUV((double)f15, 0.0D, 0.0D, (double)f14, (double)f6);
				tessellator2.addVertexWithUV((double)f15, 1.0D, 0.0D, (double)f14, (double)f5);
				tessellator2.addVertexWithUV((double)f15, 1.0D, (double)(0.0F - f11), (double)f14, (double)f5);
			}

			tessellator2.draw();
			tessellator2.startDrawingQuads();
			tessellator2.setNormal(1.0F, 0.0F, 0.0F);

			for(i12 = 0; i12 < 16; ++i12) {
				f13 = (float)i12 / 16.0F;
				f14 = f4 + (f3 - f4) * f13 - 0.001953125F;
				f15 = f7 * f13 + 0.0625F;
				tessellator2.addVertexWithUV((double)f15, 1.0D, (double)(0.0F - f11), (double)f14, (double)f5);
				tessellator2.addVertexWithUV((double)f15, 1.0D, 0.0D, (double)f14, (double)f5);
				tessellator2.addVertexWithUV((double)f15, 0.0D, 0.0D, (double)f14, (double)f6);
				tessellator2.addVertexWithUV((double)f15, 0.0D, (double)(0.0F - f11), (double)f14, (double)f6);
			}

			tessellator2.draw();
			tessellator2.startDrawingQuads();
			tessellator2.setNormal(0.0F, 1.0F, 0.0F);

			for(i12 = 0; i12 < 16; ++i12) {
				f13 = (float)i12 / 16.0F;
				f14 = f6 + (f5 - f6) * f13 - 0.001953125F;
				f15 = f7 * f13 + 0.0625F;
				tessellator2.addVertexWithUV(0.0D, (double)f15, 0.0D, (double)f4, (double)f14);
				tessellator2.addVertexWithUV((double)f7, (double)f15, 0.0D, (double)f3, (double)f14);
				tessellator2.addVertexWithUV((double)f7, (double)f15, (double)(0.0F - f11), (double)f3, (double)f14);
				tessellator2.addVertexWithUV(0.0D, (double)f15, (double)(0.0F - f11), (double)f4, (double)f14);
			}

			tessellator2.draw();
			tessellator2.startDrawingQuads();
			tessellator2.setNormal(0.0F, -1.0F, 0.0F);

			for(i12 = 0; i12 < 16; ++i12) {
				f13 = (float)i12 / 16.0F;
				f14 = f6 + (f5 - f6) * f13 - 0.001953125F;
				f15 = f7 * f13;
				tessellator2.addVertexWithUV((double)f7, (double)f15, 0.0D, (double)f3, (double)f14);
				tessellator2.addVertexWithUV(0.0D, (double)f15, 0.0D, (double)f4, (double)f14);
				tessellator2.addVertexWithUV(0.0D, (double)f15, (double)(0.0F - f11), (double)f4, (double)f14);
				tessellator2.addVertexWithUV((double)f7, (double)f15, (double)(0.0F - f11), (double)f3, (double)f14);
			}

			tessellator2.draw();
			GL11.glDisable(GL12.GL_RESCALE_NORMAL);
		}

		GL11.glPopMatrix();
	}

	public void renderItemInFirstPerson(float f1) {
		float f2 = this.field_9452_d + (this.field_9453_c - this.field_9452_d) * f1;
		EntityPlayerSP entityPlayerSP3 = this.mc.thePlayer;
		GL11.glPushMatrix();
		GL11.glRotatef(entityPlayerSP3.prevRotationPitch + (entityPlayerSP3.rotationPitch - entityPlayerSP3.prevRotationPitch) * f1, 1.0F, 0.0F, 0.0F);
		GL11.glRotatef(entityPlayerSP3.prevRotationYaw + (entityPlayerSP3.rotationYaw - entityPlayerSP3.prevRotationYaw) * f1, 0.0F, 1.0F, 0.0F);
		RenderHelper.enableStandardItemLighting();
		GL11.glPopMatrix();
		float f4 = this.mc.theWorld.getLightBrightness(MathHelper.floor_double(entityPlayerSP3.posX), MathHelper.floor_double(entityPlayerSP3.posY), MathHelper.floor_double(entityPlayerSP3.posZ));
		GL11.glColor4f(f4, f4, f4, 1.0F);
		ItemStack itemStack5 = this.field_9451_b;
		if(entityPlayerSP3.fishEntity != null) {
			itemStack5 = new ItemStack(Item.stick.shiftedIndex);
		}

		float f6;
		float f7;
		float f8;
		float f9;
		if(itemStack5 != null) {
			GL11.glPushMatrix();
			f6 = 0.8F;
			f7 = entityPlayerSP3.getSwingProgress(f1);
			f8 = MathHelper.sin(f7 * (float)Math.PI);
			f9 = MathHelper.sin(MathHelper.sqrt_float(f7) * (float)Math.PI);
			GL11.glTranslatef(-f9 * 0.4F, MathHelper.sin(MathHelper.sqrt_float(f7) * (float)Math.PI * 2.0F) * 0.2F, -f8 * 0.2F);
			GL11.glTranslatef(0.7F * f6, -0.65F * f6 - (1.0F - f2) * 0.6F, -0.9F * f6);
			GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
			GL11.glEnable(GL12.GL_RESCALE_NORMAL);
			f7 = entityPlayerSP3.getSwingProgress(f1);
			f8 = MathHelper.sin(f7 * f7 * (float)Math.PI);
			f9 = MathHelper.sin(MathHelper.sqrt_float(f7) * (float)Math.PI);
			GL11.glRotatef(-f8 * 20.0F, 0.0F, 1.0F, 0.0F);
			GL11.glRotatef(-f9 * 20.0F, 0.0F, 0.0F, 1.0F);
			GL11.glRotatef(-f9 * 80.0F, 1.0F, 0.0F, 0.0F);
			f7 = 0.4F;
			GL11.glScalef(f7, f7, f7);
			if(itemStack5.getItem().shouldRotateAroundWhenRendering()) {
				GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
			}

			this.renderItem(itemStack5);
			GL11.glPopMatrix();
		} else {
			GL11.glPushMatrix();
			f6 = 0.8F;
			f7 = entityPlayerSP3.getSwingProgress(f1);
			f8 = MathHelper.sin(f7 * (float)Math.PI);
			f9 = MathHelper.sin(MathHelper.sqrt_float(f7) * (float)Math.PI);
			GL11.glTranslatef(-f9 * 0.3F, MathHelper.sin(MathHelper.sqrt_float(f7) * (float)Math.PI * 2.0F) * 0.4F, -f8 * 0.4F);
			GL11.glTranslatef(0.8F * f6, -0.75F * f6 - (1.0F - f2) * 0.6F, -0.9F * f6);
			GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
			GL11.glEnable(GL12.GL_RESCALE_NORMAL);
			f7 = entityPlayerSP3.getSwingProgress(f1);
			f8 = MathHelper.sin(f7 * f7 * (float)Math.PI);
			f9 = MathHelper.sin(MathHelper.sqrt_float(f7) * (float)Math.PI);
			GL11.glRotatef(f9 * 70.0F, 0.0F, 1.0F, 0.0F);
			GL11.glRotatef(-f8 * 20.0F, 0.0F, 0.0F, 1.0F);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTextureForDownloadableImage(this.mc.thePlayer.field_20047_bv, this.mc.thePlayer.getEntityTexture()));
			GL11.glTranslatef(-1.0F, 3.6F, 3.5F);
			GL11.glRotatef(120.0F, 0.0F, 0.0F, 1.0F);
			GL11.glRotatef(200.0F, 1.0F, 0.0F, 0.0F);
			GL11.glRotatef(-135.0F, 0.0F, 1.0F, 0.0F);
			GL11.glScalef(1.0F, 1.0F, 1.0F);
			GL11.glTranslatef(5.6F, 0.0F, 0.0F);
			Render render10 = RenderManager.instance.getEntityRenderObject(this.mc.thePlayer);
			RenderPlayer renderPlayer11 = (RenderPlayer)render10;
			f9 = 1.0F;
			GL11.glScalef(f9, f9, f9);
			renderPlayer11.drawFirstPersonHand();
			GL11.glPopMatrix();
		}

		GL11.glDisable(GL12.GL_RESCALE_NORMAL);
		RenderHelper.disableStandardItemLighting();
	}

	public void renderOverlays(float f1) {
		GL11.glDisable(GL11.GL_ALPHA_TEST);
		int i2;
		if(this.mc.thePlayer.fire > 0 || this.mc.thePlayer.field_9299_bv) {
			i2 = this.mc.renderEngine.getTexture("/terrain.png");
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, i2);
			this.renderFireInFirstPerson(f1);
		}

		if(this.mc.thePlayer.func_345_I()) {
			i2 = MathHelper.floor_double(this.mc.thePlayer.posX);
			int i3 = MathHelper.floor_double(this.mc.thePlayer.posY);
			int i4 = MathHelper.floor_double(this.mc.thePlayer.posZ);
			int i5 = this.mc.renderEngine.getTexture("/terrain.png");
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, i5);
			int i6 = this.mc.theWorld.getBlockId(i2, i3, i4);
			if(Block.blocksList[i6] != null) {
				this.renderInsideOfBlock(f1, Block.blocksList[i6].getBlockTextureFromSide(2));
			}
		}

		if(this.mc.thePlayer.isInsideOfMaterial(Material.water)) {
			i2 = this.mc.renderEngine.getTexture("/misc/water.png");
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, i2);
			this.renderWarpedTextureOverlay(f1);
		}

		GL11.glEnable(GL11.GL_ALPHA_TEST);
	}

	private void renderInsideOfBlock(float f1, int i2) {
		Tessellator tessellator3 = Tessellator.instance;
		this.mc.thePlayer.getEntityBrightness(f1);
		float f4 = 0.1F;
		GL11.glColor4f(f4, f4, f4, 0.5F);
		GL11.glPushMatrix();
		float f5 = -1.0F;
		float f6 = 1.0F;
		float f7 = -1.0F;
		float f8 = 1.0F;
		float f9 = -0.5F;
		float f10 = 0.0078125F;
		float f11 = (float)(i2 % 16) / 256.0F - f10;
		float f12 = ((float)(i2 % 16) + 15.99F) / 256.0F + f10;
		float f13 = (float)(i2 / 16) / 256.0F - f10;
		float f14 = ((float)(i2 / 16) + 15.99F) / 256.0F + f10;
		tessellator3.startDrawingQuads();
		tessellator3.addVertexWithUV((double)f5, (double)f7, (double)f9, (double)f12, (double)f14);
		tessellator3.addVertexWithUV((double)f6, (double)f7, (double)f9, (double)f11, (double)f14);
		tessellator3.addVertexWithUV((double)f6, (double)f8, (double)f9, (double)f11, (double)f13);
		tessellator3.addVertexWithUV((double)f5, (double)f8, (double)f9, (double)f12, (double)f13);
		tessellator3.draw();
		GL11.glPopMatrix();
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
	}

	private void renderWarpedTextureOverlay(float f1) {
		Tessellator tessellator2 = Tessellator.instance;
		float f3 = this.mc.thePlayer.getEntityBrightness(f1);
		GL11.glColor4f(f3, f3, f3, 0.5F);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glPushMatrix();
		float f4 = 4.0F;
		float f5 = -1.0F;
		float f6 = 1.0F;
		float f7 = -1.0F;
		float f8 = 1.0F;
		float f9 = -0.5F;
		float f10 = -this.mc.thePlayer.rotationYaw / 64.0F;
		float f11 = this.mc.thePlayer.rotationPitch / 64.0F;
		tessellator2.startDrawingQuads();
		tessellator2.addVertexWithUV((double)f5, (double)f7, (double)f9, (double)(f4 + f10), (double)(f4 + f11));
		tessellator2.addVertexWithUV((double)f6, (double)f7, (double)f9, (double)(0.0F + f10), (double)(f4 + f11));
		tessellator2.addVertexWithUV((double)f6, (double)f8, (double)f9, (double)(0.0F + f10), (double)(0.0F + f11));
		tessellator2.addVertexWithUV((double)f5, (double)f8, (double)f9, (double)(f4 + f10), (double)(0.0F + f11));
		tessellator2.draw();
		GL11.glPopMatrix();
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GL11.glDisable(GL11.GL_BLEND);
	}

	private void renderFireInFirstPerson(float f1) {
		Tessellator tessellator2 = Tessellator.instance;
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.9F);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		float f3 = 1.0F;

		for(int i4 = 0; i4 < 2; ++i4) {
			GL11.glPushMatrix();
			int i5 = Block.fire.blockIndexInTexture + i4 * 16;
			int i6 = (i5 & 15) << 4;
			int i7 = i5 & 240;
			float f8 = (float)i6 / 256.0F;
			float f9 = ((float)i6 + 15.99F) / 256.0F;
			float f10 = (float)i7 / 256.0F;
			float f11 = ((float)i7 + 15.99F) / 256.0F;
			float f12 = (0.0F - f3) / 2.0F;
			float f13 = f12 + f3;
			float f14 = 0.0F - f3 / 2.0F;
			float f15 = f14 + f3;
			float f16 = -0.5F;
			GL11.glTranslatef((float)(-(i4 * 2 - 1)) * 0.24F, -0.3F, 0.0F);
			GL11.glRotatef((float)(i4 * 2 - 1) * 10.0F, 0.0F, 1.0F, 0.0F);
			tessellator2.startDrawingQuads();
			tessellator2.addVertexWithUV((double)f12, (double)f14, (double)f16, (double)f9, (double)f11);
			tessellator2.addVertexWithUV((double)f13, (double)f14, (double)f16, (double)f8, (double)f11);
			tessellator2.addVertexWithUV((double)f13, (double)f15, (double)f16, (double)f8, (double)f10);
			tessellator2.addVertexWithUV((double)f12, (double)f15, (double)f16, (double)f9, (double)f10);
			tessellator2.draw();
			GL11.glPopMatrix();
		}

		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GL11.glDisable(GL11.GL_BLEND);
	}

	public void func_895_a() {
		this.field_9452_d = this.field_9453_c;
		EntityPlayerSP entityPlayerSP1 = this.mc.thePlayer;
		ItemStack itemStack2 = entityPlayerSP1.inventory.getCurrentItem();
		boolean z4 = this.field_20099_f == entityPlayerSP1.inventory.currentItem && itemStack2 == this.field_9451_b;
		if(this.field_9451_b == null && itemStack2 == null) {
			z4 = true;
		}

		if(itemStack2 != null && this.field_9451_b != null && itemStack2 != this.field_9451_b && itemStack2.itemID == this.field_9451_b.itemID) {
			this.field_9451_b = itemStack2;
			z4 = true;
		}

		float f5 = 0.4F;
		float f6 = z4 ? 1.0F : 0.0F;
		float f7 = f6 - this.field_9453_c;
		if(f7 < -f5) {
			f7 = -f5;
		}

		if(f7 > f5) {
			f7 = f5;
		}

		this.field_9453_c += f7;
		if(this.field_9453_c < 0.1F) {
			this.field_9451_b = itemStack2;
			this.field_20099_f = entityPlayerSP1.inventory.currentItem;
		}

	}

	public void func_9449_b() {
		this.field_9453_c = 0.0F;
	}

	public void func_9450_c() {
		this.field_9453_c = 0.0F;
	}
}
