package net.minecraft.src;

import java.awt.Color;

public class MobSpawnerBase {
	public static final MobSpawnerBase rainforest = (new MobSpawnerBase()).func_4123_b(588342).setBiomeName("Rainforest").func_4124_a(2094168);
	public static final MobSpawnerBase swampland = (new MobSpawnerSwamp()).func_4123_b(522674).setBiomeName("Swampland").func_4124_a(9154376);
	public static final MobSpawnerBase seasonalForest = (new MobSpawnerBase()).func_4123_b(10215459).setBiomeName("Seasonal Forest");
	public static final MobSpawnerBase forest = (new MobSpawnerBase()).func_4123_b(353825).setBiomeName("Forest").func_4124_a(5159473);
	public static final MobSpawnerBase savanna = (new MobSpawnerDesert()).func_4123_b(14278691).setBiomeName("Savanna");
	public static final MobSpawnerBase shrubland = (new MobSpawnerBase()).func_4123_b(10595616).setBiomeName("Shrubland");
	public static final MobSpawnerBase taiga = (new MobSpawnerBase()).func_4123_b(3060051).setBiomeName("Taiga").func_4122_b().func_4124_a(8107825);
	public static final MobSpawnerBase desert = (new MobSpawnerDesert()).func_4123_b(16421912).setBiomeName("Desert");
	public static final MobSpawnerBase plains = (new MobSpawnerDesert()).func_4123_b(16767248).setBiomeName("Plains");
	public static final MobSpawnerBase iceDesert = (new MobSpawnerDesert()).func_4123_b(16772499).setBiomeName("Ice Desert").func_4122_b().func_4124_a(12899129);
	public static final MobSpawnerBase tundra = (new MobSpawnerBase()).func_4123_b(5762041).setBiomeName("Tundra").func_4122_b().func_4124_a(12899129);
	public static final MobSpawnerBase hell = (new MobSpawnerHell()).func_4123_b(16711680).setBiomeName("Hell");
	public String biomeName;
	public int field_6503_n;
	public byte topBlock = (byte)Block.grass.blockID;
	public byte fillerBlock = (byte)Block.dirt.blockID;
	public int field_6502_q = 5169201;
	protected Class[] biomeMonsters = new Class[]{EntitySpider.class, EntityZombie.class, EntitySkeleton.class, EntityCreeper.class};
	protected Class[] biomeCreatures = new Class[]{EntitySheep.class, EntityPig.class, EntityChicken.class, EntityCow.class};
	private static MobSpawnerBase[] biomeLookupTable = new MobSpawnerBase[4096];

	public static void generateBiomeLookup() {
		for(int i0 = 0; i0 < 64; ++i0) {
			for(int i1 = 0; i1 < 64; ++i1) {
				biomeLookupTable[i0 + i1 * 64] = getBiome((float)i0 / 63.0F, (float)i1 / 63.0F);
			}
		}

		desert.topBlock = desert.fillerBlock = (byte)Block.sand.blockID;
		iceDesert.topBlock = iceDesert.fillerBlock = (byte)Block.sand.blockID;
	}

	protected MobSpawnerBase func_4122_b() {
		return this;
	}

	protected MobSpawnerBase setBiomeName(String string1) {
		this.biomeName = string1;
		return this;
	}

	protected MobSpawnerBase func_4124_a(int i1) {
		this.field_6502_q = i1;
		return this;
	}

	protected MobSpawnerBase func_4123_b(int i1) {
		this.field_6503_n = i1;
		return this;
	}

	public static MobSpawnerBase getBiomeFromLookup(double d0, double d2) {
		int i4 = (int)(d0 * 63.0D);
		int i5 = (int)(d2 * 63.0D);
		return biomeLookupTable[i4 + i5 * 64];
	}

	public static MobSpawnerBase getBiome(float f0, float f1) {
		f1 *= f0;
		return f0 < 0.1F ? tundra : (f1 < 0.2F ? (f0 < 0.5F ? tundra : (f0 < 0.95F ? savanna : desert)) : (f1 > 0.5F && f0 < 0.7F ? swampland : (f0 < 0.5F ? taiga : (f0 < 0.97F ? (f1 < 0.35F ? shrubland : forest) : (f1 < 0.45F ? plains : (f1 < 0.9F ? seasonalForest : rainforest))))));
	}

	public int getSkyColorByTemp(float f1) {
		f1 /= 3.0F;
		if(f1 < -1.0F) {
			f1 = -1.0F;
		}

		if(f1 > 1.0F) {
			f1 = 1.0F;
		}

		return Color.getHSBColor(0.62222224F - f1 * 0.05F, 0.5F + f1 * 0.1F, 1.0F).getRGB();
	}

	public Class[] getEntitiesForType(EnumCreatureType enumCreatureType1) {
		return enumCreatureType1 == EnumCreatureType.monster ? this.biomeMonsters : (enumCreatureType1 == EnumCreatureType.creature ? this.biomeCreatures : null);
	}

	static {
		generateBiomeLookup();
	}
}
