package net.minecraft.src;

public interface ICrafting {
	void func_20159_a(CraftingInventoryCB craftingInventoryCB1, int i2, ItemStack itemStack3);

	void func_20158_a(CraftingInventoryCB craftingInventoryCB1, int i2, int i3);
}
