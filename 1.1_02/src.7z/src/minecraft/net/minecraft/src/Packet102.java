package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet102 extends Packet {
	public int field_20024_a;
	public int field_20023_b;
	public int field_20027_c;
	public short field_20026_d;
	public ItemStack field_20025_e;

	public Packet102() {
	}

	public Packet102(int i1, int i2, int i3, ItemStack itemStack4, short s5) {
		this.field_20024_a = i1;
		this.field_20023_b = i2;
		this.field_20027_c = i3;
		this.field_20025_e = itemStack4;
		this.field_20026_d = s5;
	}

	public void processPacket(NetHandler netHandler1) {
		netHandler1.func_20091_a(this);
	}

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.field_20024_a = dataInputStream1.readByte();
		this.field_20023_b = dataInputStream1.readShort();
		this.field_20027_c = dataInputStream1.readByte();
		this.field_20026_d = dataInputStream1.readShort();
		short s2 = dataInputStream1.readShort();
		if(s2 >= 0) {
			byte b3 = dataInputStream1.readByte();
			byte b4 = dataInputStream1.readByte();
			this.field_20025_e = new ItemStack(s2, b3, b4);
		} else {
			this.field_20025_e = null;
		}

	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeByte(this.field_20024_a);
		dataOutputStream1.writeShort(this.field_20023_b);
		dataOutputStream1.writeByte(this.field_20027_c);
		dataOutputStream1.writeShort(this.field_20026_d);
		if(this.field_20025_e == null) {
			dataOutputStream1.writeShort(-1);
		} else {
			dataOutputStream1.writeShort(this.field_20025_e.itemID);
			dataOutputStream1.writeByte(this.field_20025_e.stackSize);
			dataOutputStream1.writeByte(this.field_20025_e.itemDamage);
		}

	}

	public int getPacketSize() {
		return 10;
	}
}
