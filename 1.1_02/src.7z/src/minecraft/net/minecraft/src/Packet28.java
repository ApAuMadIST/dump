package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet28 extends Packet {
	public int field_6367_a;
	public int field_6366_b;
	public int field_6369_c;
	public int field_6368_d;

	public Packet28() {
	}

	public Packet28(Entity entity1) {
		this(entity1.field_620_ab, entity1.motionX, entity1.motionY, entity1.motionZ);
	}

	public Packet28(int i1, double d2, double d4, double d6) {
		this.field_6367_a = i1;
		double d8 = 3.9D;
		if(d2 < -d8) {
			d2 = -d8;
		}

		if(d4 < -d8) {
			d4 = -d8;
		}

		if(d6 < -d8) {
			d6 = -d8;
		}

		if(d2 > d8) {
			d2 = d8;
		}

		if(d4 > d8) {
			d4 = d8;
		}

		if(d6 > d8) {
			d6 = d8;
		}

		this.field_6366_b = (int)(d2 * 8000.0D);
		this.field_6369_c = (int)(d4 * 8000.0D);
		this.field_6368_d = (int)(d6 * 8000.0D);
	}

	public void readPacketData(DataInputStream dataInputStream1) throws IOException {
		this.field_6367_a = dataInputStream1.readInt();
		this.field_6366_b = dataInputStream1.readShort();
		this.field_6369_c = dataInputStream1.readShort();
		this.field_6368_d = dataInputStream1.readShort();
	}

	public void writePacketData(DataOutputStream dataOutputStream1) throws IOException {
		dataOutputStream1.writeInt(this.field_6367_a);
		dataOutputStream1.writeShort(this.field_6366_b);
		dataOutputStream1.writeShort(this.field_6369_c);
		dataOutputStream1.writeShort(this.field_6368_d);
	}

	public void processPacket(NetHandler netHandler1) {
		netHandler1.func_6498_a(this);
	}

	public int getPacketSize() {
		return 10;
	}
}
