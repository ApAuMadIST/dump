package net.minecraft.src;

import org.lwjgl.opengl.GL11;

public class RenderBlocks {
	private IBlockAccess blockAccess;
	private int overrideBlockTexture = -1;
	private boolean flipTexture = false;
	private boolean renderAllFaces = false;

	public RenderBlocks(IBlockAccess iBlockAccess1) {
		this.blockAccess = iBlockAccess1;
	}

	public RenderBlocks() {
	}

	public void renderBlockUsingTexture(Block block1, int i2, int i3, int i4, int i5) {
		this.overrideBlockTexture = i5;
		this.renderBlockByRenderType(block1, i2, i3, i4);
		this.overrideBlockTexture = -1;
	}

	public boolean renderBlockByRenderType(Block block1, int i2, int i3, int i4) {
		int i5 = block1.getRenderType();
		block1.setBlockBoundsBasedOnState(this.blockAccess, i2, i3, i4);
		return i5 == 0 ? this.renderStandardBlock(block1, i2, i3, i4) : (i5 == 4 ? this.renderBlockFluids(block1, i2, i3, i4) : (i5 == 13 ? this.renderBlockCactus(block1, i2, i3, i4) : (i5 == 1 ? this.renderBlockReed(block1, i2, i3, i4) : (i5 == 6 ? this.renderBlockCrops(block1, i2, i3, i4) : (i5 == 2 ? this.renderBlockTorch(block1, i2, i3, i4) : (i5 == 3 ? this.renderBlockFire(block1, i2, i3, i4) : (i5 == 5 ? this.renderBlockRedstoneWire(block1, i2, i3, i4) : (i5 == 8 ? this.renderBlockLadder(block1, i2, i3, i4) : (i5 == 7 ? this.renderBlockDoor(block1, i2, i3, i4) : (i5 == 9 ? this.renderBlockMinecartTrack(block1, i2, i3, i4) : (i5 == 10 ? this.renderBlockStairs(block1, i2, i3, i4) : (i5 == 11 ? this.renderBlockFence(block1, i2, i3, i4) : (i5 == 12 ? this.renderBlockLever(block1, i2, i3, i4) : false)))))))))))));
	}

	public boolean renderBlockTorch(Block block1, int i2, int i3, int i4) {
		int i5 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		Tessellator tessellator6 = Tessellator.instance;
		float f7 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
		if(Block.lightValue[block1.blockID] > 0) {
			f7 = 1.0F;
		}

		tessellator6.setColorOpaque_F(f7, f7, f7);
		double d8 = (double)0.4F;
		double d10 = 0.5D - d8;
		double d12 = (double)0.2F;
		if(i5 == 1) {
			this.renderTorchAtAngle(block1, (double)i2 - d10, (double)i3 + d12, (double)i4, -d8, 0.0D);
		} else if(i5 == 2) {
			this.renderTorchAtAngle(block1, (double)i2 + d10, (double)i3 + d12, (double)i4, d8, 0.0D);
		} else if(i5 == 3) {
			this.renderTorchAtAngle(block1, (double)i2, (double)i3 + d12, (double)i4 - d10, 0.0D, -d8);
		} else if(i5 == 4) {
			this.renderTorchAtAngle(block1, (double)i2, (double)i3 + d12, (double)i4 + d10, 0.0D, d8);
		} else {
			this.renderTorchAtAngle(block1, (double)i2, (double)i3, (double)i4, 0.0D, 0.0D);
		}

		return true;
	}

	public boolean renderBlockLever(Block block1, int i2, int i3, int i4) {
		int i5 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		int i6 = i5 & 7;
		boolean z7 = (i5 & 8) > 0;
		Tessellator tessellator8 = Tessellator.instance;
		boolean z9 = this.overrideBlockTexture >= 0;
		if(!z9) {
			this.overrideBlockTexture = Block.cobblestone.blockIndexInTexture;
		}

		float f10 = 0.25F;
		float f11 = 0.1875F;
		float f12 = 0.1875F;
		if(i6 == 5) {
			block1.setBlockBounds(0.5F - f11, 0.0F, 0.5F - f10, 0.5F + f11, f12, 0.5F + f10);
		} else if(i6 == 6) {
			block1.setBlockBounds(0.5F - f10, 0.0F, 0.5F - f11, 0.5F + f10, f12, 0.5F + f11);
		} else if(i6 == 4) {
			block1.setBlockBounds(0.5F - f11, 0.5F - f10, 1.0F - f12, 0.5F + f11, 0.5F + f10, 1.0F);
		} else if(i6 == 3) {
			block1.setBlockBounds(0.5F - f11, 0.5F - f10, 0.0F, 0.5F + f11, 0.5F + f10, f12);
		} else if(i6 == 2) {
			block1.setBlockBounds(1.0F - f12, 0.5F - f10, 0.5F - f11, 1.0F, 0.5F + f10, 0.5F + f11);
		} else if(i6 == 1) {
			block1.setBlockBounds(0.0F, 0.5F - f10, 0.5F - f11, f12, 0.5F + f10, 0.5F + f11);
		}

		this.renderStandardBlock(block1, i2, i3, i4);
		if(!z9) {
			this.overrideBlockTexture = -1;
		}

		float f13 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
		if(Block.lightValue[block1.blockID] > 0) {
			f13 = 1.0F;
		}

		tessellator8.setColorOpaque_F(f13, f13, f13);
		int i14 = block1.getBlockTextureFromSide(0);
		if(this.overrideBlockTexture >= 0) {
			i14 = this.overrideBlockTexture;
		}

		int i15 = (i14 & 15) << 4;
		int i16 = i14 & 240;
		float f17 = (float)i15 / 256.0F;
		float f18 = ((float)i15 + 15.99F) / 256.0F;
		float f19 = (float)i16 / 256.0F;
		float f20 = ((float)i16 + 15.99F) / 256.0F;
		Vec3D[] vec3D21 = new Vec3D[8];
		float f22 = 0.0625F;
		float f23 = 0.0625F;
		float f24 = 0.625F;
		vec3D21[0] = Vec3D.createVector((double)(-f22), 0.0D, (double)(-f23));
		vec3D21[1] = Vec3D.createVector((double)f22, 0.0D, (double)(-f23));
		vec3D21[2] = Vec3D.createVector((double)f22, 0.0D, (double)f23);
		vec3D21[3] = Vec3D.createVector((double)(-f22), 0.0D, (double)f23);
		vec3D21[4] = Vec3D.createVector((double)(-f22), (double)f24, (double)(-f23));
		vec3D21[5] = Vec3D.createVector((double)f22, (double)f24, (double)(-f23));
		vec3D21[6] = Vec3D.createVector((double)f22, (double)f24, (double)f23);
		vec3D21[7] = Vec3D.createVector((double)(-f22), (double)f24, (double)f23);

		for(int i25 = 0; i25 < 8; ++i25) {
			if(z7) {
				vec3D21[i25].zCoord -= 0.0625D;
				vec3D21[i25].rotateAroundX((float)Math.PI / 4.5F);
			} else {
				vec3D21[i25].zCoord += 0.0625D;
				vec3D21[i25].rotateAroundX(-0.69813174F);
			}

			if(i6 == 6) {
				vec3D21[i25].rotateAroundY((float)Math.PI / 2F);
			}

			if(i6 < 5) {
				vec3D21[i25].yCoord -= 0.375D;
				vec3D21[i25].rotateAroundX((float)Math.PI / 2F);
				if(i6 == 4) {
					vec3D21[i25].rotateAroundY(0.0F);
				}

				if(i6 == 3) {
					vec3D21[i25].rotateAroundY((float)Math.PI);
				}

				if(i6 == 2) {
					vec3D21[i25].rotateAroundY((float)Math.PI / 2F);
				}

				if(i6 == 1) {
					vec3D21[i25].rotateAroundY(-1.5707964F);
				}

				vec3D21[i25].xCoord += (double)i2 + 0.5D;
				vec3D21[i25].yCoord += (double)((float)i3 + 0.5F);
				vec3D21[i25].zCoord += (double)i4 + 0.5D;
			} else {
				vec3D21[i25].xCoord += (double)i2 + 0.5D;
				vec3D21[i25].yCoord += (double)((float)i3 + 0.125F);
				vec3D21[i25].zCoord += (double)i4 + 0.5D;
			}
		}

		Vec3D vec3D30 = null;
		Vec3D vec3D26 = null;
		Vec3D vec3D27 = null;
		Vec3D vec3D28 = null;

		for(int i29 = 0; i29 < 6; ++i29) {
			if(i29 == 0) {
				f17 = (float)(i15 + 7) / 256.0F;
				f18 = ((float)(i15 + 9) - 0.01F) / 256.0F;
				f19 = (float)(i16 + 6) / 256.0F;
				f20 = ((float)(i16 + 8) - 0.01F) / 256.0F;
			} else if(i29 == 2) {
				f17 = (float)(i15 + 7) / 256.0F;
				f18 = ((float)(i15 + 9) - 0.01F) / 256.0F;
				f19 = (float)(i16 + 6) / 256.0F;
				f20 = ((float)(i16 + 16) - 0.01F) / 256.0F;
			}

			if(i29 == 0) {
				vec3D30 = vec3D21[0];
				vec3D26 = vec3D21[1];
				vec3D27 = vec3D21[2];
				vec3D28 = vec3D21[3];
			} else if(i29 == 1) {
				vec3D30 = vec3D21[7];
				vec3D26 = vec3D21[6];
				vec3D27 = vec3D21[5];
				vec3D28 = vec3D21[4];
			} else if(i29 == 2) {
				vec3D30 = vec3D21[1];
				vec3D26 = vec3D21[0];
				vec3D27 = vec3D21[4];
				vec3D28 = vec3D21[5];
			} else if(i29 == 3) {
				vec3D30 = vec3D21[2];
				vec3D26 = vec3D21[1];
				vec3D27 = vec3D21[5];
				vec3D28 = vec3D21[6];
			} else if(i29 == 4) {
				vec3D30 = vec3D21[3];
				vec3D26 = vec3D21[2];
				vec3D27 = vec3D21[6];
				vec3D28 = vec3D21[7];
			} else if(i29 == 5) {
				vec3D30 = vec3D21[0];
				vec3D26 = vec3D21[3];
				vec3D27 = vec3D21[7];
				vec3D28 = vec3D21[4];
			}

			tessellator8.addVertexWithUV(vec3D30.xCoord, vec3D30.yCoord, vec3D30.zCoord, (double)f17, (double)f20);
			tessellator8.addVertexWithUV(vec3D26.xCoord, vec3D26.yCoord, vec3D26.zCoord, (double)f18, (double)f20);
			tessellator8.addVertexWithUV(vec3D27.xCoord, vec3D27.yCoord, vec3D27.zCoord, (double)f18, (double)f19);
			tessellator8.addVertexWithUV(vec3D28.xCoord, vec3D28.yCoord, vec3D28.zCoord, (double)f17, (double)f19);
		}

		return true;
	}

	public boolean renderBlockFire(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		int i6 = block1.getBlockTextureFromSide(0);
		if(this.overrideBlockTexture >= 0) {
			i6 = this.overrideBlockTexture;
		}

		float f7 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
		tessellator5.setColorOpaque_F(f7, f7, f7);
		int i8 = (i6 & 15) << 4;
		int i9 = i6 & 240;
		double d10 = (double)((float)i8 / 256.0F);
		double d12 = (double)(((float)i8 + 15.99F) / 256.0F);
		double d14 = (double)((float)i9 / 256.0F);
		double d16 = (double)(((float)i9 + 15.99F) / 256.0F);
		float f18 = 1.4F;
		double d21;
		double d23;
		double d25;
		double d27;
		double d29;
		double d31;
		double d33;
		if(!this.blockAccess.isBlockOpaqueCube(i2, i3 - 1, i4) && !Block.fire.canBlockCatchFire(this.blockAccess, i2, i3 - 1, i4)) {
			float f37 = 0.2F;
			float f20 = 0.0625F;
			if((i2 + i3 + i4 & 1) == 1) {
				d10 = (double)((float)i8 / 256.0F);
				d12 = (double)(((float)i8 + 15.99F) / 256.0F);
				d14 = (double)((float)(i9 + 16) / 256.0F);
				d16 = (double)(((float)i9 + 15.99F + 16.0F) / 256.0F);
			}

			if((i2 / 2 + i3 / 2 + i4 / 2 & 1) == 1) {
				d21 = d12;
				d12 = d10;
				d10 = d21;
			}

			if(Block.fire.canBlockCatchFire(this.blockAccess, i2 - 1, i3, i4)) {
				tessellator5.addVertexWithUV((double)((float)i2 + f37), (double)((float)i3 + f18 + f20), (double)(i4 + 1), d12, d14);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 1), d12, d16);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 0), d10, d16);
				tessellator5.addVertexWithUV((double)((float)i2 + f37), (double)((float)i3 + f18 + f20), (double)(i4 + 0), d10, d14);
				tessellator5.addVertexWithUV((double)((float)i2 + f37), (double)((float)i3 + f18 + f20), (double)(i4 + 0), d10, d14);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 0), d10, d16);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 1), d12, d16);
				tessellator5.addVertexWithUV((double)((float)i2 + f37), (double)((float)i3 + f18 + f20), (double)(i4 + 1), d12, d14);
			}

			if(Block.fire.canBlockCatchFire(this.blockAccess, i2 + 1, i3, i4)) {
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f37), (double)((float)i3 + f18 + f20), (double)(i4 + 0), d10, d14);
				tessellator5.addVertexWithUV((double)(i2 + 1 - 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 0), d10, d16);
				tessellator5.addVertexWithUV((double)(i2 + 1 - 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 1), d12, d16);
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f37), (double)((float)i3 + f18 + f20), (double)(i4 + 1), d12, d14);
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f37), (double)((float)i3 + f18 + f20), (double)(i4 + 1), d12, d14);
				tessellator5.addVertexWithUV((double)(i2 + 1 - 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 1), d12, d16);
				tessellator5.addVertexWithUV((double)(i2 + 1 - 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 0), d10, d16);
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f37), (double)((float)i3 + f18 + f20), (double)(i4 + 0), d10, d14);
			}

			if(Block.fire.canBlockCatchFire(this.blockAccess, i2, i3, i4 - 1)) {
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f18 + f20), (double)((float)i4 + f37), d12, d14);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 0), d12, d16);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)(i3 + 0) + f20), (double)(i4 + 0), d10, d16);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f18 + f20), (double)((float)i4 + f37), d10, d14);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f18 + f20), (double)((float)i4 + f37), d10, d14);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)(i3 + 0) + f20), (double)(i4 + 0), d10, d16);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 0), d12, d16);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f18 + f20), (double)((float)i4 + f37), d12, d14);
			}

			if(Block.fire.canBlockCatchFire(this.blockAccess, i2, i3, i4 + 1)) {
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f18 + f20), (double)((float)(i4 + 1) - f37), d10, d14);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)(i3 + 0) + f20), (double)(i4 + 1 - 0), d10, d16);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 1 - 0), d12, d16);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f18 + f20), (double)((float)(i4 + 1) - f37), d12, d14);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f18 + f20), (double)((float)(i4 + 1) - f37), d12, d14);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f20), (double)(i4 + 1 - 0), d12, d16);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)(i3 + 0) + f20), (double)(i4 + 1 - 0), d10, d16);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f18 + f20), (double)((float)(i4 + 1) - f37), d10, d14);
			}

			if(Block.fire.canBlockCatchFire(this.blockAccess, i2, i3 + 1, i4)) {
				d21 = (double)i2 + 0.5D + 0.5D;
				d23 = (double)i2 + 0.5D - 0.5D;
				d25 = (double)i4 + 0.5D + 0.5D;
				d27 = (double)i4 + 0.5D - 0.5D;
				d29 = (double)i2 + 0.5D - 0.5D;
				d31 = (double)i2 + 0.5D + 0.5D;
				d33 = (double)i4 + 0.5D - 0.5D;
				double d35 = (double)i4 + 0.5D + 0.5D;
				d10 = (double)((float)i8 / 256.0F);
				d12 = (double)(((float)i8 + 15.99F) / 256.0F);
				d14 = (double)((float)i9 / 256.0F);
				d16 = (double)(((float)i9 + 15.99F) / 256.0F);
				++i3;
				f18 = -0.2F;
				if((i2 + i3 + i4 & 1) == 0) {
					tessellator5.addVertexWithUV(d29, (double)((float)i3 + f18), (double)(i4 + 0), d12, d14);
					tessellator5.addVertexWithUV(d21, (double)(i3 + 0), (double)(i4 + 0), d12, d16);
					tessellator5.addVertexWithUV(d21, (double)(i3 + 0), (double)(i4 + 1), d10, d16);
					tessellator5.addVertexWithUV(d29, (double)((float)i3 + f18), (double)(i4 + 1), d10, d14);
					d10 = (double)((float)i8 / 256.0F);
					d12 = (double)(((float)i8 + 15.99F) / 256.0F);
					d14 = (double)((float)(i9 + 16) / 256.0F);
					d16 = (double)(((float)i9 + 15.99F + 16.0F) / 256.0F);
					tessellator5.addVertexWithUV(d31, (double)((float)i3 + f18), (double)(i4 + 1), d12, d14);
					tessellator5.addVertexWithUV(d23, (double)(i3 + 0), (double)(i4 + 1), d12, d16);
					tessellator5.addVertexWithUV(d23, (double)(i3 + 0), (double)(i4 + 0), d10, d16);
					tessellator5.addVertexWithUV(d31, (double)((float)i3 + f18), (double)(i4 + 0), d10, d14);
				} else {
					tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f18), d35, d12, d14);
					tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d27, d12, d16);
					tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d27, d10, d16);
					tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f18), d35, d10, d14);
					d10 = (double)((float)i8 / 256.0F);
					d12 = (double)(((float)i8 + 15.99F) / 256.0F);
					d14 = (double)((float)(i9 + 16) / 256.0F);
					d16 = (double)(((float)i9 + 15.99F + 16.0F) / 256.0F);
					tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f18), d33, d12, d14);
					tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d25, d12, d16);
					tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d25, d10, d16);
					tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f18), d33, d10, d14);
				}
			}
		} else {
			double d19 = (double)i2 + 0.5D + 0.2D;
			d21 = (double)i2 + 0.5D - 0.2D;
			d23 = (double)i4 + 0.5D + 0.2D;
			d25 = (double)i4 + 0.5D - 0.2D;
			d27 = (double)i2 + 0.5D - 0.3D;
			d29 = (double)i2 + 0.5D + 0.3D;
			d31 = (double)i4 + 0.5D - 0.3D;
			d33 = (double)i4 + 0.5D + 0.3D;
			tessellator5.addVertexWithUV(d27, (double)((float)i3 + f18), (double)(i4 + 1), d12, d14);
			tessellator5.addVertexWithUV(d19, (double)(i3 + 0), (double)(i4 + 1), d12, d16);
			tessellator5.addVertexWithUV(d19, (double)(i3 + 0), (double)(i4 + 0), d10, d16);
			tessellator5.addVertexWithUV(d27, (double)((float)i3 + f18), (double)(i4 + 0), d10, d14);
			tessellator5.addVertexWithUV(d29, (double)((float)i3 + f18), (double)(i4 + 0), d12, d14);
			tessellator5.addVertexWithUV(d21, (double)(i3 + 0), (double)(i4 + 0), d12, d16);
			tessellator5.addVertexWithUV(d21, (double)(i3 + 0), (double)(i4 + 1), d10, d16);
			tessellator5.addVertexWithUV(d29, (double)((float)i3 + f18), (double)(i4 + 1), d10, d14);
			d10 = (double)((float)i8 / 256.0F);
			d12 = (double)(((float)i8 + 15.99F) / 256.0F);
			d14 = (double)((float)(i9 + 16) / 256.0F);
			d16 = (double)(((float)i9 + 15.99F + 16.0F) / 256.0F);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f18), d33, d12, d14);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d25, d12, d16);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d25, d10, d16);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f18), d33, d10, d14);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f18), d31, d12, d14);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d23, d12, d16);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d23, d10, d16);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f18), d31, d10, d14);
			d19 = (double)i2 + 0.5D - 0.5D;
			d21 = (double)i2 + 0.5D + 0.5D;
			d23 = (double)i4 + 0.5D - 0.5D;
			d25 = (double)i4 + 0.5D + 0.5D;
			d27 = (double)i2 + 0.5D - 0.4D;
			d29 = (double)i2 + 0.5D + 0.4D;
			d31 = (double)i4 + 0.5D - 0.4D;
			d33 = (double)i4 + 0.5D + 0.4D;
			tessellator5.addVertexWithUV(d27, (double)((float)i3 + f18), (double)(i4 + 0), d10, d14);
			tessellator5.addVertexWithUV(d19, (double)(i3 + 0), (double)(i4 + 0), d10, d16);
			tessellator5.addVertexWithUV(d19, (double)(i3 + 0), (double)(i4 + 1), d12, d16);
			tessellator5.addVertexWithUV(d27, (double)((float)i3 + f18), (double)(i4 + 1), d12, d14);
			tessellator5.addVertexWithUV(d29, (double)((float)i3 + f18), (double)(i4 + 1), d10, d14);
			tessellator5.addVertexWithUV(d21, (double)(i3 + 0), (double)(i4 + 1), d10, d16);
			tessellator5.addVertexWithUV(d21, (double)(i3 + 0), (double)(i4 + 0), d12, d16);
			tessellator5.addVertexWithUV(d29, (double)((float)i3 + f18), (double)(i4 + 0), d12, d14);
			d10 = (double)((float)i8 / 256.0F);
			d12 = (double)(((float)i8 + 15.99F) / 256.0F);
			d14 = (double)((float)i9 / 256.0F);
			d16 = (double)(((float)i9 + 15.99F) / 256.0F);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f18), d33, d10, d14);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d25, d10, d16);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d25, d12, d16);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f18), d33, d12, d14);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f18), d31, d10, d14);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d23, d10, d16);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d23, d12, d16);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f18), d31, d12, d14);
		}

		return true;
	}

	public boolean renderBlockRedstoneWire(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		int i6 = block1.getBlockTextureFromSideAndMetadata(1, this.blockAccess.getBlockMetadata(i2, i3, i4));
		if(this.overrideBlockTexture >= 0) {
			i6 = this.overrideBlockTexture;
		}

		float f7 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
		tessellator5.setColorOpaque_F(f7, f7, f7);
		int i8 = (i6 & 15) << 4;
		int i9 = i6 & 240;
		double d10 = (double)((float)i8 / 256.0F);
		double d12 = (double)(((float)i8 + 15.99F) / 256.0F);
		double d14 = (double)((float)i9 / 256.0F);
		double d16 = (double)(((float)i9 + 15.99F) / 256.0F);
		float f18 = 0.0F;
		float f19 = 0.03125F;
		boolean z20 = BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 - 1, i3, i4) || !this.blockAccess.isBlockOpaqueCube(i2 - 1, i3, i4) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 - 1, i3 - 1, i4);
		boolean z21 = BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 + 1, i3, i4) || !this.blockAccess.isBlockOpaqueCube(i2 + 1, i3, i4) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 + 1, i3 - 1, i4);
		boolean z22 = BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3, i4 - 1) || !this.blockAccess.isBlockOpaqueCube(i2, i3, i4 - 1) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3 - 1, i4 - 1);
		boolean z23 = BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3, i4 + 1) || !this.blockAccess.isBlockOpaqueCube(i2, i3, i4 + 1) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3 - 1, i4 + 1);
		if(!this.blockAccess.isBlockOpaqueCube(i2, i3 + 1, i4)) {
			if(this.blockAccess.isBlockOpaqueCube(i2 - 1, i3, i4) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 - 1, i3 + 1, i4)) {
				z20 = true;
			}

			if(this.blockAccess.isBlockOpaqueCube(i2 + 1, i3, i4) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 + 1, i3 + 1, i4)) {
				z21 = true;
			}

			if(this.blockAccess.isBlockOpaqueCube(i2, i3, i4 - 1) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3 + 1, i4 - 1)) {
				z22 = true;
			}

			if(this.blockAccess.isBlockOpaqueCube(i2, i3, i4 + 1) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3 + 1, i4 + 1)) {
				z23 = true;
			}
		}

		float f24 = 0.3125F;
		float f25 = (float)(i2 + 0);
		float f26 = (float)(i2 + 1);
		float f27 = (float)(i4 + 0);
		float f28 = (float)(i4 + 1);
		byte b29 = 0;
		if((z20 || z21) && !z22 && !z23) {
			b29 = 1;
		}

		if((z22 || z23) && !z21 && !z20) {
			b29 = 2;
		}

		if(b29 != 0) {
			d10 = (double)((float)(i8 + 16) / 256.0F);
			d12 = (double)(((float)(i8 + 16) + 15.99F) / 256.0F);
			d14 = (double)((float)i9 / 256.0F);
			d16 = (double)(((float)i9 + 15.99F) / 256.0F);
		}

		if(b29 == 0) {
			if(z21 || z22 || z23 || z20) {
				if(!z20) {
					f25 += f24;
				}

				if(!z20) {
					d10 += (double)(f24 / 16.0F);
				}

				if(!z21) {
					f26 -= f24;
				}

				if(!z21) {
					d12 -= (double)(f24 / 16.0F);
				}

				if(!z22) {
					f27 += f24;
				}

				if(!z22) {
					d14 += (double)(f24 / 16.0F);
				}

				if(!z23) {
					f28 -= f24;
				}

				if(!z23) {
					d16 -= (double)(f24 / 16.0F);
				}
			}

			tessellator5.addVertexWithUV((double)(f26 + f18), (double)((float)i3 + f19), (double)(f28 + f18), d12, d16);
			tessellator5.addVertexWithUV((double)(f26 + f18), (double)((float)i3 + f19), (double)(f27 - f18), d12, d14);
			tessellator5.addVertexWithUV((double)(f25 - f18), (double)((float)i3 + f19), (double)(f27 - f18), d10, d14);
			tessellator5.addVertexWithUV((double)(f25 - f18), (double)((float)i3 + f19), (double)(f28 + f18), d10, d16);
		}

		if(b29 == 1) {
			tessellator5.addVertexWithUV((double)(f26 + f18), (double)((float)i3 + f19), (double)(f28 + f18), d12, d16);
			tessellator5.addVertexWithUV((double)(f26 + f18), (double)((float)i3 + f19), (double)(f27 - f18), d12, d14);
			tessellator5.addVertexWithUV((double)(f25 - f18), (double)((float)i3 + f19), (double)(f27 - f18), d10, d14);
			tessellator5.addVertexWithUV((double)(f25 - f18), (double)((float)i3 + f19), (double)(f28 + f18), d10, d16);
		}

		if(b29 == 2) {
			tessellator5.addVertexWithUV((double)(f26 + f18), (double)((float)i3 + f19), (double)(f28 + f18), d12, d16);
			tessellator5.addVertexWithUV((double)(f26 + f18), (double)((float)i3 + f19), (double)(f27 - f18), d10, d16);
			tessellator5.addVertexWithUV((double)(f25 - f18), (double)((float)i3 + f19), (double)(f27 - f18), d10, d14);
			tessellator5.addVertexWithUV((double)(f25 - f18), (double)((float)i3 + f19), (double)(f28 + f18), d12, d14);
		}

		d10 = (double)((float)(i8 + 16) / 256.0F);
		d12 = (double)(((float)(i8 + 16) + 15.99F) / 256.0F);
		d14 = (double)((float)i9 / 256.0F);
		d16 = (double)(((float)i9 + 15.99F) / 256.0F);
		if(!this.blockAccess.isBlockOpaqueCube(i2, i3 + 1, i4)) {
			if(this.blockAccess.isBlockOpaqueCube(i2 - 1, i3, i4) && this.blockAccess.getBlockId(i2 - 1, i3 + 1, i4) == Block.redstoneWire.blockID) {
				tessellator5.addVertexWithUV((double)((float)i2 + f19), (double)((float)(i3 + 1) + f18), (double)((float)(i4 + 1) + f18), d12, d14);
				tessellator5.addVertexWithUV((double)((float)i2 + f19), (double)((float)(i3 + 0) - f18), (double)((float)(i4 + 1) + f18), d10, d14);
				tessellator5.addVertexWithUV((double)((float)i2 + f19), (double)((float)(i3 + 0) - f18), (double)((float)(i4 + 0) - f18), d10, d16);
				tessellator5.addVertexWithUV((double)((float)i2 + f19), (double)((float)(i3 + 1) + f18), (double)((float)(i4 + 0) - f18), d12, d16);
			}

			if(this.blockAccess.isBlockOpaqueCube(i2 + 1, i3, i4) && this.blockAccess.getBlockId(i2 + 1, i3 + 1, i4) == Block.redstoneWire.blockID) {
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f19), (double)((float)(i3 + 0) - f18), (double)((float)(i4 + 1) + f18), d10, d16);
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f19), (double)((float)(i3 + 1) + f18), (double)((float)(i4 + 1) + f18), d12, d16);
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f19), (double)((float)(i3 + 1) + f18), (double)((float)(i4 + 0) - f18), d12, d14);
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f19), (double)((float)(i3 + 0) - f18), (double)((float)(i4 + 0) - f18), d10, d14);
			}

			if(this.blockAccess.isBlockOpaqueCube(i2, i3, i4 - 1) && this.blockAccess.getBlockId(i2, i3 + 1, i4 - 1) == Block.redstoneWire.blockID) {
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) + f18), (double)((float)(i3 + 0) - f18), (double)((float)i4 + f19), d10, d16);
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) + f18), (double)((float)(i3 + 1) + f18), (double)((float)i4 + f19), d12, d16);
				tessellator5.addVertexWithUV((double)((float)(i2 + 0) - f18), (double)((float)(i3 + 1) + f18), (double)((float)i4 + f19), d12, d14);
				tessellator5.addVertexWithUV((double)((float)(i2 + 0) - f18), (double)((float)(i3 + 0) - f18), (double)((float)i4 + f19), d10, d14);
			}

			if(this.blockAccess.isBlockOpaqueCube(i2, i3, i4 + 1) && this.blockAccess.getBlockId(i2, i3 + 1, i4 + 1) == Block.redstoneWire.blockID) {
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) + f18), (double)((float)(i3 + 1) + f18), (double)((float)(i4 + 1) - f19), d12, d14);
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) + f18), (double)((float)(i3 + 0) - f18), (double)((float)(i4 + 1) - f19), d10, d14);
				tessellator5.addVertexWithUV((double)((float)(i2 + 0) - f18), (double)((float)(i3 + 0) - f18), (double)((float)(i4 + 1) - f19), d10, d16);
				tessellator5.addVertexWithUV((double)((float)(i2 + 0) - f18), (double)((float)(i3 + 1) + f18), (double)((float)(i4 + 1) - f19), d12, d16);
			}
		}

		return true;
	}

	public boolean renderBlockMinecartTrack(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		int i6 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		int i7 = block1.getBlockTextureFromSideAndMetadata(0, i6);
		if(this.overrideBlockTexture >= 0) {
			i7 = this.overrideBlockTexture;
		}

		float f8 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
		tessellator5.setColorOpaque_F(f8, f8, f8);
		int i9 = (i7 & 15) << 4;
		int i10 = i7 & 240;
		double d11 = (double)((float)i9 / 256.0F);
		double d13 = (double)(((float)i9 + 15.99F) / 256.0F);
		double d15 = (double)((float)i10 / 256.0F);
		double d17 = (double)(((float)i10 + 15.99F) / 256.0F);
		float f19 = 0.0625F;
		float f20 = (float)(i2 + 1);
		float f21 = (float)(i2 + 1);
		float f22 = (float)(i2 + 0);
		float f23 = (float)(i2 + 0);
		float f24 = (float)(i4 + 0);
		float f25 = (float)(i4 + 1);
		float f26 = (float)(i4 + 1);
		float f27 = (float)(i4 + 0);
		float f28 = (float)i3 + f19;
		float f29 = (float)i3 + f19;
		float f30 = (float)i3 + f19;
		float f31 = (float)i3 + f19;
		if(i6 != 1 && i6 != 2 && i6 != 3 && i6 != 7) {
			if(i6 == 8) {
				f20 = f21 = (float)(i2 + 0);
				f22 = f23 = (float)(i2 + 1);
				f24 = f27 = (float)(i4 + 1);
				f25 = f26 = (float)(i4 + 0);
			} else if(i6 == 9) {
				f20 = f23 = (float)(i2 + 0);
				f21 = f22 = (float)(i2 + 1);
				f24 = f25 = (float)(i4 + 0);
				f26 = f27 = (float)(i4 + 1);
			}
		} else {
			f20 = f23 = (float)(i2 + 1);
			f21 = f22 = (float)(i2 + 0);
			f24 = f25 = (float)(i4 + 1);
			f26 = f27 = (float)(i4 + 0);
		}

		if(i6 != 2 && i6 != 4) {
			if(i6 == 3 || i6 == 5) {
				++f29;
				++f30;
			}
		} else {
			++f28;
			++f31;
		}

		tessellator5.addVertexWithUV((double)f20, (double)f28, (double)f24, d13, d15);
		tessellator5.addVertexWithUV((double)f21, (double)f29, (double)f25, d13, d17);
		tessellator5.addVertexWithUV((double)f22, (double)f30, (double)f26, d11, d17);
		tessellator5.addVertexWithUV((double)f23, (double)f31, (double)f27, d11, d15);
		tessellator5.addVertexWithUV((double)f23, (double)f31, (double)f27, d11, d15);
		tessellator5.addVertexWithUV((double)f22, (double)f30, (double)f26, d11, d17);
		tessellator5.addVertexWithUV((double)f21, (double)f29, (double)f25, d13, d17);
		tessellator5.addVertexWithUV((double)f20, (double)f28, (double)f24, d13, d15);
		return true;
	}

	public boolean renderBlockLadder(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		int i6 = block1.getBlockTextureFromSide(0);
		if(this.overrideBlockTexture >= 0) {
			i6 = this.overrideBlockTexture;
		}

		float f7 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
		tessellator5.setColorOpaque_F(f7, f7, f7);
		int i8 = (i6 & 15) << 4;
		int i9 = i6 & 240;
		double d10 = (double)((float)i8 / 256.0F);
		double d12 = (double)(((float)i8 + 15.99F) / 256.0F);
		double d14 = (double)((float)i9 / 256.0F);
		double d16 = (double)(((float)i9 + 15.99F) / 256.0F);
		int i18 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		float f19 = 0.0F;
		float f20 = 0.05F;
		if(i18 == 5) {
			tessellator5.addVertexWithUV((double)((float)i2 + f20), (double)((float)(i3 + 1) + f19), (double)((float)(i4 + 1) + f19), d10, d14);
			tessellator5.addVertexWithUV((double)((float)i2 + f20), (double)((float)(i3 + 0) - f19), (double)((float)(i4 + 1) + f19), d10, d16);
			tessellator5.addVertexWithUV((double)((float)i2 + f20), (double)((float)(i3 + 0) - f19), (double)((float)(i4 + 0) - f19), d12, d16);
			tessellator5.addVertexWithUV((double)((float)i2 + f20), (double)((float)(i3 + 1) + f19), (double)((float)(i4 + 0) - f19), d12, d14);
		}

		if(i18 == 4) {
			tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f20), (double)((float)(i3 + 0) - f19), (double)((float)(i4 + 1) + f19), d12, d16);
			tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f20), (double)((float)(i3 + 1) + f19), (double)((float)(i4 + 1) + f19), d12, d14);
			tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f20), (double)((float)(i3 + 1) + f19), (double)((float)(i4 + 0) - f19), d10, d14);
			tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f20), (double)((float)(i3 + 0) - f19), (double)((float)(i4 + 0) - f19), d10, d16);
		}

		if(i18 == 3) {
			tessellator5.addVertexWithUV((double)((float)(i2 + 1) + f19), (double)((float)(i3 + 0) - f19), (double)((float)i4 + f20), d12, d16);
			tessellator5.addVertexWithUV((double)((float)(i2 + 1) + f19), (double)((float)(i3 + 1) + f19), (double)((float)i4 + f20), d12, d14);
			tessellator5.addVertexWithUV((double)((float)(i2 + 0) - f19), (double)((float)(i3 + 1) + f19), (double)((float)i4 + f20), d10, d14);
			tessellator5.addVertexWithUV((double)((float)(i2 + 0) - f19), (double)((float)(i3 + 0) - f19), (double)((float)i4 + f20), d10, d16);
		}

		if(i18 == 2) {
			tessellator5.addVertexWithUV((double)((float)(i2 + 1) + f19), (double)((float)(i3 + 1) + f19), (double)((float)(i4 + 1) - f20), d10, d14);
			tessellator5.addVertexWithUV((double)((float)(i2 + 1) + f19), (double)((float)(i3 + 0) - f19), (double)((float)(i4 + 1) - f20), d10, d16);
			tessellator5.addVertexWithUV((double)((float)(i2 + 0) - f19), (double)((float)(i3 + 0) - f19), (double)((float)(i4 + 1) - f20), d12, d16);
			tessellator5.addVertexWithUV((double)((float)(i2 + 0) - f19), (double)((float)(i3 + 1) + f19), (double)((float)(i4 + 1) - f20), d12, d14);
		}

		return true;
	}

	public boolean renderBlockReed(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		float f6 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
		tessellator5.setColorOpaque_F(f6, f6, f6);
		this.func_1239_a(block1, this.blockAccess.getBlockMetadata(i2, i3, i4), (double)i2, (double)i3, (double)i4);
		return true;
	}

	public boolean renderBlockCrops(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		float f6 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
		tessellator5.setColorOpaque_F(f6, f6, f6);
		this.func_1245_b(block1, this.blockAccess.getBlockMetadata(i2, i3, i4), (double)i2, (double)((float)i3 - 0.0625F), (double)i4);
		return true;
	}

	public void renderTorchAtAngle(Block block1, double d2, double d4, double d6, double d8, double d10) {
		Tessellator tessellator12 = Tessellator.instance;
		int i13 = block1.getBlockTextureFromSide(0);
		if(this.overrideBlockTexture >= 0) {
			i13 = this.overrideBlockTexture;
		}

		int i14 = (i13 & 15) << 4;
		int i15 = i13 & 240;
		float f16 = (float)i14 / 256.0F;
		float f17 = ((float)i14 + 15.99F) / 256.0F;
		float f18 = (float)i15 / 256.0F;
		float f19 = ((float)i15 + 15.99F) / 256.0F;
		double d20 = (double)f16 + 7.0D / 256D;
		double d22 = (double)f18 + 6.0D / 256D;
		double d24 = (double)f16 + 9.0D / 256D;
		double d26 = (double)f18 + 8.0D / 256D;
		d2 += 0.5D;
		d6 += 0.5D;
		double d28 = d2 - 0.5D;
		double d30 = d2 + 0.5D;
		double d32 = d6 - 0.5D;
		double d34 = d6 + 0.5D;
		double d36 = 0.0625D;
		double d38 = 0.625D;
		tessellator12.addVertexWithUV(d2 + d8 * (1.0D - d38) - d36, d4 + d38, d6 + d10 * (1.0D - d38) - d36, d20, d22);
		tessellator12.addVertexWithUV(d2 + d8 * (1.0D - d38) - d36, d4 + d38, d6 + d10 * (1.0D - d38) + d36, d20, d26);
		tessellator12.addVertexWithUV(d2 + d8 * (1.0D - d38) + d36, d4 + d38, d6 + d10 * (1.0D - d38) + d36, d24, d26);
		tessellator12.addVertexWithUV(d2 + d8 * (1.0D - d38) + d36, d4 + d38, d6 + d10 * (1.0D - d38) - d36, d24, d22);
		tessellator12.addVertexWithUV(d2 - d36, d4 + 1.0D, d32, (double)f16, (double)f18);
		tessellator12.addVertexWithUV(d2 - d36 + d8, d4 + 0.0D, d32 + d10, (double)f16, (double)f19);
		tessellator12.addVertexWithUV(d2 - d36 + d8, d4 + 0.0D, d34 + d10, (double)f17, (double)f19);
		tessellator12.addVertexWithUV(d2 - d36, d4 + 1.0D, d34, (double)f17, (double)f18);
		tessellator12.addVertexWithUV(d2 + d36, d4 + 1.0D, d34, (double)f16, (double)f18);
		tessellator12.addVertexWithUV(d2 + d8 + d36, d4 + 0.0D, d34 + d10, (double)f16, (double)f19);
		tessellator12.addVertexWithUV(d2 + d8 + d36, d4 + 0.0D, d32 + d10, (double)f17, (double)f19);
		tessellator12.addVertexWithUV(d2 + d36, d4 + 1.0D, d32, (double)f17, (double)f18);
		tessellator12.addVertexWithUV(d28, d4 + 1.0D, d6 + d36, (double)f16, (double)f18);
		tessellator12.addVertexWithUV(d28 + d8, d4 + 0.0D, d6 + d36 + d10, (double)f16, (double)f19);
		tessellator12.addVertexWithUV(d30 + d8, d4 + 0.0D, d6 + d36 + d10, (double)f17, (double)f19);
		tessellator12.addVertexWithUV(d30, d4 + 1.0D, d6 + d36, (double)f17, (double)f18);
		tessellator12.addVertexWithUV(d30, d4 + 1.0D, d6 - d36, (double)f16, (double)f18);
		tessellator12.addVertexWithUV(d30 + d8, d4 + 0.0D, d6 - d36 + d10, (double)f16, (double)f19);
		tessellator12.addVertexWithUV(d28 + d8, d4 + 0.0D, d6 - d36 + d10, (double)f17, (double)f19);
		tessellator12.addVertexWithUV(d28, d4 + 1.0D, d6 - d36, (double)f17, (double)f18);
	}

	public void func_1239_a(Block block1, int i2, double d3, double d5, double d7) {
		Tessellator tessellator9 = Tessellator.instance;
		int i10 = block1.getBlockTextureFromSideAndMetadata(0, i2);
		if(this.overrideBlockTexture >= 0) {
			i10 = this.overrideBlockTexture;
		}

		int i11 = (i10 & 15) << 4;
		int i12 = i10 & 240;
		double d13 = (double)((float)i11 / 256.0F);
		double d15 = (double)(((float)i11 + 15.99F) / 256.0F);
		double d17 = (double)((float)i12 / 256.0F);
		double d19 = (double)(((float)i12 + 15.99F) / 256.0F);
		double d21 = d3 + 0.5D - (double)0.45F;
		double d23 = d3 + 0.5D + (double)0.45F;
		double d25 = d7 + 0.5D - (double)0.45F;
		double d27 = d7 + 0.5D + (double)0.45F;
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d25, d13, d17);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d25, d13, d19);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d27, d15, d19);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d27, d15, d17);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d27, d13, d17);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d27, d13, d19);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d25, d15, d19);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d25, d15, d17);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d27, d13, d17);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d27, d13, d19);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d25, d15, d19);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d25, d15, d17);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d25, d13, d17);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d25, d13, d19);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d27, d15, d19);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d27, d15, d17);
	}

	public void func_1245_b(Block block1, int i2, double d3, double d5, double d7) {
		Tessellator tessellator9 = Tessellator.instance;
		int i10 = block1.getBlockTextureFromSideAndMetadata(0, i2);
		if(this.overrideBlockTexture >= 0) {
			i10 = this.overrideBlockTexture;
		}

		int i11 = (i10 & 15) << 4;
		int i12 = i10 & 240;
		double d13 = (double)((float)i11 / 256.0F);
		double d15 = (double)(((float)i11 + 15.99F) / 256.0F);
		double d17 = (double)((float)i12 / 256.0F);
		double d19 = (double)(((float)i12 + 15.99F) / 256.0F);
		double d21 = d3 + 0.5D - 0.25D;
		double d23 = d3 + 0.5D + 0.25D;
		double d25 = d7 + 0.5D - 0.5D;
		double d27 = d7 + 0.5D + 0.5D;
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d25, d13, d17);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d25, d13, d19);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d27, d15, d19);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d27, d15, d17);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d27, d13, d17);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d27, d13, d19);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d25, d15, d19);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d25, d15, d17);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d27, d13, d17);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d27, d13, d19);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d25, d15, d19);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d25, d15, d17);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d25, d13, d17);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d25, d13, d19);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d27, d15, d19);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d27, d15, d17);
		d21 = d3 + 0.5D - 0.5D;
		d23 = d3 + 0.5D + 0.5D;
		d25 = d7 + 0.5D - 0.25D;
		d27 = d7 + 0.5D + 0.25D;
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d25, d13, d17);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d25, d13, d19);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d25, d15, d19);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d25, d15, d17);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d25, d13, d17);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d25, d13, d19);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d25, d15, d19);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d25, d15, d17);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d27, d13, d17);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d27, d13, d19);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d27, d15, d19);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d27, d15, d17);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d27, d13, d17);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d27, d13, d19);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d27, d15, d19);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d27, d15, d17);
	}

	public boolean renderBlockFluids(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		boolean z6 = block1.shouldSideBeRendered(this.blockAccess, i2, i3 + 1, i4, 1);
		boolean z7 = block1.shouldSideBeRendered(this.blockAccess, i2, i3 - 1, i4, 0);
		boolean[] z8 = new boolean[]{block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 - 1, 2), block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 + 1, 3), block1.shouldSideBeRendered(this.blockAccess, i2 - 1, i3, i4, 4), block1.shouldSideBeRendered(this.blockAccess, i2 + 1, i3, i4, 5)};
		if(!z6 && !z7 && !z8[0] && !z8[1] && !z8[2] && !z8[3]) {
			return false;
		} else {
			boolean z9 = false;
			float f10 = 0.5F;
			float f11 = 1.0F;
			float f12 = 0.8F;
			float f13 = 0.6F;
			double d14 = 0.0D;
			double d16 = 1.0D;
			Material material18 = block1.blockMaterial;
			int i19 = this.blockAccess.getBlockMetadata(i2, i3, i4);
			float f20 = this.func_1224_a(i2, i3, i4, material18);
			float f21 = this.func_1224_a(i2, i3, i4 + 1, material18);
			float f22 = this.func_1224_a(i2 + 1, i3, i4 + 1, material18);
			float f23 = this.func_1224_a(i2 + 1, i3, i4, material18);
			int i24;
			int i27;
			float f32;
			float f33;
			float f34;
			if(this.renderAllFaces || z6) {
				z9 = true;
				i24 = block1.getBlockTextureFromSideAndMetadata(1, i19);
				float f25 = (float)BlockFluids.func_293_a(this.blockAccess, i2, i3, i4, material18);
				if(f25 > -999.0F) {
					i24 = block1.getBlockTextureFromSideAndMetadata(2, i19);
				}

				int i26 = (i24 & 15) << 4;
				i27 = i24 & 240;
				double d28 = ((double)i26 + 8.0D) / 256.0D;
				double d30 = ((double)i27 + 8.0D) / 256.0D;
				if(f25 < -999.0F) {
					f25 = 0.0F;
				} else {
					d28 = (double)((float)(i26 + 16) / 256.0F);
					d30 = (double)((float)(i27 + 16) / 256.0F);
				}

				f32 = MathHelper.sin(f25) * 8.0F / 256.0F;
				f33 = MathHelper.cos(f25) * 8.0F / 256.0F;
				f34 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
				tessellator5.setColorOpaque_F(f11 * f34, f11 * f34, f11 * f34);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f20), (double)(i4 + 0), d28 - (double)f33 - (double)f32, d30 - (double)f33 + (double)f32);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f21), (double)(i4 + 1), d28 - (double)f33 + (double)f32, d30 + (double)f33 + (double)f32);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f22), (double)(i4 + 1), d28 + (double)f33 + (double)f32, d30 + (double)f33 - (double)f32);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f23), (double)(i4 + 0), d28 + (double)f33 - (double)f32, d30 - (double)f33 - (double)f32);
			}

			if(this.renderAllFaces || z7) {
				float f48 = block1.getBlockBrightness(this.blockAccess, i2, i3 - 1, i4);
				tessellator5.setColorOpaque_F(f10 * f48, f10 * f48, f10 * f48);
				this.renderBottomFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTextureFromSide(0));
				z9 = true;
			}

			for(i24 = 0; i24 < 4; ++i24) {
				int i49 = i2;
				i27 = i4;
				if(i24 == 0) {
					i27 = i4 - 1;
				}

				if(i24 == 1) {
					++i27;
				}

				if(i24 == 2) {
					i49 = i2 - 1;
				}

				if(i24 == 3) {
					++i49;
				}

				int i50 = block1.getBlockTextureFromSideAndMetadata(i24 + 2, i19);
				int i29 = (i50 & 15) << 4;
				int i51 = i50 & 240;
				if(this.renderAllFaces || z8[i24]) {
					float f31;
					float f35;
					float f36;
					if(i24 == 0) {
						f31 = f20;
						f32 = f23;
						f33 = (float)i2;
						f35 = (float)(i2 + 1);
						f34 = (float)i4;
						f36 = (float)i4;
					} else if(i24 == 1) {
						f31 = f22;
						f32 = f21;
						f33 = (float)(i2 + 1);
						f35 = (float)i2;
						f34 = (float)(i4 + 1);
						f36 = (float)(i4 + 1);
					} else if(i24 == 2) {
						f31 = f21;
						f32 = f20;
						f33 = (float)i2;
						f35 = (float)i2;
						f34 = (float)(i4 + 1);
						f36 = (float)i4;
					} else {
						f31 = f23;
						f32 = f22;
						f33 = (float)(i2 + 1);
						f35 = (float)(i2 + 1);
						f34 = (float)i4;
						f36 = (float)(i4 + 1);
					}

					z9 = true;
					double d37 = (double)((float)(i29 + 0) / 256.0F);
					double d39 = ((double)(i29 + 16) - 0.01D) / 256.0D;
					double d41 = (double)(((float)i51 + (1.0F - f31) * 16.0F) / 256.0F);
					double d43 = (double)(((float)i51 + (1.0F - f32) * 16.0F) / 256.0F);
					double d45 = ((double)(i51 + 16) - 0.01D) / 256.0D;
					float f47 = block1.getBlockBrightness(this.blockAccess, i49, i3, i27);
					if(i24 < 2) {
						f47 *= f12;
					} else {
						f47 *= f13;
					}

					tessellator5.setColorOpaque_F(f11 * f47, f11 * f47, f11 * f47);
					tessellator5.addVertexWithUV((double)f33, (double)((float)i3 + f31), (double)f34, d37, d41);
					tessellator5.addVertexWithUV((double)f35, (double)((float)i3 + f32), (double)f36, d39, d43);
					tessellator5.addVertexWithUV((double)f35, (double)(i3 + 0), (double)f36, d39, d45);
					tessellator5.addVertexWithUV((double)f33, (double)(i3 + 0), (double)f34, d37, d45);
				}
			}

			block1.minY = d14;
			block1.maxY = d16;
			return z9;
		}
	}

	private float func_1224_a(int i1, int i2, int i3, Material material4) {
		int i5 = 0;
		float f6 = 0.0F;

		for(int i7 = 0; i7 < 4; ++i7) {
			int i8 = i1 - (i7 & 1);
			int i10 = i3 - (i7 >> 1 & 1);
			if(this.blockAccess.getBlockMaterial(i8, i2 + 1, i10) == material4) {
				return 1.0F;
			}

			Material material11 = this.blockAccess.getBlockMaterial(i8, i2, i10);
			if(material11 != material4) {
				if(!material11.func_878_a()) {
					++f6;
					++i5;
				}
			} else {
				int i12 = this.blockAccess.getBlockMetadata(i8, i2, i10);
				if(i12 >= 8 || i12 == 0) {
					f6 += BlockFluids.setFluidHeight(i12) * 10.0F;
					i5 += 10;
				}

				f6 += BlockFluids.setFluidHeight(i12);
				++i5;
			}
		}

		return 1.0F - f6 / (float)i5;
	}

	public void func_1243_a(Block block1, World world2, int i3, int i4, int i5) {
		float f6 = 0.5F;
		float f7 = 1.0F;
		float f8 = 0.8F;
		float f9 = 0.6F;
		Tessellator tessellator10 = Tessellator.instance;
		tessellator10.startDrawingQuads();
		float f11 = block1.getBlockBrightness(world2, i3, i4, i5);
		float f12 = block1.getBlockBrightness(world2, i3, i4 - 1, i5);
		if(f12 < f11) {
			f12 = f11;
		}

		tessellator10.setColorOpaque_F(f6 * f12, f6 * f12, f6 * f12);
		this.renderBottomFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(0));
		f12 = block1.getBlockBrightness(world2, i3, i4 + 1, i5);
		if(f12 < f11) {
			f12 = f11;
		}

		tessellator10.setColorOpaque_F(f7 * f12, f7 * f12, f7 * f12);
		this.renderTopFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(1));
		f12 = block1.getBlockBrightness(world2, i3, i4, i5 - 1);
		if(f12 < f11) {
			f12 = f11;
		}

		tessellator10.setColorOpaque_F(f8 * f12, f8 * f12, f8 * f12);
		this.renderEastFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(2));
		f12 = block1.getBlockBrightness(world2, i3, i4, i5 + 1);
		if(f12 < f11) {
			f12 = f11;
		}

		tessellator10.setColorOpaque_F(f8 * f12, f8 * f12, f8 * f12);
		this.renderWestFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(3));
		f12 = block1.getBlockBrightness(world2, i3 - 1, i4, i5);
		if(f12 < f11) {
			f12 = f11;
		}

		tessellator10.setColorOpaque_F(f9 * f12, f9 * f12, f9 * f12);
		this.renderNorthFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(4));
		f12 = block1.getBlockBrightness(world2, i3 + 1, i4, i5);
		if(f12 < f11) {
			f12 = f11;
		}

		tessellator10.setColorOpaque_F(f9 * f12, f9 * f12, f9 * f12);
		this.renderSouthFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(5));
		tessellator10.draw();
	}

	public boolean renderStandardBlock(Block block1, int i2, int i3, int i4) {
		int i5 = block1.colorMultiplier(this.blockAccess, i2, i3, i4);
		float f6 = (float)(i5 >> 16 & 255) / 255.0F;
		float f7 = (float)(i5 >> 8 & 255) / 255.0F;
		float f8 = (float)(i5 & 255) / 255.0F;
		return this.renderStandardBlockWithColorMultiplier(block1, i2, i3, i4, f6, f7, f8);
	}

	public boolean renderStandardBlockWithColorMultiplier(Block block1, int i2, int i3, int i4, float f5, float f6, float f7) {
		Tessellator tessellator8 = Tessellator.instance;
		boolean z9 = false;
		float f10 = 0.5F;
		float f11 = 1.0F;
		float f12 = 0.8F;
		float f13 = 0.6F;
		float f14 = f11 * f5;
		float f15 = f11 * f6;
		float f16 = f11 * f7;
		if(block1 == Block.grass) {
			f7 = 1.0F;
			f6 = 1.0F;
			f5 = 1.0F;
		}

		float f17 = f10 * f5;
		float f18 = f12 * f5;
		float f19 = f13 * f5;
		float f20 = f10 * f6;
		float f21 = f12 * f6;
		float f22 = f13 * f6;
		float f23 = f10 * f7;
		float f24 = f12 * f7;
		float f25 = f13 * f7;
		float f26 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
		float f27;
		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3 - 1, i4, 0)) {
			f27 = block1.getBlockBrightness(this.blockAccess, i2, i3 - 1, i4);
			tessellator8.setColorOpaque_F(f17 * f27, f20 * f27, f23 * f27);
			this.renderBottomFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 0));
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3 + 1, i4, 1)) {
			f27 = block1.getBlockBrightness(this.blockAccess, i2, i3 + 1, i4);
			if(block1.maxY != 1.0D && !block1.blockMaterial.getIsLiquid()) {
				f27 = f26;
			}

			tessellator8.setColorOpaque_F(f14 * f27, f15 * f27, f16 * f27);
			this.renderTopFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 1));
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 - 1, 2)) {
			f27 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4 - 1);
			if(block1.minZ > 0.0D) {
				f27 = f26;
			}

			tessellator8.setColorOpaque_F(f18 * f27, f21 * f27, f24 * f27);
			this.renderEastFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 2));
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 + 1, 3)) {
			f27 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4 + 1);
			if(block1.maxZ < 1.0D) {
				f27 = f26;
			}

			tessellator8.setColorOpaque_F(f18 * f27, f21 * f27, f24 * f27);
			this.renderWestFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 3));
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2 - 1, i3, i4, 4)) {
			f27 = block1.getBlockBrightness(this.blockAccess, i2 - 1, i3, i4);
			if(block1.minX > 0.0D) {
				f27 = f26;
			}

			tessellator8.setColorOpaque_F(f19 * f27, f22 * f27, f25 * f27);
			this.renderNorthFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 4));
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2 + 1, i3, i4, 5)) {
			f27 = block1.getBlockBrightness(this.blockAccess, i2 + 1, i3, i4);
			if(block1.maxX < 1.0D) {
				f27 = f26;
			}

			tessellator8.setColorOpaque_F(f19 * f27, f22 * f27, f25 * f27);
			this.renderSouthFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 5));
			z9 = true;
		}

		return z9;
	}

	public boolean renderBlockCactus(Block block1, int i2, int i3, int i4) {
		int i5 = block1.colorMultiplier(this.blockAccess, i2, i3, i4);
		float f6 = (float)(i5 >> 16 & 255) / 255.0F;
		float f7 = (float)(i5 >> 8 & 255) / 255.0F;
		float f8 = (float)(i5 & 255) / 255.0F;
		return this.func_1230_b(block1, i2, i3, i4, f6, f7, f8);
	}

	public boolean func_1230_b(Block block1, int i2, int i3, int i4, float f5, float f6, float f7) {
		Tessellator tessellator8 = Tessellator.instance;
		boolean z9 = false;
		float f10 = 0.5F;
		float f11 = 1.0F;
		float f12 = 0.8F;
		float f13 = 0.6F;
		float f14 = f10 * f5;
		float f15 = f11 * f5;
		float f16 = f12 * f5;
		float f17 = f13 * f5;
		float f18 = f10 * f6;
		float f19 = f11 * f6;
		float f20 = f12 * f6;
		float f21 = f13 * f6;
		float f22 = f10 * f7;
		float f23 = f11 * f7;
		float f24 = f12 * f7;
		float f25 = f13 * f7;
		float f26 = 0.0625F;
		float f27 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
		float f28;
		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3 - 1, i4, 0)) {
			f28 = block1.getBlockBrightness(this.blockAccess, i2, i3 - 1, i4);
			tessellator8.setColorOpaque_F(f14 * f28, f18 * f28, f22 * f28);
			this.renderBottomFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 0));
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3 + 1, i4, 1)) {
			f28 = block1.getBlockBrightness(this.blockAccess, i2, i3 + 1, i4);
			if(block1.maxY != 1.0D && !block1.blockMaterial.getIsLiquid()) {
				f28 = f27;
			}

			tessellator8.setColorOpaque_F(f15 * f28, f19 * f28, f23 * f28);
			this.renderTopFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 1));
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 - 1, 2)) {
			f28 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4 - 1);
			if(block1.minZ > 0.0D) {
				f28 = f27;
			}

			tessellator8.setColorOpaque_F(f16 * f28, f20 * f28, f24 * f28);
			tessellator8.setTranslationF(0.0F, 0.0F, f26);
			this.renderEastFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 2));
			tessellator8.setTranslationF(0.0F, 0.0F, -f26);
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 + 1, 3)) {
			f28 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4 + 1);
			if(block1.maxZ < 1.0D) {
				f28 = f27;
			}

			tessellator8.setColorOpaque_F(f16 * f28, f20 * f28, f24 * f28);
			tessellator8.setTranslationF(0.0F, 0.0F, -f26);
			this.renderWestFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 3));
			tessellator8.setTranslationF(0.0F, 0.0F, f26);
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2 - 1, i3, i4, 4)) {
			f28 = block1.getBlockBrightness(this.blockAccess, i2 - 1, i3, i4);
			if(block1.minX > 0.0D) {
				f28 = f27;
			}

			tessellator8.setColorOpaque_F(f17 * f28, f21 * f28, f25 * f28);
			tessellator8.setTranslationF(f26, 0.0F, 0.0F);
			this.renderNorthFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 4));
			tessellator8.setTranslationF(-f26, 0.0F, 0.0F);
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2 + 1, i3, i4, 5)) {
			f28 = block1.getBlockBrightness(this.blockAccess, i2 + 1, i3, i4);
			if(block1.maxX < 1.0D) {
				f28 = f27;
			}

			tessellator8.setColorOpaque_F(f17 * f28, f21 * f28, f25 * f28);
			tessellator8.setTranslationF(-f26, 0.0F, 0.0F);
			this.renderSouthFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 5));
			tessellator8.setTranslationF(f26, 0.0F, 0.0F);
			z9 = true;
		}

		return z9;
	}

	public boolean renderBlockFence(Block block1, int i2, int i3, int i4) {
		boolean z5 = false;
		float f6 = 0.375F;
		float f7 = 0.625F;
		block1.setBlockBounds(f6, 0.0F, f6, f7, 1.0F, f7);
		this.renderStandardBlock(block1, i2, i3, i4);
		boolean z8 = false;
		boolean z9 = false;
		if(this.blockAccess.getBlockId(i2 - 1, i3, i4) == block1.blockID || this.blockAccess.getBlockId(i2 + 1, i3, i4) == block1.blockID) {
			z8 = true;
		}

		if(this.blockAccess.getBlockId(i2, i3, i4 - 1) == block1.blockID || this.blockAccess.getBlockId(i2, i3, i4 + 1) == block1.blockID) {
			z9 = true;
		}

		boolean z10 = this.blockAccess.getBlockId(i2 - 1, i3, i4) == block1.blockID;
		boolean z11 = this.blockAccess.getBlockId(i2 + 1, i3, i4) == block1.blockID;
		boolean z12 = this.blockAccess.getBlockId(i2, i3, i4 - 1) == block1.blockID;
		boolean z13 = this.blockAccess.getBlockId(i2, i3, i4 + 1) == block1.blockID;
		if(!z8 && !z9) {
			z8 = true;
		}

		f6 = 0.4375F;
		f7 = 0.5625F;
		float f14 = 0.75F;
		float f15 = 0.9375F;
		float f16 = z10 ? 0.0F : f6;
		float f17 = z11 ? 1.0F : f7;
		float f18 = z12 ? 0.0F : f6;
		float f19 = z13 ? 1.0F : f7;
		if(z8) {
			block1.setBlockBounds(f16, f14, f6, f17, f15, f7);
			this.renderStandardBlock(block1, i2, i3, i4);
		}

		if(z9) {
			block1.setBlockBounds(f6, f14, f18, f7, f15, f19);
			this.renderStandardBlock(block1, i2, i3, i4);
		}

		f14 = 0.375F;
		f15 = 0.5625F;
		if(z8) {
			block1.setBlockBounds(f16, f14, f6, f17, f15, f7);
			this.renderStandardBlock(block1, i2, i3, i4);
		}

		if(z9) {
			block1.setBlockBounds(f6, f14, f18, f7, f15, f19);
			this.renderStandardBlock(block1, i2, i3, i4);
		}

		block1.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		return z5;
	}

	public boolean renderBlockStairs(Block block1, int i2, int i3, int i4) {
		boolean z5 = false;
		int i6 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		if(i6 == 0) {
			block1.setBlockBounds(0.0F, 0.0F, 0.0F, 0.5F, 0.5F, 1.0F);
			this.renderStandardBlock(block1, i2, i3, i4);
			block1.setBlockBounds(0.5F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
			this.renderStandardBlock(block1, i2, i3, i4);
		} else if(i6 == 1) {
			block1.setBlockBounds(0.0F, 0.0F, 0.0F, 0.5F, 1.0F, 1.0F);
			this.renderStandardBlock(block1, i2, i3, i4);
			block1.setBlockBounds(0.5F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
			this.renderStandardBlock(block1, i2, i3, i4);
		} else if(i6 == 2) {
			block1.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 0.5F);
			this.renderStandardBlock(block1, i2, i3, i4);
			block1.setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 1.0F, 1.0F);
			this.renderStandardBlock(block1, i2, i3, i4);
		} else if(i6 == 3) {
			block1.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.5F);
			this.renderStandardBlock(block1, i2, i3, i4);
			block1.setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 0.5F, 1.0F);
			this.renderStandardBlock(block1, i2, i3, i4);
		}

		block1.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		return z5;
	}

	public boolean renderBlockDoor(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		BlockDoor blockDoor6 = (BlockDoor)block1;
		boolean z7 = false;
		float f8 = 0.5F;
		float f9 = 1.0F;
		float f10 = 0.8F;
		float f11 = 0.6F;
		float f12 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4);
		float f13 = block1.getBlockBrightness(this.blockAccess, i2, i3 - 1, i4);
		if(blockDoor6.minY > 0.0D) {
			f13 = f12;
		}

		if(Block.lightValue[block1.blockID] > 0) {
			f13 = 1.0F;
		}

		tessellator5.setColorOpaque_F(f8 * f13, f8 * f13, f8 * f13);
		this.renderBottomFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 0));
		z7 = true;
		f13 = block1.getBlockBrightness(this.blockAccess, i2, i3 + 1, i4);
		if(blockDoor6.maxY < 1.0D) {
			f13 = f12;
		}

		if(Block.lightValue[block1.blockID] > 0) {
			f13 = 1.0F;
		}

		tessellator5.setColorOpaque_F(f9 * f13, f9 * f13, f9 * f13);
		this.renderTopFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 1));
		z7 = true;
		f13 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4 - 1);
		if(blockDoor6.minZ > 0.0D) {
			f13 = f12;
		}

		if(Block.lightValue[block1.blockID] > 0) {
			f13 = 1.0F;
		}

		tessellator5.setColorOpaque_F(f10 * f13, f10 * f13, f10 * f13);
		int i14 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 2);
		if(i14 < 0) {
			this.flipTexture = true;
			i14 = -i14;
		}

		this.renderEastFace(block1, (double)i2, (double)i3, (double)i4, i14);
		z7 = true;
		this.flipTexture = false;
		f13 = block1.getBlockBrightness(this.blockAccess, i2, i3, i4 + 1);
		if(blockDoor6.maxZ < 1.0D) {
			f13 = f12;
		}

		if(Block.lightValue[block1.blockID] > 0) {
			f13 = 1.0F;
		}

		tessellator5.setColorOpaque_F(f10 * f13, f10 * f13, f10 * f13);
		i14 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 3);
		if(i14 < 0) {
			this.flipTexture = true;
			i14 = -i14;
		}

		this.renderWestFace(block1, (double)i2, (double)i3, (double)i4, i14);
		z7 = true;
		this.flipTexture = false;
		f13 = block1.getBlockBrightness(this.blockAccess, i2 - 1, i3, i4);
		if(blockDoor6.minX > 0.0D) {
			f13 = f12;
		}

		if(Block.lightValue[block1.blockID] > 0) {
			f13 = 1.0F;
		}

		tessellator5.setColorOpaque_F(f11 * f13, f11 * f13, f11 * f13);
		i14 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 4);
		if(i14 < 0) {
			this.flipTexture = true;
			i14 = -i14;
		}

		this.renderNorthFace(block1, (double)i2, (double)i3, (double)i4, i14);
		z7 = true;
		this.flipTexture = false;
		f13 = block1.getBlockBrightness(this.blockAccess, i2 + 1, i3, i4);
		if(blockDoor6.maxX < 1.0D) {
			f13 = f12;
		}

		if(Block.lightValue[block1.blockID] > 0) {
			f13 = 1.0F;
		}

		tessellator5.setColorOpaque_F(f11 * f13, f11 * f13, f11 * f13);
		i14 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 5);
		if(i14 < 0) {
			this.flipTexture = true;
			i14 = -i14;
		}

		this.renderSouthFace(block1, (double)i2, (double)i3, (double)i4, i14);
		z7 = true;
		this.flipTexture = false;
		return z7;
	}

	public void renderBottomFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 240;
		double d12 = ((double)i10 + block1.minX * 16.0D) / 256.0D;
		double d14 = ((double)i10 + block1.maxX * 16.0D - 0.01D) / 256.0D;
		double d16 = ((double)i11 + block1.minZ * 16.0D) / 256.0D;
		double d18 = ((double)i11 + block1.maxZ * 16.0D - 0.01D) / 256.0D;
		if(block1.minX < 0.0D || block1.maxX > 1.0D) {
			d12 = (double)(((float)i10 + 0.0F) / 256.0F);
			d14 = (double)(((float)i10 + 15.99F) / 256.0F);
		}

		if(block1.minZ < 0.0D || block1.maxZ > 1.0D) {
			d16 = (double)(((float)i11 + 0.0F) / 256.0F);
			d18 = (double)(((float)i11 + 15.99F) / 256.0F);
		}

		double d20 = d2 + block1.minX;
		double d22 = d2 + block1.maxX;
		double d24 = d4 + block1.minY;
		double d26 = d6 + block1.minZ;
		double d28 = d6 + block1.maxZ;
		tessellator9.addVertexWithUV(d20, d24, d28, d12, d18);
		tessellator9.addVertexWithUV(d20, d24, d26, d12, d16);
		tessellator9.addVertexWithUV(d22, d24, d26, d14, d16);
		tessellator9.addVertexWithUV(d22, d24, d28, d14, d18);
	}

	public void renderTopFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 240;
		double d12 = ((double)i10 + block1.minX * 16.0D) / 256.0D;
		double d14 = ((double)i10 + block1.maxX * 16.0D - 0.01D) / 256.0D;
		double d16 = ((double)i11 + block1.minZ * 16.0D) / 256.0D;
		double d18 = ((double)i11 + block1.maxZ * 16.0D - 0.01D) / 256.0D;
		if(block1.minX < 0.0D || block1.maxX > 1.0D) {
			d12 = (double)(((float)i10 + 0.0F) / 256.0F);
			d14 = (double)(((float)i10 + 15.99F) / 256.0F);
		}

		if(block1.minZ < 0.0D || block1.maxZ > 1.0D) {
			d16 = (double)(((float)i11 + 0.0F) / 256.0F);
			d18 = (double)(((float)i11 + 15.99F) / 256.0F);
		}

		double d20 = d2 + block1.minX;
		double d22 = d2 + block1.maxX;
		double d24 = d4 + block1.maxY;
		double d26 = d6 + block1.minZ;
		double d28 = d6 + block1.maxZ;
		tessellator9.addVertexWithUV(d22, d24, d28, d14, d18);
		tessellator9.addVertexWithUV(d22, d24, d26, d14, d16);
		tessellator9.addVertexWithUV(d20, d24, d26, d12, d16);
		tessellator9.addVertexWithUV(d20, d24, d28, d12, d18);
	}

	public void renderEastFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 240;
		double d12 = ((double)i10 + block1.minX * 16.0D) / 256.0D;
		double d14 = ((double)i10 + block1.maxX * 16.0D - 0.01D) / 256.0D;
		double d16 = ((double)i11 + block1.minY * 16.0D) / 256.0D;
		double d18 = ((double)i11 + block1.maxY * 16.0D - 0.01D) / 256.0D;
		double d20;
		if(this.flipTexture) {
			d20 = d12;
			d12 = d14;
			d14 = d20;
		}

		if(block1.minX < 0.0D || block1.maxX > 1.0D) {
			d12 = (double)(((float)i10 + 0.0F) / 256.0F);
			d14 = (double)(((float)i10 + 15.99F) / 256.0F);
		}

		if(block1.minY < 0.0D || block1.maxY > 1.0D) {
			d16 = (double)(((float)i11 + 0.0F) / 256.0F);
			d18 = (double)(((float)i11 + 15.99F) / 256.0F);
		}

		d20 = d2 + block1.minX;
		double d22 = d2 + block1.maxX;
		double d24 = d4 + block1.minY;
		double d26 = d4 + block1.maxY;
		double d28 = d6 + block1.minZ;
		tessellator9.addVertexWithUV(d20, d26, d28, d14, d16);
		tessellator9.addVertexWithUV(d22, d26, d28, d12, d16);
		tessellator9.addVertexWithUV(d22, d24, d28, d12, d18);
		tessellator9.addVertexWithUV(d20, d24, d28, d14, d18);
	}

	public void renderWestFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 240;
		double d12 = ((double)i10 + block1.minX * 16.0D) / 256.0D;
		double d14 = ((double)i10 + block1.maxX * 16.0D - 0.01D) / 256.0D;
		double d16 = ((double)i11 + block1.minY * 16.0D) / 256.0D;
		double d18 = ((double)i11 + block1.maxY * 16.0D - 0.01D) / 256.0D;
		double d20;
		if(this.flipTexture) {
			d20 = d12;
			d12 = d14;
			d14 = d20;
		}

		if(block1.minX < 0.0D || block1.maxX > 1.0D) {
			d12 = (double)(((float)i10 + 0.0F) / 256.0F);
			d14 = (double)(((float)i10 + 15.99F) / 256.0F);
		}

		if(block1.minY < 0.0D || block1.maxY > 1.0D) {
			d16 = (double)(((float)i11 + 0.0F) / 256.0F);
			d18 = (double)(((float)i11 + 15.99F) / 256.0F);
		}

		d20 = d2 + block1.minX;
		double d22 = d2 + block1.maxX;
		double d24 = d4 + block1.minY;
		double d26 = d4 + block1.maxY;
		double d28 = d6 + block1.maxZ;
		tessellator9.addVertexWithUV(d20, d26, d28, d12, d16);
		tessellator9.addVertexWithUV(d20, d24, d28, d12, d18);
		tessellator9.addVertexWithUV(d22, d24, d28, d14, d18);
		tessellator9.addVertexWithUV(d22, d26, d28, d14, d16);
	}

	public void renderNorthFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 240;
		double d12 = ((double)i10 + block1.minZ * 16.0D) / 256.0D;
		double d14 = ((double)i10 + block1.maxZ * 16.0D - 0.01D) / 256.0D;
		double d16 = ((double)i11 + block1.minY * 16.0D) / 256.0D;
		double d18 = ((double)i11 + block1.maxY * 16.0D - 0.01D) / 256.0D;
		double d20;
		if(this.flipTexture) {
			d20 = d12;
			d12 = d14;
			d14 = d20;
		}

		if(block1.minZ < 0.0D || block1.maxZ > 1.0D) {
			d12 = (double)(((float)i10 + 0.0F) / 256.0F);
			d14 = (double)(((float)i10 + 15.99F) / 256.0F);
		}

		if(block1.minY < 0.0D || block1.maxY > 1.0D) {
			d16 = (double)(((float)i11 + 0.0F) / 256.0F);
			d18 = (double)(((float)i11 + 15.99F) / 256.0F);
		}

		d20 = d2 + block1.minX;
		double d22 = d4 + block1.minY;
		double d24 = d4 + block1.maxY;
		double d26 = d6 + block1.minZ;
		double d28 = d6 + block1.maxZ;
		tessellator9.addVertexWithUV(d20, d24, d28, d14, d16);
		tessellator9.addVertexWithUV(d20, d24, d26, d12, d16);
		tessellator9.addVertexWithUV(d20, d22, d26, d12, d18);
		tessellator9.addVertexWithUV(d20, d22, d28, d14, d18);
	}

	public void renderSouthFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 240;
		double d12 = ((double)i10 + block1.minZ * 16.0D) / 256.0D;
		double d14 = ((double)i10 + block1.maxZ * 16.0D - 0.01D) / 256.0D;
		double d16 = ((double)i11 + block1.minY * 16.0D) / 256.0D;
		double d18 = ((double)i11 + block1.maxY * 16.0D - 0.01D) / 256.0D;
		double d20;
		if(this.flipTexture) {
			d20 = d12;
			d12 = d14;
			d14 = d20;
		}

		if(block1.minZ < 0.0D || block1.maxZ > 1.0D) {
			d12 = (double)(((float)i10 + 0.0F) / 256.0F);
			d14 = (double)(((float)i10 + 15.99F) / 256.0F);
		}

		if(block1.minY < 0.0D || block1.maxY > 1.0D) {
			d16 = (double)(((float)i11 + 0.0F) / 256.0F);
			d18 = (double)(((float)i11 + 15.99F) / 256.0F);
		}

		d20 = d2 + block1.maxX;
		double d22 = d4 + block1.minY;
		double d24 = d4 + block1.maxY;
		double d26 = d6 + block1.minZ;
		double d28 = d6 + block1.maxZ;
		tessellator9.addVertexWithUV(d20, d22, d28, d12, d18);
		tessellator9.addVertexWithUV(d20, d22, d26, d14, d18);
		tessellator9.addVertexWithUV(d20, d24, d26, d14, d16);
		tessellator9.addVertexWithUV(d20, d24, d28, d12, d16);
	}

	public void func_1238_a(Block block1, float f2) {
		int i3 = block1.getRenderType();
		Tessellator tessellator4 = Tessellator.instance;
		if(i3 == 0) {
			block1.func_237_e();
			GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
			float f5 = 0.5F;
			float f6 = 1.0F;
			float f7 = 0.8F;
			float f8 = 0.6F;
			tessellator4.startDrawingQuads();
			tessellator4.setColorRGBA_F(f6, f6, f6, f2);
			this.renderBottomFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(0));
			tessellator4.setColorRGBA_F(f5, f5, f5, f2);
			this.renderTopFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(1));
			tessellator4.setColorRGBA_F(f7, f7, f7, f2);
			this.renderEastFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(2));
			this.renderWestFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(3));
			tessellator4.setColorRGBA_F(f8, f8, f8, f2);
			this.renderNorthFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(4));
			this.renderSouthFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(5));
			tessellator4.draw();
			GL11.glTranslatef(0.5F, 0.5F, 0.5F);
		}

	}

	public void func_1227_a(Block block1) {
		byte b2 = -1;
		Tessellator tessellator3 = Tessellator.instance;
		int i4 = block1.getRenderType();
		if(i4 == 0) {
			block1.func_237_e();
			GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(0.0F, -1.0F, 0.0F);
			this.renderBottomFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(0));
			tessellator3.draw();
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(0.0F, 1.0F, 0.0F);
			this.renderTopFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(1));
			tessellator3.draw();
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(0.0F, 0.0F, -1.0F);
			this.renderEastFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(2));
			tessellator3.draw();
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(0.0F, 0.0F, 1.0F);
			this.renderWestFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(3));
			tessellator3.draw();
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(-1.0F, 0.0F, 0.0F);
			this.renderNorthFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(4));
			tessellator3.draw();
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(1.0F, 0.0F, 0.0F);
			this.renderSouthFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(5));
			tessellator3.draw();
			GL11.glTranslatef(0.5F, 0.5F, 0.5F);
		} else if(i4 == 1) {
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(0.0F, -1.0F, 0.0F);
			this.func_1239_a(block1, b2, -0.5D, -0.5D, -0.5D);
			tessellator3.draw();
		} else if(i4 == 13) {
			block1.func_237_e();
			GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
			float f5 = 0.0625F;
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(0.0F, -1.0F, 0.0F);
			this.renderBottomFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(0));
			tessellator3.draw();
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(0.0F, 1.0F, 0.0F);
			this.renderTopFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(1));
			tessellator3.draw();
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(0.0F, 0.0F, -1.0F);
			tessellator3.setTranslationF(0.0F, 0.0F, f5);
			this.renderEastFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(2));
			tessellator3.setTranslationF(0.0F, 0.0F, -f5);
			tessellator3.draw();
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(0.0F, 0.0F, 1.0F);
			tessellator3.setTranslationF(0.0F, 0.0F, -f5);
			this.renderWestFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(3));
			tessellator3.setTranslationF(0.0F, 0.0F, f5);
			tessellator3.draw();
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(-1.0F, 0.0F, 0.0F);
			tessellator3.setTranslationF(f5, 0.0F, 0.0F);
			this.renderNorthFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(4));
			tessellator3.setTranslationF(-f5, 0.0F, 0.0F);
			tessellator3.draw();
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(1.0F, 0.0F, 0.0F);
			tessellator3.setTranslationF(-f5, 0.0F, 0.0F);
			this.renderSouthFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(5));
			tessellator3.setTranslationF(f5, 0.0F, 0.0F);
			tessellator3.draw();
			GL11.glTranslatef(0.5F, 0.5F, 0.5F);
		} else if(i4 == 6) {
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(0.0F, -1.0F, 0.0F);
			this.func_1245_b(block1, b2, -0.5D, -0.5D, -0.5D);
			tessellator3.draw();
		} else if(i4 == 2) {
			tessellator3.startDrawingQuads();
			tessellator3.setNormal(0.0F, -1.0F, 0.0F);
			this.renderTorchAtAngle(block1, -0.5D, -0.5D, -0.5D, 0.0D, 0.0D);
			tessellator3.draw();
		} else {
			int i7;
			if(i4 == 10) {
				for(i7 = 0; i7 < 2; ++i7) {
					if(i7 == 0) {
						block1.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.5F);
					}

					if(i7 == 1) {
						block1.setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 0.5F, 1.0F);
					}

					GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(0.0F, -1.0F, 0.0F);
					this.renderBottomFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(0));
					tessellator3.draw();
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(0.0F, 1.0F, 0.0F);
					this.renderTopFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(1));
					tessellator3.draw();
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(0.0F, 0.0F, -1.0F);
					this.renderEastFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(2));
					tessellator3.draw();
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(0.0F, 0.0F, 1.0F);
					this.renderWestFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(3));
					tessellator3.draw();
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(-1.0F, 0.0F, 0.0F);
					this.renderNorthFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(4));
					tessellator3.draw();
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(1.0F, 0.0F, 0.0F);
					this.renderSouthFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(5));
					tessellator3.draw();
					GL11.glTranslatef(0.5F, 0.5F, 0.5F);
				}
			} else if(i4 == 11) {
				for(i7 = 0; i7 < 4; ++i7) {
					float f6 = 0.125F;
					if(i7 == 0) {
						block1.setBlockBounds(0.5F - f6, 0.0F, 0.0F, 0.5F + f6, 1.0F, f6 * 2.0F);
					}

					if(i7 == 1) {
						block1.setBlockBounds(0.5F - f6, 0.0F, 1.0F - f6 * 2.0F, 0.5F + f6, 1.0F, 1.0F);
					}

					f6 = 0.0625F;
					if(i7 == 2) {
						block1.setBlockBounds(0.5F - f6, 1.0F - f6 * 3.0F, -f6 * 2.0F, 0.5F + f6, 1.0F - f6, 1.0F + f6 * 2.0F);
					}

					if(i7 == 3) {
						block1.setBlockBounds(0.5F - f6, 0.5F - f6 * 3.0F, -f6 * 2.0F, 0.5F + f6, 0.5F - f6, 1.0F + f6 * 2.0F);
					}

					GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(0.0F, -1.0F, 0.0F);
					this.renderBottomFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(0));
					tessellator3.draw();
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(0.0F, 1.0F, 0.0F);
					this.renderTopFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(1));
					tessellator3.draw();
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(0.0F, 0.0F, -1.0F);
					this.renderEastFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(2));
					tessellator3.draw();
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(0.0F, 0.0F, 1.0F);
					this.renderWestFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(3));
					tessellator3.draw();
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(-1.0F, 0.0F, 0.0F);
					this.renderNorthFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(4));
					tessellator3.draw();
					tessellator3.startDrawingQuads();
					tessellator3.setNormal(1.0F, 0.0F, 0.0F);
					this.renderSouthFace(block1, 0.0D, 0.0D, 0.0D, block1.getBlockTextureFromSide(5));
					tessellator3.draw();
					GL11.glTranslatef(0.5F, 0.5F, 0.5F);
				}

				block1.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
			}
		}

	}

	public static boolean func_1219_a(int i0) {
		return i0 == 0 ? true : (i0 == 13 ? true : (i0 == 10 ? true : i0 == 11));
	}
}
