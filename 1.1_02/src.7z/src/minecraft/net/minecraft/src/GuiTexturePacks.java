package net.minecraft.src;

import java.io.File;
import java.util.List;

import org.lwjgl.Sys;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class GuiTexturePacks extends GuiScreen {
	protected GuiScreen field_6461_a;
	private int field_6460_h = 0;
	private int field_6459_i = 32;
	private int field_6458_j = this.height - 55 + 4;
	private int field_6457_l = 0;
	private int field_6456_m = this.width;
	private int field_6455_n = -2;
	private int field_6454_o = -1;
	private String field_6453_p = "";

	public GuiTexturePacks(GuiScreen guiScreen1) {
		this.field_6461_a = guiScreen1;
	}

	public void initGui() {
		StringTranslate stringTranslate1 = StringTranslate.func_20162_a();
		this.controlList.add(new GuiSmallButton(5, this.width / 2 - 154, this.height - 48, stringTranslate1.func_20163_a("texturePack.openFolder")));
		this.controlList.add(new GuiSmallButton(6, this.width / 2 + 4, this.height - 48, stringTranslate1.func_20163_a("gui.done")));
		this.mc.texturePackList.func_6532_a();
		this.field_6453_p = (new File(this.mc.mcDataDir, "texturepacks")).getAbsolutePath();
		this.field_6459_i = 32;
		this.field_6458_j = this.height - 58 + 4;
		this.field_6457_l = 0;
		this.field_6456_m = this.width;
	}

	protected void actionPerformed(GuiButton guiButton1) {
		if(guiButton1.enabled) {
			if(guiButton1.id == 5) {
				Sys.openURL("file://" + this.field_6453_p);
			}

			if(guiButton1.id == 6) {
				this.mc.renderEngine.refreshTextures();
				this.mc.displayGuiScreen(this.field_6461_a);
			}

		}
	}

	protected void mouseClicked(int i1, int i2, int i3) {
		super.mouseClicked(i1, i2, i3);
	}

	protected void mouseMovedOrUp(int i1, int i2, int i3) {
		super.mouseMovedOrUp(i1, i2, i3);
	}

	public void drawScreen(int i1, int i2, float f3) {
		this.drawDefaultBackground();
		if(this.field_6454_o <= 0) {
			this.mc.texturePackList.func_6532_a();
			this.field_6454_o += 20;
		}

		List list4 = this.mc.texturePackList.availableTexturePacks();
		int i5;
		if(Mouse.isButtonDown(0)) {
			if(this.field_6455_n == -1) {
				if(i2 >= this.field_6459_i && i2 <= this.field_6458_j) {
					i5 = this.width / 2 - 110;
					int i6 = this.width / 2 + 110;
					int i7 = (i2 - this.field_6459_i + this.field_6460_h - 2) / 36;
					if(i1 >= i5 && i1 <= i6 && i7 >= 0 && i7 < list4.size() && this.mc.texturePackList.setTexturePack((TexturePackBase)list4.get(i7))) {
						this.mc.renderEngine.refreshTextures();
					}

					this.field_6455_n = i2;
				} else {
					this.field_6455_n = -2;
				}
			} else if(this.field_6455_n >= 0) {
				this.field_6460_h -= i2 - this.field_6455_n;
				this.field_6455_n = i2;
			}
		} else {
			if(this.field_6455_n >= 0 && this.field_6455_n == i2) {
				;
			}

			this.field_6455_n = -1;
		}

		i5 = list4.size() * 36 - (this.field_6458_j - this.field_6459_i - 4);
		if(i5 < 0) {
			i5 /= 2;
		}

		if(this.field_6460_h < 0) {
			this.field_6460_h = 0;
		}

		if(this.field_6460_h > i5) {
			this.field_6460_h = i5;
		}

		GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glDisable(GL11.GL_FOG);
		Tessellator tessellator16 = Tessellator.instance;
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("/gui/background.png"));
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		float f17 = 32.0F;
		tessellator16.startDrawingQuads();
		tessellator16.setColorOpaque_I(2105376);
		tessellator16.addVertexWithUV((double)this.field_6457_l, (double)this.field_6458_j, 0.0D, (double)((float)this.field_6457_l / f17), (double)((float)(this.field_6458_j + this.field_6460_h) / f17));
		tessellator16.addVertexWithUV((double)this.field_6456_m, (double)this.field_6458_j, 0.0D, (double)((float)this.field_6456_m / f17), (double)((float)(this.field_6458_j + this.field_6460_h) / f17));
		tessellator16.addVertexWithUV((double)this.field_6456_m, (double)this.field_6459_i, 0.0D, (double)((float)this.field_6456_m / f17), (double)((float)(this.field_6459_i + this.field_6460_h) / f17));
		tessellator16.addVertexWithUV((double)this.field_6457_l, (double)this.field_6459_i, 0.0D, (double)((float)this.field_6457_l / f17), (double)((float)(this.field_6459_i + this.field_6460_h) / f17));
		tessellator16.draw();

		for(int i8 = 0; i8 < list4.size(); ++i8) {
			TexturePackBase texturePackBase9 = (TexturePackBase)list4.get(i8);
			int i10 = this.width / 2 - 92 - 16;
			int i11 = 36 + i8 * 36 - this.field_6460_h;
			byte b12 = 32;
			byte b13 = 32;
			if(texturePackBase9 == this.mc.texturePackList.selectedTexturePack) {
				int i14 = this.width / 2 - 110;
				int i15 = this.width / 2 + 110;
				GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
				GL11.glDisable(GL11.GL_TEXTURE_2D);
				tessellator16.startDrawingQuads();
				tessellator16.setColorOpaque_I(8421504);
				tessellator16.addVertexWithUV((double)i14, (double)(i11 + b12 + 2), 0.0D, 0.0D, 1.0D);
				tessellator16.addVertexWithUV((double)i15, (double)(i11 + b12 + 2), 0.0D, 1.0D, 1.0D);
				tessellator16.addVertexWithUV((double)i15, (double)(i11 - 2), 0.0D, 1.0D, 0.0D);
				tessellator16.addVertexWithUV((double)i14, (double)(i11 - 2), 0.0D, 0.0D, 0.0D);
				tessellator16.setColorOpaque_I(0);
				tessellator16.addVertexWithUV((double)(i14 + 1), (double)(i11 + b12 + 1), 0.0D, 0.0D, 1.0D);
				tessellator16.addVertexWithUV((double)(i15 - 1), (double)(i11 + b12 + 1), 0.0D, 1.0D, 1.0D);
				tessellator16.addVertexWithUV((double)(i15 - 1), (double)(i11 - 1), 0.0D, 1.0D, 0.0D);
				tessellator16.addVertexWithUV((double)(i14 + 1), (double)(i11 - 1), 0.0D, 0.0D, 0.0D);
				tessellator16.draw();
				GL11.glEnable(GL11.GL_TEXTURE_2D);
			}

			texturePackBase9.func_6483_c(this.mc);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
			tessellator16.startDrawingQuads();
			tessellator16.setColorOpaque_I(0xFFFFFF);
			tessellator16.addVertexWithUV((double)i10, (double)(i11 + b12), 0.0D, 0.0D, 1.0D);
			tessellator16.addVertexWithUV((double)(i10 + b13), (double)(i11 + b12), 0.0D, 1.0D, 1.0D);
			tessellator16.addVertexWithUV((double)(i10 + b13), (double)i11, 0.0D, 1.0D, 0.0D);
			tessellator16.addVertexWithUV((double)i10, (double)i11, 0.0D, 0.0D, 0.0D);
			tessellator16.draw();
			this.drawString(this.fontRenderer, texturePackBase9.texturePackFileName, i10 + b13 + 2, i11 + 1, 0xFFFFFF);
			this.drawString(this.fontRenderer, texturePackBase9.firstDescriptionLine, i10 + b13 + 2, i11 + 12, 8421504);
			this.drawString(this.fontRenderer, texturePackBase9.secondDescriptionLine, i10 + b13 + 2, i11 + 12 + 10, 8421504);
		}

		byte b18 = 4;
		this.func_6452_a(0, this.field_6459_i, 255, 255);
		this.func_6452_a(this.field_6458_j, this.height, 255, 255);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glDisable(GL11.GL_ALPHA_TEST);
		GL11.glShadeModel(GL11.GL_SMOOTH);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		tessellator16.startDrawingQuads();
		tessellator16.setColorRGBA_I(0, 0);
		tessellator16.addVertexWithUV((double)this.field_6457_l, (double)(this.field_6459_i + b18), 0.0D, 0.0D, 1.0D);
		tessellator16.addVertexWithUV((double)this.field_6456_m, (double)(this.field_6459_i + b18), 0.0D, 1.0D, 1.0D);
		tessellator16.setColorRGBA_I(0, 255);
		tessellator16.addVertexWithUV((double)this.field_6456_m, (double)this.field_6459_i, 0.0D, 1.0D, 0.0D);
		tessellator16.addVertexWithUV((double)this.field_6457_l, (double)this.field_6459_i, 0.0D, 0.0D, 0.0D);
		tessellator16.draw();
		tessellator16.startDrawingQuads();
		tessellator16.setColorRGBA_I(0, 255);
		tessellator16.addVertexWithUV((double)this.field_6457_l, (double)this.field_6458_j, 0.0D, 0.0D, 1.0D);
		tessellator16.addVertexWithUV((double)this.field_6456_m, (double)this.field_6458_j, 0.0D, 1.0D, 1.0D);
		tessellator16.setColorRGBA_I(0, 0);
		tessellator16.addVertexWithUV((double)this.field_6456_m, (double)(this.field_6458_j - b18), 0.0D, 1.0D, 0.0D);
		tessellator16.addVertexWithUV((double)this.field_6457_l, (double)(this.field_6458_j - b18), 0.0D, 0.0D, 0.0D);
		tessellator16.draw();
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		GL11.glShadeModel(GL11.GL_FLAT);
		GL11.glEnable(GL11.GL_ALPHA_TEST);
		GL11.glDisable(GL11.GL_BLEND);
		StringTranslate stringTranslate19 = StringTranslate.func_20162_a();
		this.drawCenteredString(this.fontRenderer, stringTranslate19.func_20163_a("texturePack.title"), this.width / 2, 16, 0xFFFFFF);
		this.drawCenteredString(this.fontRenderer, stringTranslate19.func_20163_a("texturePack.folderInfo"), this.width / 2 - 77, this.height - 26, 8421504);
		super.drawScreen(i1, i2, f3);
	}

	public void updateScreen() {
		super.updateScreen();
		--this.field_6454_o;
	}

	public void func_6452_a(int i1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("/gui/background.png"));
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		float f6 = 32.0F;
		tessellator5.startDrawingQuads();
		tessellator5.setColorRGBA_I(4210752, i4);
		tessellator5.addVertexWithUV(0.0D, (double)i2, 0.0D, 0.0D, (double)((float)i2 / f6));
		tessellator5.addVertexWithUV((double)this.width, (double)i2, 0.0D, (double)((float)this.width / f6), (double)((float)i2 / f6));
		tessellator5.setColorRGBA_I(4210752, i3);
		tessellator5.addVertexWithUV((double)this.width, (double)i1, 0.0D, (double)((float)this.width / f6), (double)((float)i1 / f6));
		tessellator5.addVertexWithUV(0.0D, (double)i1, 0.0D, 0.0D, (double)((float)i1 / f6));
		tessellator5.draw();
	}
}
