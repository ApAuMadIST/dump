package net.minecraft.src;

import java.io.IOException;

public class ChunkProviderIso implements IChunkProvider {
	private Chunk[] chunks = new Chunk[256];
	private World worldObj;
	private IChunkLoader chunkLoader;
	byte[] field_899_a = new byte[32768];

	public ChunkProviderIso(World world1, IChunkLoader iChunkLoader2) {
		this.worldObj = world1;
		this.chunkLoader = iChunkLoader2;
	}

	public boolean chunkExists(int i1, int i2) {
		int i3 = i1 & 15 | (i2 & 15) * 16;
		return this.chunks[i3] != null && this.chunks[i3].isAtLocation(i1, i2);
	}

	public Chunk provideChunk(int i1, int i2) {
		int i3 = i1 & 15 | (i2 & 15) * 16;

		try {
			if(!this.chunkExists(i1, i2)) {
				Chunk chunk4 = this.func_543_c(i1, i2);
				if(chunk4 == null) {
					chunk4 = new Chunk(this.worldObj, this.field_899_a, i1, i2);
					chunk4.field_1524_q = true;
					chunk4.neverSave = true;
				}

				this.chunks[i3] = chunk4;
			}

			return this.chunks[i3];
		} catch (Exception exception5) {
			exception5.printStackTrace();
			return null;
		}
	}

	private synchronized Chunk func_543_c(int i1, int i2) {
		try {
			return this.chunkLoader.loadChunk(this.worldObj, i1, i2);
		} catch (IOException iOException4) {
			iOException4.printStackTrace();
			return null;
		}
	}

	public void populate(IChunkProvider iChunkProvider1, int i2, int i3) {
	}

	public boolean saveChunks(boolean z1, IProgressUpdate iProgressUpdate2) {
		return true;
	}

	public boolean func_532_a() {
		return false;
	}

	public boolean func_536_b() {
		return false;
	}
}
