package net.minecraft.src;

import net.minecraft.client.Minecraft;

public class EntityPlayerSP extends EntityPlayer {
	public MovementInput movementInput;
	protected Minecraft mc;
	public int field_9373_b = 20;
	private boolean inPortal = false;
	public float timeInPortal;
	public float prevTimeInPortal;

	public EntityPlayerSP(Minecraft minecraft1, World world2, Session session3, int i4) {
		super(world2);
		this.mc = minecraft1;
		this.dimension = i4;
		if(session3 != null && session3.playerName != null && session3.playerName.length() > 0) {
			this.field_20047_bv = "http://www.minecraft.net/skin/" + session3.playerName + ".png";
			System.out.println("Loading texture " + this.field_20047_bv);
		}

		this.field_771_i = session3.playerName;
	}

	public void updatePlayerActionState() {
		super.updatePlayerActionState();
		this.moveStrafing = this.movementInput.moveStrafe;
		this.moveForward = this.movementInput.moveForward;
		this.isJumping = this.movementInput.jump;
	}

	public void onLivingUpdate() {
		this.prevTimeInPortal = this.timeInPortal;
		if(this.inPortal) {
			if(this.timeInPortal == 0.0F) {
				this.mc.sndManager.func_337_a("portal.trigger", 1.0F, this.rand.nextFloat() * 0.4F + 0.8F);
			}

			this.timeInPortal += 0.0125F;
			if(this.timeInPortal >= 1.0F) {
				this.timeInPortal = 1.0F;
				this.field_9373_b = 10;
				this.mc.sndManager.func_337_a("portal.travel", 1.0F, this.rand.nextFloat() * 0.4F + 0.8F);
				this.mc.usePortal();
			}

			this.inPortal = false;
		} else {
			if(this.timeInPortal > 0.0F) {
				this.timeInPortal -= 0.05F;
			}

			if(this.timeInPortal < 0.0F) {
				this.timeInPortal = 0.0F;
			}
		}

		if(this.field_9373_b > 0) {
			--this.field_9373_b;
		}

		this.movementInput.updatePlayerMoveState(this);
		if(this.movementInput.sneak && this.field_9287_aY < 0.2F) {
			this.field_9287_aY = 0.2F;
		}

		super.onLivingUpdate();
	}

	public void resetPlayerKeyState() {
		this.movementInput.resetKeyState();
	}

	public void handleKeyPress(int i1, boolean z2) {
		this.movementInput.checkKeyForMovementInput(i1, z2);
	}

	public void writeEntityToNBT(NBTTagCompound nBTTagCompound1) {
		super.writeEntityToNBT(nBTTagCompound1);
		nBTTagCompound1.setInteger("Score", this.score);
	}

	public void readEntityFromNBT(NBTTagCompound nBTTagCompound1) {
		super.readEntityFromNBT(nBTTagCompound1);
		this.score = nBTTagCompound1.getInteger("Score");
	}

	public void func_20059_m() {
		super.func_20059_m();
		this.mc.displayGuiScreen((GuiScreen)null);
	}

	public void displayGUIEditSign(TileEntitySign tileEntitySign1) {
		this.mc.displayGuiScreen(new GuiEditSign(tileEntitySign1));
	}

	public void displayGUIChest(IInventory iInventory1) {
		this.mc.displayGuiScreen(new GuiChest(this.inventory, iInventory1));
	}

	public void displayWorkbenchGUI(int i1, int i2, int i3) {
		this.mc.displayGuiScreen(new GuiCrafting(this.inventory, this.worldObj, i1, i2, i3));
	}

	public void displayGUIFurnace(TileEntityFurnace tileEntityFurnace1) {
		this.mc.displayGuiScreen(new GuiFurnace(this.inventory, tileEntityFurnace1));
	}

	public void onItemPickup(Entity entity1, int i2) {
		this.mc.effectRenderer.func_1192_a(new EntityPickupFX(this.mc.theWorld, entity1, this, -0.5F));
	}

	public int getPlayerArmorValue() {
		return this.inventory.getTotalArmorValue();
	}

	public void useCurrentItemOnEntity(Entity entity1) {
		if(!entity1.interact(this)) {
			ItemStack itemStack2 = this.getCurrentEquippedItem();
			if(itemStack2 != null && entity1 instanceof EntityLiving) {
				itemStack2.useItemOnEntity((EntityLiving)entity1);
				if(itemStack2.stackSize <= 0) {
					itemStack2.func_1097_a(this);
					this.destroyCurrentEquippedItem();
				}
			}

		}
	}

	public void sendChatMessage(String string1) {
	}

	public void func_6420_o() {
	}

	public boolean isSneaking() {
		return this.movementInput.sneak;
	}

	public void setInPortal() {
		if(this.field_9373_b > 0) {
			this.field_9373_b = 10;
		} else {
			this.inPortal = true;
		}
	}

	public void setHealth(int i1) {
		int i2 = this.health - i1;
		if(i2 <= 0) {
			this.health = i1;
		} else {
			this.field_9346_af = i2;
			this.prevHealth = this.health;
			this.field_9306_bj = this.field_9366_o;
			this.damageEntity(i2);
			this.hurtTime = this.maxHurtTime = 10;
		}

	}

	public void respawnPlayer() {
		this.mc.respawn();
	}
}
