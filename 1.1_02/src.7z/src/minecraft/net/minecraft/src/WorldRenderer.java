package net.minecraft.src;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.lwjgl.opengl.GL11;

public class WorldRenderer {
	public World worldObj;
	private int glRenderList = -1;
	private static Tessellator tessellator = Tessellator.instance;
	public static int chunksUpdated = 0;
	public int posX;
	public int posY;
	public int posZ;
	public int sizeWidth;
	public int sizeHeight;
	public int sizeDepth;
	public int field_1755_i;
	public int field_1754_j;
	public int field_1753_k;
	public int field_1752_l;
	public int field_1751_m;
	public int field_1750_n;
	public boolean isInFrustrum = false;
	public boolean[] skipRenderPass = new boolean[2];
	public int field_1746_q;
	public int field_1743_r;
	public int field_1741_s;
	public float field_1740_t;
	public boolean needsUpdate;
	public AxisAlignedBB field_1736_v;
	public int field_1735_w;
	public boolean isVisible = true;
	public boolean isWaitingOnOcclusionQuery;
	public int field_1732_z;
	public boolean field_1747_A;
	private boolean isInitialized = false;
	public List tileEntityRenderers = new ArrayList();
	private List field_1737_F;

	public WorldRenderer(World world1, List list2, int i3, int i4, int i5, int i6, int i7) {
		this.worldObj = world1;
		this.field_1737_F = list2;
		this.sizeWidth = this.sizeHeight = this.sizeDepth = i6;
		this.field_1740_t = MathHelper.sqrt_float((float)(this.sizeWidth * this.sizeWidth + this.sizeHeight * this.sizeHeight + this.sizeDepth * this.sizeDepth)) / 2.0F;
		this.glRenderList = i7;
		this.posX = -999;
		this.func_1197_a(i3, i4, i5);
		this.needsUpdate = false;
	}

	public void func_1197_a(int i1, int i2, int i3) {
		if(i1 != this.posX || i2 != this.posY || i3 != this.posZ) {
			this.func_1195_b();
			this.posX = i1;
			this.posY = i2;
			this.posZ = i3;
			this.field_1746_q = i1 + this.sizeWidth / 2;
			this.field_1743_r = i2 + this.sizeHeight / 2;
			this.field_1741_s = i3 + this.sizeDepth / 2;
			this.field_1752_l = i1 & 1023;
			this.field_1751_m = i2;
			this.field_1750_n = i3 & 1023;
			this.field_1755_i = i1 - this.field_1752_l;
			this.field_1754_j = i2 - this.field_1751_m;
			this.field_1753_k = i3 - this.field_1750_n;
			float f4 = 2.0F;
			this.field_1736_v = AxisAlignedBB.getBoundingBox((double)((float)i1 - f4), (double)((float)i2 - f4), (double)((float)i3 - f4), (double)((float)(i1 + this.sizeWidth) + f4), (double)((float)(i2 + this.sizeHeight) + f4), (double)((float)(i3 + this.sizeDepth) + f4));
			GL11.glNewList(this.glRenderList + 2, GL11.GL_COMPILE);
			RenderItem.renderAABB(AxisAlignedBB.getBoundingBoxFromPool((double)((float)this.field_1752_l - f4), (double)((float)this.field_1751_m - f4), (double)((float)this.field_1750_n - f4), (double)((float)(this.field_1752_l + this.sizeWidth) + f4), (double)((float)(this.field_1751_m + this.sizeHeight) + f4), (double)((float)(this.field_1750_n + this.sizeDepth) + f4)));
			GL11.glEndList();
			this.markDirty();
		}
	}

	private void setupGLTranslation() {
		GL11.glTranslatef((float)this.field_1752_l, (float)this.field_1751_m, (float)this.field_1750_n);
	}

	public void updateRenderer() {
		if(this.needsUpdate) {
			++chunksUpdated;
			int i1 = this.posX;
			int i2 = this.posY;
			int i3 = this.posZ;
			int i4 = this.posX + this.sizeWidth;
			int i5 = this.posY + this.sizeHeight;
			int i6 = this.posZ + this.sizeDepth;

			for(int i7 = 0; i7 < 2; ++i7) {
				this.skipRenderPass[i7] = true;
			}

			Chunk.field_1540_a = false;
			HashSet hashSet21 = new HashSet();
			hashSet21.addAll(this.tileEntityRenderers);
			this.tileEntityRenderers.clear();
			byte b8 = 1;
			ChunkCache chunkCache9 = new ChunkCache(this.worldObj, i1 - b8, i2 - b8, i3 - b8, i4 + b8, i5 + b8, i6 + b8);
			RenderBlocks renderBlocks10 = new RenderBlocks(chunkCache9);

			for(int i11 = 0; i11 < 2; ++i11) {
				boolean z12 = false;
				boolean z13 = false;
				boolean z14 = false;

				for(int i15 = i2; i15 < i5; ++i15) {
					for(int i16 = i3; i16 < i6; ++i16) {
						for(int i17 = i1; i17 < i4; ++i17) {
							int i18 = chunkCache9.getBlockId(i17, i15, i16);
							if(i18 > 0) {
								if(!z14) {
									z14 = true;
									GL11.glNewList(this.glRenderList + i11, GL11.GL_COMPILE);
									GL11.glPushMatrix();
									this.setupGLTranslation();
									float f19 = 1.000001F;
									GL11.glTranslatef((float)(-this.sizeDepth) / 2.0F, (float)(-this.sizeHeight) / 2.0F, (float)(-this.sizeDepth) / 2.0F);
									GL11.glScalef(f19, f19, f19);
									GL11.glTranslatef((float)this.sizeDepth / 2.0F, (float)this.sizeHeight / 2.0F, (float)this.sizeDepth / 2.0F);
									tessellator.startDrawingQuads();
									tessellator.setTranslationD((double)(-this.posX), (double)(-this.posY), (double)(-this.posZ));
								}

								if(i11 == 0 && Block.isBlockContainer[i18]) {
									TileEntity tileEntity23 = chunkCache9.getBlockTileEntity(i17, i15, i16);
									if(TileEntityRenderer.instance.hasSpecialRenderer(tileEntity23)) {
										this.tileEntityRenderers.add(tileEntity23);
									}
								}

								Block block24 = Block.blocksList[i18];
								int i20 = block24.getRenderBlockPass();
								if(i20 != i11) {
									z12 = true;
								} else if(i20 == i11) {
									z13 |= renderBlocks10.renderBlockByRenderType(block24, i17, i15, i16);
								}
							}
						}
					}
				}

				if(z14) {
					tessellator.draw();
					GL11.glPopMatrix();
					GL11.glEndList();
					tessellator.setTranslationD(0.0D, 0.0D, 0.0D);
				} else {
					z13 = false;
				}

				if(z13) {
					this.skipRenderPass[i11] = false;
				}

				if(!z12) {
					break;
				}
			}

			HashSet hashSet22 = new HashSet();
			hashSet22.addAll(this.tileEntityRenderers);
			hashSet22.removeAll(hashSet21);
			this.field_1737_F.addAll(hashSet22);
			hashSet21.removeAll(this.tileEntityRenderers);
			this.field_1737_F.removeAll(hashSet21);
			this.field_1747_A = Chunk.field_1540_a;
			this.isInitialized = true;
		}
	}

	public float distanceToEntity(Entity entity1) {
		float f2 = (float)(entity1.posX - (double)this.field_1746_q);
		float f3 = (float)(entity1.posY - (double)this.field_1743_r);
		float f4 = (float)(entity1.posZ - (double)this.field_1741_s);
		return f2 * f2 + f3 * f3 + f4 * f4;
	}

	public void func_1195_b() {
		for(int i1 = 0; i1 < 2; ++i1) {
			this.skipRenderPass[i1] = true;
		}

		this.isInFrustrum = false;
		this.isInitialized = false;
	}

	public void func_1204_c() {
		this.func_1195_b();
		this.worldObj = null;
	}

	public int getGLCallListForPass(int i1) {
		return !this.isInFrustrum ? -1 : (!this.skipRenderPass[i1] ? this.glRenderList + i1 : -1);
	}

	public void updateInFrustrum(ICamera iCamera1) {
		this.isInFrustrum = iCamera1.isBoundingBoxInFrustum(this.field_1736_v);
	}

	public void callOcclusionQueryList() {
		GL11.glCallList(this.glRenderList + 2);
	}

	public boolean canRender() {
		return !this.isInitialized ? false : this.skipRenderPass[0] && this.skipRenderPass[1];
	}

	public void markDirty() {
		this.needsUpdate = true;
	}
}
