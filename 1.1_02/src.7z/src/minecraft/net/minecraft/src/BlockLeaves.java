package net.minecraft.src;

import java.util.Random;

public class BlockLeaves extends BlockLeavesBase {
	private int baseIndexInPNG;
	int[] field_20017_a;

	protected BlockLeaves(int i1, int i2) {
		super(i1, i2, Material.leaves, false);
		this.baseIndexInPNG = i2;
		this.setTickOnLoad(true);
	}

	public int colorMultiplier(IBlockAccess iBlockAccess1, int i2, int i3, int i4) {
		iBlockAccess1.func_4075_a().func_4069_a(i2, i4, 1, 1);
		double d5 = iBlockAccess1.func_4075_a().temperature[0];
		double d7 = iBlockAccess1.func_4075_a().humidity[0];
		return ColorizerFoliage.func_4146_a(d5, d7);
	}

	public void onBlockRemoval(World world1, int i2, int i3, int i4) {
		byte b5 = 1;
		int i6 = b5 + 1;
		if(world1.checkChunksExist(i2 - i6, i3 - i6, i4 - i6, i2 + i6, i3 + i6, i4 + i6)) {
			for(int i7 = -b5; i7 <= b5; ++i7) {
				for(int i8 = -b5; i8 <= b5; ++i8) {
					for(int i9 = -b5; i9 <= b5; ++i9) {
						int i10 = world1.getBlockId(i2 + i7, i3 + i8, i4 + i9);
						if(i10 == Block.leaves.blockID) {
							world1.setBlockMetadata(i2 + i7, i3 + i8, i4 + i9, 7);
						}
					}
				}
			}
		}

	}

	public void updateTick(World world1, int i2, int i3, int i4, Random random5) {
		if(!world1.multiplayerWorld) {
			if(world1.getBlockMetadata(i2, i3, i4) == 7) {
				byte b6 = 4;
				int i7 = b6 + 1;
				byte b8 = 32;
				int i9 = b8 * b8;
				int i10 = b8 / 2;
				if(this.field_20017_a == null) {
					this.field_20017_a = new int[b8 * b8 * b8];
				}

				int i11;
				if(world1.checkChunksExist(i2 - i7, i3 - i7, i4 - i7, i2 + i7, i3 + i7, i4 + i7)) {
					i11 = -b6;

					label111:
					while(true) {
						int i12;
						int i13;
						int i14;
						if(i11 > b6) {
							i11 = 1;

							while(true) {
								if(i11 > 4) {
									break label111;
								}

								for(i12 = -b6; i12 <= b6; ++i12) {
									for(i13 = -b6; i13 <= b6; ++i13) {
										for(i14 = -b6; i14 <= b6; ++i14) {
											if(this.field_20017_a[(i12 + i10) * i9 + (i13 + i10) * b8 + i14 + i10] == i11 - 1) {
												if(this.field_20017_a[(i12 + i10 - 1) * i9 + (i13 + i10) * b8 + i14 + i10] == -2) {
													this.field_20017_a[(i12 + i10 - 1) * i9 + (i13 + i10) * b8 + i14 + i10] = i11;
												}

												if(this.field_20017_a[(i12 + i10 + 1) * i9 + (i13 + i10) * b8 + i14 + i10] == -2) {
													this.field_20017_a[(i12 + i10 + 1) * i9 + (i13 + i10) * b8 + i14 + i10] = i11;
												}

												if(this.field_20017_a[(i12 + i10) * i9 + (i13 + i10 - 1) * b8 + i14 + i10] == -2) {
													this.field_20017_a[(i12 + i10) * i9 + (i13 + i10 - 1) * b8 + i14 + i10] = i11;
												}

												if(this.field_20017_a[(i12 + i10) * i9 + (i13 + i10 + 1) * b8 + i14 + i10] == -2) {
													this.field_20017_a[(i12 + i10) * i9 + (i13 + i10 + 1) * b8 + i14 + i10] = i11;
												}

												if(this.field_20017_a[(i12 + i10) * i9 + (i13 + i10) * b8 + (i14 + i10 - 1)] == -2) {
													this.field_20017_a[(i12 + i10) * i9 + (i13 + i10) * b8 + (i14 + i10 - 1)] = i11;
												}

												if(this.field_20017_a[(i12 + i10) * i9 + (i13 + i10) * b8 + i14 + i10 + 1] == -2) {
													this.field_20017_a[(i12 + i10) * i9 + (i13 + i10) * b8 + i14 + i10 + 1] = i11;
												}
											}
										}
									}
								}

								++i11;
							}
						}

						for(i12 = -b6; i12 <= b6; ++i12) {
							for(i13 = -b6; i13 <= b6; ++i13) {
								i14 = world1.getBlockId(i2 + i11, i3 + i12, i4 + i13);
								if(i14 == Block.wood.blockID) {
									this.field_20017_a[(i11 + i10) * i9 + (i12 + i10) * b8 + i13 + i10] = 0;
								} else if(i14 == Block.leaves.blockID) {
									this.field_20017_a[(i11 + i10) * i9 + (i12 + i10) * b8 + i13 + i10] = -2;
								} else {
									this.field_20017_a[(i11 + i10) * i9 + (i12 + i10) * b8 + i13 + i10] = -1;
								}
							}
						}

						++i11;
					}
				}

				i11 = this.field_20017_a[i10 * i9 + i10 * b8 + i10];
				if(i11 >= 0) {
					world1.setBlockMetadataWithNotify(i2, i3, i4, 0);
				} else {
					this.func_6360_i(world1, i2, i3, i4);
				}
			}

		}
	}

	private void func_6360_i(World world1, int i2, int i3, int i4) {
		this.dropBlockAsItem(world1, i2, i3, i4, world1.getBlockMetadata(i2, i3, i4));
		world1.setBlockWithNotify(i2, i3, i4, 0);
	}

	public int quantityDropped(Random random1) {
		return random1.nextInt(16) == 0 ? 1 : 0;
	}

	public int idDropped(int i1, Random random2) {
		return Block.sapling.blockID;
	}

	public boolean isOpaqueCube() {
		return !this.graphicsLevel;
	}

	public void setGraphicsLevel(boolean z1) {
		this.graphicsLevel = z1;
		this.blockIndexInTexture = this.baseIndexInPNG + (z1 ? 0 : 1);
	}

	public void onEntityWalking(World world1, int i2, int i3, int i4, Entity entity5) {
		super.onEntityWalking(world1, i2, i3, i4, entity5);
	}
}
