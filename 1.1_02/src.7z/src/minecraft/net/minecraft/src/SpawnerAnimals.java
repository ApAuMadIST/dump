package net.minecraft.src;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public final class SpawnerAnimals {
	private static Set eligibleChunksForSpawning = new HashSet();

	protected static ChunkPosition getRandomSpawningPointInChunk(World world0, int i1, int i2) {
		int i3 = i1 + world0.rand.nextInt(16);
		int i4 = world0.rand.nextInt(128);
		int i5 = i2 + world0.rand.nextInt(16);
		return new ChunkPosition(i3, i4, i5);
	}

	public static final int performSpawning(World world0) {
		eligibleChunksForSpawning.clear();

		int i1;
		for(i1 = 0; i1 < world0.playerEntities.size(); ++i1) {
			EntityPlayer entityPlayer2 = (EntityPlayer)world0.playerEntities.get(i1);
			int i3 = MathHelper.floor_double(entityPlayer2.posX / 16.0D);
			int i4 = MathHelper.floor_double(entityPlayer2.posZ / 16.0D);
			byte b5 = 8;

			for(int i6 = -b5; i6 <= b5; ++i6) {
				for(int i7 = -b5; i7 <= b5; ++i7) {
					eligibleChunksForSpawning.add(new ChunkCoordIntPair(i6 + i3, i7 + i4));
				}
			}
		}

		i1 = 0;

		label113:
		for(int i28 = 0; i28 < EnumCreatureType.values().length; ++i28) {
			EnumCreatureType enumCreatureType29 = EnumCreatureType.values()[i28];
			if(world0.countEntities(enumCreatureType29.field_4278_c) <= enumCreatureType29.maxNumberOfEntityType * eligibleChunksForSpawning.size() / 256) {
				Iterator iterator30 = eligibleChunksForSpawning.iterator();

				label110:
				while(true) {
					int i8;
					int i10;
					int i11;
					int i12;
					Class[] class33;
					do {
						do {
							ChunkCoordIntPair chunkCoordIntPair31;
							do {
								do {
									do {
										if(!iterator30.hasNext()) {
											continue label113;
										}

										chunkCoordIntPair31 = (ChunkCoordIntPair)iterator30.next();
									} while(world0.rand.nextInt(50) != 0);

									MobSpawnerBase mobSpawnerBase32 = world0.func_4075_a().func_4074_a(chunkCoordIntPair31);
									class33 = mobSpawnerBase32.getEntitiesForType(enumCreatureType29);
								} while(class33 == null);
							} while(class33.length == 0);

							i8 = world0.rand.nextInt(class33.length);
							ChunkPosition chunkPosition9 = getRandomSpawningPointInChunk(world0, chunkCoordIntPair31.chunkXPos * 16, chunkCoordIntPair31.chunkZPos * 16);
							i10 = chunkPosition9.x;
							i11 = chunkPosition9.y;
							i12 = chunkPosition9.z;
						} while(world0.isBlockOpaqueCube(i10, i11, i12));
					} while(world0.getBlockMaterial(i10, i11, i12) != Material.air);

					int i13 = 0;

					for(int i14 = 0; i14 < 3; ++i14) {
						int i15 = i10;
						int i16 = i11;
						int i17 = i12;
						byte b18 = 6;

						for(int i19 = 0; i19 < 4; ++i19) {
							i15 += world0.rand.nextInt(b18) - world0.rand.nextInt(b18);
							i16 += world0.rand.nextInt(1) - world0.rand.nextInt(1);
							i17 += world0.rand.nextInt(b18) - world0.rand.nextInt(b18);
							if(world0.isBlockOpaqueCube(i15, i16 - 1, i17) && !world0.isBlockOpaqueCube(i15, i16, i17) && !world0.getBlockMaterial(i15, i16, i17).getIsLiquid() && !world0.isBlockOpaqueCube(i15, i16 + 1, i17)) {
								float f20 = (float)i15 + 0.5F;
								float f21 = (float)i16;
								float f22 = (float)i17 + 0.5F;
								if(world0.getClosestPlayer((double)f20, (double)f21, (double)f22, 24.0D) == null) {
									float f23 = f20 - (float)world0.spawnX;
									float f24 = f21 - (float)world0.spawnY;
									float f25 = f22 - (float)world0.spawnZ;
									float f26 = f23 * f23 + f24 * f24 + f25 * f25;
									if(f26 >= 576.0F) {
										EntityLiving entityLiving34;
										try {
											entityLiving34 = (EntityLiving)class33[i8].getConstructor(new Class[]{World.class}).newInstance(new Object[]{world0});
										} catch (Exception exception27) {
											exception27.printStackTrace();
											return i1;
										}

										entityLiving34.setLocationAndAngles((double)f20, (double)f21, (double)f22, world0.rand.nextFloat() * 360.0F, 0.0F);
										if(entityLiving34.getCanSpawnHere()) {
											++i13;
											world0.entityJoinedWorld(entityLiving34);
											if(entityLiving34 instanceof EntitySpider && world0.rand.nextInt(100) == 0) {
												EntitySkeleton entitySkeleton35 = new EntitySkeleton(world0);
												entitySkeleton35.setLocationAndAngles((double)f20, (double)f21, (double)f22, entityLiving34.rotationYaw, 0.0F);
												world0.entityJoinedWorld(entitySkeleton35);
												entitySkeleton35.mountEntity(entityLiving34);
											}

											if(i13 >= entityLiving34.getMaxSpawnedInChunk()) {
												continue label110;
											}
										}

										i1 += i13;
									}
								}
							}
						}
					}
				}
			}
		}

		return i1;
	}
}
