package net.minecraft.src;

public enum EnumSkyBlock {
	Sky(15),
	Block(0);

	public final int field_1722_c;

	private EnumSkyBlock(int i3) {
		this.field_1722_c = i3;
	}
}
