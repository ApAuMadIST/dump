package net.minecraft.src;

public class CraftingInventoryPlayerCB extends CraftingInventoryCB {
	public InventoryCrafting craftMatrix;
	public IInventory craftResult;
	public boolean field_20124_c;

	public CraftingInventoryPlayerCB(InventoryPlayer inventoryPlayer1) {
		this(inventoryPlayer1, true);
	}

	public CraftingInventoryPlayerCB(InventoryPlayer inventoryPlayer1, boolean z2) {
		this.craftMatrix = new InventoryCrafting(this, 2, 2);
		this.craftResult = new InventoryCraftResult();
		this.field_20124_c = false;
		this.field_20124_c = z2;
		this.func_20117_a(new SlotCrafting(this.craftMatrix, this.craftResult, 0, 144, 36));

		int i3;
		int i4;
		for(i3 = 0; i3 < 2; ++i3) {
			for(i4 = 0; i4 < 2; ++i4) {
				this.func_20117_a(new Slot(this.craftMatrix, i4 + i3 * 2, 88 + i4 * 18, 26 + i3 * 18));
			}
		}

		for(i3 = 0; i3 < 4; ++i3) {
			this.func_20117_a(new SlotArmor(this, inventoryPlayer1, inventoryPlayer1.getSizeInventory() - 1 - i3, 8, 8 + i3 * 18, i3));
		}

		for(i3 = 0; i3 < 3; ++i3) {
			for(i4 = 0; i4 < 9; ++i4) {
				this.func_20117_a(new Slot(inventoryPlayer1, i4 + (i3 + 1) * 9, 8 + i4 * 18, 84 + i3 * 18));
			}
		}

		for(i3 = 0; i3 < 9; ++i3) {
			this.func_20117_a(new Slot(inventoryPlayer1, i3, 8 + i3 * 18, 142));
		}

		this.onCraftMatrixChanged(this.craftMatrix);
	}

	public void onCraftMatrixChanged(IInventory iInventory1) {
		int[] i2 = new int[9];

		for(int i3 = 0; i3 < 3; ++i3) {
			for(int i4 = 0; i4 < 3; ++i4) {
				int i5 = -1;
				if(i3 < 2 && i4 < 2) {
					ItemStack itemStack6 = this.craftMatrix.getStackInSlot(i3 + i4 * 2);
					if(itemStack6 != null) {
						i5 = itemStack6.itemID;
					}
				}

				i2[i3 + i4 * 3] = i5;
			}
		}

		this.craftResult.setInventorySlotContents(0, CraftingManager.getInstance().craft(i2));
	}

	public void onCraftGuiClosed(EntityPlayer entityPlayer1) {
		super.onCraftGuiClosed(entityPlayer1);

		for(int i2 = 0; i2 < 4; ++i2) {
			ItemStack itemStack3 = this.craftMatrix.getStackInSlot(i2);
			if(itemStack3 != null) {
				entityPlayer1.dropPlayerItem(itemStack3);
				this.craftMatrix.setInventorySlotContents(i2, (ItemStack)null);
			}
		}

	}

	public boolean func_20120_b(EntityPlayer entityPlayer1) {
		return true;
	}
}
