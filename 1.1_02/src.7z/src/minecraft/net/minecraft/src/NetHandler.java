package net.minecraft.src;

public class NetHandler {
	public void handleMapChunk(Packet51MapChunk packet51MapChunk1) {
	}

	public void func_4114_b(Packet packet1) {
	}

	public void handleErrorMessage(String string1, Object[] object2) {
	}

	public void handleKickDisconnect(Packet255KickDisconnect packet255KickDisconnect1) {
		this.func_4114_b(packet255KickDisconnect1);
	}

	public void handleLogin(Packet1Login packet1Login1) {
		this.func_4114_b(packet1Login1);
	}

	public void handleFlying(Packet10Flying packet10Flying1) {
		this.func_4114_b(packet10Flying1);
	}

	public void handleMultiBlockChange(Packet52MultiBlockChange packet52MultiBlockChange1) {
		this.func_4114_b(packet52MultiBlockChange1);
	}

	public void handleBlockDig(Packet14BlockDig packet14BlockDig1) {
		this.func_4114_b(packet14BlockDig1);
	}

	public void handleBlockChange(Packet53BlockChange packet53BlockChange1) {
		this.func_4114_b(packet53BlockChange1);
	}

	public void handlePreChunk(Packet50PreChunk packet50PreChunk1) {
		this.func_4114_b(packet50PreChunk1);
	}

	public void handleNamedEntitySpawn(Packet20NamedEntitySpawn packet20NamedEntitySpawn1) {
		this.func_4114_b(packet20NamedEntitySpawn1);
	}

	public void handleEntity(Packet30Entity packet30Entity1) {
		this.func_4114_b(packet30Entity1);
	}

	public void handleEntityTeleport(Packet34EntityTeleport packet34EntityTeleport1) {
		this.func_4114_b(packet34EntityTeleport1);
	}

	public void handlePlace(Packet15Place packet15Place1) {
		this.func_4114_b(packet15Place1);
	}

	public void handleBlockItemSwitch(Packet16BlockItemSwitch packet16BlockItemSwitch1) {
		this.func_4114_b(packet16BlockItemSwitch1);
	}

	public void handleDestroyEntity(Packet29DestroyEntity packet29DestroyEntity1) {
		this.func_4114_b(packet29DestroyEntity1);
	}

	public void handlePickupSpawn(Packet21PickupSpawn packet21PickupSpawn1) {
		this.func_4114_b(packet21PickupSpawn1);
	}

	public void handleCollect(Packet22Collect packet22Collect1) {
		this.func_4114_b(packet22Collect1);
	}

	public void handleChat(Packet3Chat packet3Chat1) {
		this.func_4114_b(packet3Chat1);
	}

	public void handleVehicleSpawn(Packet23VehicleSpawn packet23VehicleSpawn1) {
		this.func_4114_b(packet23VehicleSpawn1);
	}

	public void handleArmAnimation(Packet18ArmAnimation packet18ArmAnimation1) {
		this.func_4114_b(packet18ArmAnimation1);
	}

	public void handleHandshake(Packet2Handshake packet2Handshake1) {
		this.func_4114_b(packet2Handshake1);
	}

	public void handleMobSpawn(Packet24MobSpawn packet24MobSpawn1) {
		this.func_4114_b(packet24MobSpawn1);
	}

	public void handleUpdateTime(Packet4UpdateTime packet4UpdateTime1) {
		this.func_4114_b(packet4UpdateTime1);
	}

	public void handleSpawnPosition(Packet6SpawnPosition packet6SpawnPosition1) {
		this.func_4114_b(packet6SpawnPosition1);
	}

	public void func_6498_a(Packet28 packet281) {
		this.func_4114_b(packet281);
	}

	public void func_6497_a(Packet39 packet391) {
		this.func_4114_b(packet391);
	}

	public void func_6499_a(Packet7 packet71) {
		this.func_4114_b(packet71);
	}

	public void func_9447_a(Packet38 packet381) {
		this.func_4114_b(packet381);
	}

	public void handleHealth(Packet8 packet81) {
		this.func_4114_b(packet81);
	}

	public void func_9448_a(Packet9 packet91) {
		this.func_4114_b(packet91);
	}

	public void func_12245_a(Packet60 packet601) {
		this.func_4114_b(packet601);
	}

	public void func_20087_a(Packet100 packet1001) {
		this.func_4114_b(packet1001);
	}

	public void func_20092_a(Packet101 packet1011) {
		this.func_4114_b(packet1011);
	}

	public void func_20091_a(Packet102 packet1021) {
		this.func_4114_b(packet1021);
	}

	public void func_20088_a(Packet103 packet1031) {
		this.func_4114_b(packet1031);
	}

	public void func_20094_a(Packet104 packet1041) {
		this.func_4114_b(packet1041);
	}

	public void func_20093_a(Packet130 packet1301) {
		this.func_4114_b(packet1301);
	}

	public void func_20090_a(Packet105 packet1051) {
		this.func_4114_b(packet1051);
	}

	public void handlePlayerInventory(Packet5PlayerInventory packet5PlayerInventory1) {
		this.func_4114_b(packet5PlayerInventory1);
	}

	public void func_20089_a(Packet106 packet1061) {
		this.func_4114_b(packet1061);
	}
}
