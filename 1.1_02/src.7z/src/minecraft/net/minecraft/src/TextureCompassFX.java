package net.minecraft.src;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

import net.minecraft.client.Minecraft;

public class TextureCompassFX extends TextureFX {
	private Minecraft mc;
	private int[] field_4230_h = new int[256];
	private double field_4229_i;
	private double field_4228_j;

	public TextureCompassFX(Minecraft minecraft1) {
		super(Item.compass.getIconIndex((ItemStack)null));
		this.mc = minecraft1;
		this.field_1128_f = 1;

		try {
			BufferedImage bufferedImage2 = ImageIO.read(Minecraft.class.getResource("/gui/items.png"));
			int i3 = this.field_1126_b % 16 * 16;
			int i4 = this.field_1126_b / 16 * 16;
			bufferedImage2.getRGB(i3, i4, 16, 16, this.field_4230_h, 0, 16);
		} catch (IOException iOException5) {
			iOException5.printStackTrace();
		}

	}

	public void func_783_a() {
		for(int i1 = 0; i1 < 256; ++i1) {
			int i2 = this.field_4230_h[i1] >> 24 & 255;
			int i3 = this.field_4230_h[i1] >> 16 & 255;
			int i4 = this.field_4230_h[i1] >> 8 & 255;
			int i5 = this.field_4230_h[i1] >> 0 & 255;
			if(this.field_1131_c) {
				int i6 = (i3 * 30 + i4 * 59 + i5 * 11) / 100;
				int i7 = (i3 * 30 + i4 * 70) / 100;
				int i8 = (i3 * 30 + i5 * 70) / 100;
				i3 = i6;
				i4 = i7;
				i5 = i8;
			}

			this.field_1127_a[i1 * 4 + 0] = (byte)i3;
			this.field_1127_a[i1 * 4 + 1] = (byte)i4;
			this.field_1127_a[i1 * 4 + 2] = (byte)i5;
			this.field_1127_a[i1 * 4 + 3] = (byte)i2;
		}

		double d20 = 0.0D;
		double d21;
		double d22;
		if(this.mc.theWorld != null && this.mc.thePlayer != null) {
			d21 = (double)this.mc.theWorld.spawnX - this.mc.thePlayer.posX;
			d22 = (double)this.mc.theWorld.spawnZ - this.mc.thePlayer.posZ;
			d20 = (double)(this.mc.thePlayer.rotationYaw - 90.0F) * Math.PI / 180.0D - Math.atan2(d22, d21);
			if(this.mc.theWorld.worldProvider.field_4220_c) {
				d20 = Math.random() * (double)(float)Math.PI * 2.0D;
			}
		}

		for(d21 = d20 - this.field_4229_i; d21 < -3.141592653589793D; d21 += Math.PI * 2D) {
		}

		while(d21 >= Math.PI) {
			d21 -= Math.PI * 2D;
		}

		if(d21 < -1.0D) {
			d21 = -1.0D;
		}

		if(d21 > 1.0D) {
			d21 = 1.0D;
		}

		this.field_4228_j += d21 * 0.1D;
		this.field_4228_j *= 0.8D;
		this.field_4229_i += this.field_4228_j;
		d22 = Math.sin(this.field_4229_i);
		double d23 = Math.cos(this.field_4229_i);

		int i9;
		int i10;
		int i11;
		int i12;
		int i13;
		int i14;
		int i15;
		short s16;
		int i17;
		int i18;
		int i19;
		for(i9 = -4; i9 <= 4; ++i9) {
			i10 = (int)(8.5D + d23 * (double)i9 * 0.3D);
			i11 = (int)(7.5D - d22 * (double)i9 * 0.3D * 0.5D);
			i12 = i11 * 16 + i10;
			i13 = 100;
			i14 = 100;
			i15 = 100;
			s16 = 255;
			if(this.field_1131_c) {
				i17 = (i13 * 30 + i14 * 59 + i15 * 11) / 100;
				i18 = (i13 * 30 + i14 * 70) / 100;
				i19 = (i13 * 30 + i15 * 70) / 100;
				i13 = i17;
				i14 = i18;
				i15 = i19;
			}

			this.field_1127_a[i12 * 4 + 0] = (byte)i13;
			this.field_1127_a[i12 * 4 + 1] = (byte)i14;
			this.field_1127_a[i12 * 4 + 2] = (byte)i15;
			this.field_1127_a[i12 * 4 + 3] = (byte)s16;
		}

		for(i9 = -8; i9 <= 16; ++i9) {
			i10 = (int)(8.5D + d22 * (double)i9 * 0.3D);
			i11 = (int)(7.5D + d23 * (double)i9 * 0.3D * 0.5D);
			i12 = i11 * 16 + i10;
			i13 = i9 >= 0 ? 255 : 100;
			i14 = i9 >= 0 ? 20 : 100;
			i15 = i9 >= 0 ? 20 : 100;
			s16 = 255;
			if(this.field_1131_c) {
				i17 = (i13 * 30 + i14 * 59 + i15 * 11) / 100;
				i18 = (i13 * 30 + i14 * 70) / 100;
				i19 = (i13 * 30 + i15 * 70) / 100;
				i13 = i17;
				i14 = i18;
				i15 = i19;
			}

			this.field_1127_a[i12 * 4 + 0] = (byte)i13;
			this.field_1127_a[i12 * 4 + 1] = (byte)i14;
			this.field_1127_a[i12 * 4 + 2] = (byte)i15;
			this.field_1127_a[i12 * 4 + 3] = (byte)s16;
		}

	}
}
