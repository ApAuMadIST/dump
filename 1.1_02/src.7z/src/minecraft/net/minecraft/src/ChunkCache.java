package net.minecraft.src;

public class ChunkCache implements IBlockAccess {
	private int field_1060_a;
	private int field_1059_b;
	private Chunk[][] field_1062_c;
	private World worldObj;

	public ChunkCache(World world1, int i2, int i3, int i4, int i5, int i6, int i7) {
		this.worldObj = world1;
		this.field_1060_a = i2 >> 4;
		this.field_1059_b = i4 >> 4;
		int i8 = i5 >> 4;
		int i9 = i7 >> 4;
		this.field_1062_c = new Chunk[i8 - this.field_1060_a + 1][i9 - this.field_1059_b + 1];

		for(int i10 = this.field_1060_a; i10 <= i8; ++i10) {
			for(int i11 = this.field_1059_b; i11 <= i9; ++i11) {
				this.field_1062_c[i10 - this.field_1060_a][i11 - this.field_1059_b] = world1.getChunkFromChunkCoords(i10, i11);
			}
		}

	}

	public int getBlockId(int i1, int i2, int i3) {
		if(i2 < 0) {
			return 0;
		} else if(i2 >= 128) {
			return 0;
		} else {
			int i4 = (i1 >> 4) - this.field_1060_a;
			int i5 = (i3 >> 4) - this.field_1059_b;
			return this.field_1062_c[i4][i5].getBlockID(i1 & 15, i2, i3 & 15);
		}
	}

	public TileEntity getBlockTileEntity(int i1, int i2, int i3) {
		int i4 = (i1 >> 4) - this.field_1060_a;
		int i5 = (i3 >> 4) - this.field_1059_b;
		return this.field_1062_c[i4][i5].getChunkBlockTileEntity(i1 & 15, i2, i3 & 15);
	}

	public float getLightBrightness(int i1, int i2, int i3) {
		return this.worldObj.worldProvider.lightBrightnessTable[this.func_4086_d(i1, i2, i3)];
	}

	public int func_4086_d(int i1, int i2, int i3) {
		return this.func_716_a(i1, i2, i3, true);
	}

	public int func_716_a(int i1, int i2, int i3, boolean z4) {
		if(i1 >= -32000000 && i3 >= -32000000 && i1 < 32000000 && i3 <= 32000000) {
			int i5;
			int i6;
			if(z4) {
				i5 = this.getBlockId(i1, i2, i3);
				if(i5 == Block.stairSingle.blockID || i5 == Block.tilledField.blockID) {
					i6 = this.func_716_a(i1, i2 + 1, i3, false);
					int i7 = this.func_716_a(i1 + 1, i2, i3, false);
					int i8 = this.func_716_a(i1 - 1, i2, i3, false);
					int i9 = this.func_716_a(i1, i2, i3 + 1, false);
					int i10 = this.func_716_a(i1, i2, i3 - 1, false);
					if(i7 > i6) {
						i6 = i7;
					}

					if(i8 > i6) {
						i6 = i8;
					}

					if(i9 > i6) {
						i6 = i9;
					}

					if(i10 > i6) {
						i6 = i10;
					}

					return i6;
				}
			}

			if(i2 < 0) {
				return 0;
			} else if(i2 >= 128) {
				i5 = 15 - this.worldObj.skylightSubtracted;
				if(i5 < 0) {
					i5 = 0;
				}

				return i5;
			} else {
				i5 = (i1 >> 4) - this.field_1060_a;
				i6 = (i3 >> 4) - this.field_1059_b;
				return this.field_1062_c[i5][i6].getBlockLightValue(i1 & 15, i2, i3 & 15, this.worldObj.skylightSubtracted);
			}
		} else {
			return 15;
		}
	}

	public int getBlockMetadata(int i1, int i2, int i3) {
		if(i2 < 0) {
			return 0;
		} else if(i2 >= 128) {
			return 0;
		} else {
			int i4 = (i1 >> 4) - this.field_1060_a;
			int i5 = (i3 >> 4) - this.field_1059_b;
			return this.field_1062_c[i4][i5].getBlockMetadata(i1 & 15, i2, i3 & 15);
		}
	}

	public Material getBlockMaterial(int i1, int i2, int i3) {
		int i4 = this.getBlockId(i1, i2, i3);
		return i4 == 0 ? Material.air : Block.blocksList[i4].blockMaterial;
	}

	public boolean isBlockOpaqueCube(int i1, int i2, int i3) {
		Block block4 = Block.blocksList[this.getBlockId(i1, i2, i3)];
		return block4 == null ? false : block4.isOpaqueCube();
	}

	public WorldChunkManager func_4075_a() {
		return this.worldObj.func_4075_a();
	}
}
