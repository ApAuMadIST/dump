package net.minecraft.src;

public class CraftingInventoryFurnaceCB extends CraftingInventoryCB {
	private TileEntityFurnace field_20127_a;
	private int field_20126_b = 0;
	private int field_20129_c = 0;
	private int field_20128_h = 0;

	public CraftingInventoryFurnaceCB(IInventory iInventory1, TileEntityFurnace tileEntityFurnace2) {
		this.field_20127_a = tileEntityFurnace2;
		this.func_20117_a(new Slot(tileEntityFurnace2, 0, 56, 17));
		this.func_20117_a(new Slot(tileEntityFurnace2, 1, 56, 53));
		this.func_20117_a(new Slot(tileEntityFurnace2, 2, 116, 35));

		int i3;
		for(i3 = 0; i3 < 3; ++i3) {
			for(int i4 = 0; i4 < 9; ++i4) {
				this.func_20117_a(new Slot(iInventory1, i4 + i3 * 9 + 9, 8 + i4 * 18, 84 + i3 * 18));
			}
		}

		for(i3 = 0; i3 < 9; ++i3) {
			this.func_20117_a(new Slot(iInventory1, i3, 8 + i3 * 18, 142));
		}

	}

	public void func_20114_a() {
		super.func_20114_a();

		for(int i1 = 0; i1 < this.field_20121_g.size(); ++i1) {
			ICrafting iCrafting2 = (ICrafting)this.field_20121_g.get(i1);
			if(this.field_20126_b != this.field_20127_a.furnaceCookTime) {
				iCrafting2.func_20158_a(this, 0, this.field_20127_a.furnaceCookTime);
			}

			if(this.field_20129_c != this.field_20127_a.furnaceBurnTime) {
				iCrafting2.func_20158_a(this, 1, this.field_20127_a.furnaceBurnTime);
			}

			if(this.field_20128_h != this.field_20127_a.currentItemBurnTime) {
				iCrafting2.func_20158_a(this, 2, this.field_20127_a.currentItemBurnTime);
			}
		}

		this.field_20126_b = this.field_20127_a.furnaceCookTime;
		this.field_20129_c = this.field_20127_a.furnaceBurnTime;
		this.field_20128_h = this.field_20127_a.currentItemBurnTime;
	}

	public void func_20112_a(int i1, int i2) {
		if(i1 == 0) {
			this.field_20127_a.furnaceCookTime = i2;
		}

		if(i1 == 1) {
			this.field_20127_a.furnaceBurnTime = i2;
		}

		if(i1 == 2) {
			this.field_20127_a.currentItemBurnTime = i2;
		}

	}

	public boolean func_20120_b(EntityPlayer entityPlayer1) {
		return this.field_20127_a.func_20070_a_(entityPlayer1);
	}
}
