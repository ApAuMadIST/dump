package net.minecraft.src;

class SlotArmor extends Slot {
	final int field_1124_c;
	final CraftingInventoryPlayerCB field_1123_d;

	SlotArmor(CraftingInventoryPlayerCB craftingInventoryPlayerCB1, IInventory iInventory2, int i3, int i4, int i5, int i6) {
		super(iInventory2, i3, i4, i5);
		this.field_1123_d = craftingInventoryPlayerCB1;
		this.field_1124_c = i6;
	}

	public int getSlotStackLimit() {
		return 1;
	}

	public boolean isItemValid(ItemStack itemStack1) {
		return itemStack1.getItem() instanceof ItemArmor ? ((ItemArmor)itemStack1.getItem()).armorType == this.field_1124_c : (itemStack1.getItem().shiftedIndex == Block.pumpkin.blockID ? this.field_1124_c == 0 : false);
	}
}
