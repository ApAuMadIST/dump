package net.minecraft.src;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Random;

import net.minecraft.client.Minecraft;

public class NetClientHandler extends NetHandler {
	private boolean disconnected = false;
	private NetworkManager netManager;
	public String field_1209_a;
	private Minecraft mc;
	private WorldClient worldClient;
	private boolean field_1210_g = false;
	Random rand = new Random();

	public NetClientHandler(Minecraft minecraft1, String string2, int i3) throws UnknownHostException, IOException {
		this.mc = minecraft1;
		Socket socket4 = new Socket(InetAddress.getByName(string2), i3);
		this.netManager = new NetworkManager(socket4, "Client", this);
	}

	public void processReadPackets() {
		if(!this.disconnected) {
			this.netManager.processReadPackets();
		}
	}

	public void handleLogin(Packet1Login packet1Login1) {
		this.mc.playerController = new PlayerControllerMP(this.mc, this);
		this.worldClient = new WorldClient(this, packet1Login1.field_4074_d, packet1Login1.field_4073_e);
		this.worldClient.multiplayerWorld = true;
		this.mc.func_6261_a(this.worldClient);
		this.mc.displayGuiScreen(new GuiDownloadTerrain(this));
		this.mc.thePlayer.field_620_ab = packet1Login1.protocolVersion;
	}

	public void handlePickupSpawn(Packet21PickupSpawn packet21PickupSpawn1) {
		double d2 = (double)packet21PickupSpawn1.xPosition / 32.0D;
		double d4 = (double)packet21PickupSpawn1.yPosition / 32.0D;
		double d6 = (double)packet21PickupSpawn1.zPosition / 32.0D;
		EntityItem entityItem8 = new EntityItem(this.worldClient, d2, d4, d6, new ItemStack(packet21PickupSpawn1.itemId, packet21PickupSpawn1.count));
		entityItem8.motionX = (double)packet21PickupSpawn1.rotation / 128.0D;
		entityItem8.motionY = (double)packet21PickupSpawn1.pitch / 128.0D;
		entityItem8.motionZ = (double)packet21PickupSpawn1.roll / 128.0D;
		entityItem8.serverPosX = packet21PickupSpawn1.xPosition;
		entityItem8.serverPosY = packet21PickupSpawn1.yPosition;
		entityItem8.serverPosZ = packet21PickupSpawn1.zPosition;
		this.worldClient.func_712_a(packet21PickupSpawn1.entityId, entityItem8);
	}

	public void handleVehicleSpawn(Packet23VehicleSpawn packet23VehicleSpawn1) {
		double d2 = (double)packet23VehicleSpawn1.xPosition / 32.0D;
		double d4 = (double)packet23VehicleSpawn1.yPosition / 32.0D;
		double d6 = (double)packet23VehicleSpawn1.zPosition / 32.0D;
		Object object8 = null;
		if(packet23VehicleSpawn1.type == 10) {
			object8 = new EntityMinecart(this.worldClient, d2, d4, d6, 0);
		}

		if(packet23VehicleSpawn1.type == 11) {
			object8 = new EntityMinecart(this.worldClient, d2, d4, d6, 1);
		}

		if(packet23VehicleSpawn1.type == 12) {
			object8 = new EntityMinecart(this.worldClient, d2, d4, d6, 2);
		}

		if(packet23VehicleSpawn1.type == 90) {
			object8 = new EntityFish(this.worldClient, d2, d4, d6);
		}

		if(packet23VehicleSpawn1.type == 60) {
			object8 = new EntityArrow(this.worldClient, d2, d4, d6);
		}

		if(packet23VehicleSpawn1.type == 61) {
			object8 = new EntitySnowball(this.worldClient, d2, d4, d6);
		}

		if(packet23VehicleSpawn1.type == 62) {
			object8 = new EntityEgg(this.worldClient, d2, d4, d6);
		}

		if(packet23VehicleSpawn1.type == 1) {
			object8 = new EntityBoat(this.worldClient, d2, d4, d6);
		}

		if(packet23VehicleSpawn1.type == 50) {
			object8 = new EntityTNTPrimed(this.worldClient, d2, d4, d6);
		}

		if(packet23VehicleSpawn1.type == 70) {
			object8 = new EntityFallingSand(this.worldClient, d2, d4, d6, Block.sand.blockID);
		}

		if(packet23VehicleSpawn1.type == 71) {
			object8 = new EntityFallingSand(this.worldClient, d2, d4, d6, Block.gravel.blockID);
		}

		if(object8 != null) {
			((Entity)object8).serverPosX = packet23VehicleSpawn1.xPosition;
			((Entity)object8).serverPosY = packet23VehicleSpawn1.yPosition;
			((Entity)object8).serverPosZ = packet23VehicleSpawn1.zPosition;
			((Entity)object8).rotationYaw = 0.0F;
			((Entity)object8).rotationPitch = 0.0F;
			((Entity)object8).field_620_ab = packet23VehicleSpawn1.entityId;
			this.worldClient.func_712_a(packet23VehicleSpawn1.entityId, (Entity)object8);
		}

	}

	public void func_6498_a(Packet28 packet281) {
		Entity entity2 = this.func_12246_a(packet281.field_6367_a);
		if(entity2 != null) {
			entity2.setVelocity((double)packet281.field_6366_b / 8000.0D, (double)packet281.field_6369_c / 8000.0D, (double)packet281.field_6368_d / 8000.0D);
		}
	}

	public void handleNamedEntitySpawn(Packet20NamedEntitySpawn packet20NamedEntitySpawn1) {
		double d2 = (double)packet20NamedEntitySpawn1.xPosition / 32.0D;
		double d4 = (double)packet20NamedEntitySpawn1.yPosition / 32.0D;
		double d6 = (double)packet20NamedEntitySpawn1.zPosition / 32.0D;
		float f8 = (float)(packet20NamedEntitySpawn1.rotation * 360) / 256.0F;
		float f9 = (float)(packet20NamedEntitySpawn1.pitch * 360) / 256.0F;
		EntityOtherPlayerMP entityOtherPlayerMP10 = new EntityOtherPlayerMP(this.mc.theWorld, packet20NamedEntitySpawn1.name);
		entityOtherPlayerMP10.serverPosX = packet20NamedEntitySpawn1.xPosition;
		entityOtherPlayerMP10.serverPosY = packet20NamedEntitySpawn1.yPosition;
		entityOtherPlayerMP10.serverPosZ = packet20NamedEntitySpawn1.zPosition;
		int i11 = packet20NamedEntitySpawn1.currentItem;
		if(i11 == 0) {
			entityOtherPlayerMP10.inventory.mainInventory[entityOtherPlayerMP10.inventory.currentItem] = null;
		} else {
			entityOtherPlayerMP10.inventory.mainInventory[entityOtherPlayerMP10.inventory.currentItem] = new ItemStack(i11);
		}

		entityOtherPlayerMP10.setPositionAndRotation(d2, d4, d6, f8, f9);
		this.worldClient.func_712_a(packet20NamedEntitySpawn1.entityId, entityOtherPlayerMP10);
	}

	public void handleEntityTeleport(Packet34EntityTeleport packet34EntityTeleport1) {
		Entity entity2 = this.func_12246_a(packet34EntityTeleport1.entityId);
		if(entity2 != null) {
			entity2.serverPosX = packet34EntityTeleport1.xPosition;
			entity2.serverPosY = packet34EntityTeleport1.yPosition;
			entity2.serverPosZ = packet34EntityTeleport1.zPosition;
			double d3 = (double)entity2.serverPosX / 32.0D;
			double d5 = (double)entity2.serverPosY / 32.0D + 0.015625D;
			double d7 = (double)entity2.serverPosZ / 32.0D;
			float f9 = (float)(packet34EntityTeleport1.yaw * 360) / 256.0F;
			float f10 = (float)(packet34EntityTeleport1.pitch * 360) / 256.0F;
			entity2.setPositionAndRotation2(d3, d5, d7, f9, f10, 3);
		}
	}

	public void handleEntity(Packet30Entity packet30Entity1) {
		Entity entity2 = this.func_12246_a(packet30Entity1.entityId);
		if(entity2 != null) {
			entity2.serverPosX += packet30Entity1.xPosition;
			entity2.serverPosY += packet30Entity1.yPosition;
			entity2.serverPosZ += packet30Entity1.zPosition;
			double d3 = (double)entity2.serverPosX / 32.0D;
			double d5 = (double)entity2.serverPosY / 32.0D + 0.015625D;
			double d7 = (double)entity2.serverPosZ / 32.0D;
			float f9 = packet30Entity1.rotating ? (float)(packet30Entity1.yaw * 360) / 256.0F : entity2.rotationYaw;
			float f10 = packet30Entity1.rotating ? (float)(packet30Entity1.pitch * 360) / 256.0F : entity2.rotationPitch;
			entity2.setPositionAndRotation2(d3, d5, d7, f9, f10, 3);
		}
	}

	public void handleDestroyEntity(Packet29DestroyEntity packet29DestroyEntity1) {
		this.worldClient.removeEntityFromWorld(packet29DestroyEntity1.entityId);
	}

	public void handleFlying(Packet10Flying packet10Flying1) {
		EntityPlayerSP entityPlayerSP2 = this.mc.thePlayer;
		double d3 = entityPlayerSP2.posX;
		double d5 = entityPlayerSP2.posY;
		double d7 = entityPlayerSP2.posZ;
		float f9 = entityPlayerSP2.rotationYaw;
		float f10 = entityPlayerSP2.rotationPitch;
		if(packet10Flying1.moving) {
			d3 = packet10Flying1.xPosition;
			d5 = packet10Flying1.yPosition;
			d7 = packet10Flying1.zPosition;
		}

		if(packet10Flying1.rotating) {
			f9 = packet10Flying1.yaw;
			f10 = packet10Flying1.pitch;
		}

		entityPlayerSP2.field_9287_aY = 0.0F;
		entityPlayerSP2.motionX = entityPlayerSP2.motionY = entityPlayerSP2.motionZ = 0.0D;
		entityPlayerSP2.setPositionAndRotation(d3, d5, d7, f9, f10);
		packet10Flying1.xPosition = entityPlayerSP2.posX;
		packet10Flying1.yPosition = entityPlayerSP2.boundingBox.minY;
		packet10Flying1.zPosition = entityPlayerSP2.posZ;
		packet10Flying1.stance = entityPlayerSP2.posY;
		this.netManager.addToSendQueue(packet10Flying1);
		if(!this.field_1210_g) {
			this.mc.thePlayer.prevPosX = this.mc.thePlayer.posX;
			this.mc.thePlayer.prevPosY = this.mc.thePlayer.posY;
			this.mc.thePlayer.prevPosZ = this.mc.thePlayer.posZ;
			this.field_1210_g = true;
			this.mc.displayGuiScreen((GuiScreen)null);
		}

	}

	public void handlePreChunk(Packet50PreChunk packet50PreChunk1) {
		this.worldClient.func_713_a(packet50PreChunk1.xPosition, packet50PreChunk1.yPosition, packet50PreChunk1.mode);
	}

	public void handleMultiBlockChange(Packet52MultiBlockChange packet52MultiBlockChange1) {
		Chunk chunk2 = this.worldClient.getChunkFromChunkCoords(packet52MultiBlockChange1.xPosition, packet52MultiBlockChange1.zPosition);
		int i3 = packet52MultiBlockChange1.xPosition * 16;
		int i4 = packet52MultiBlockChange1.zPosition * 16;

		for(int i5 = 0; i5 < packet52MultiBlockChange1.size; ++i5) {
			short s6 = packet52MultiBlockChange1.coordinateArray[i5];
			int i7 = packet52MultiBlockChange1.typeArray[i5] & 255;
			byte b8 = packet52MultiBlockChange1.metadataArray[i5];
			int i9 = s6 >> 12 & 15;
			int i10 = s6 >> 8 & 15;
			int i11 = s6 & 255;
			chunk2.setBlockIDWithMetadata(i9, i11, i10, i7, b8);
			this.worldClient.func_711_c(i9 + i3, i11, i10 + i4, i9 + i3, i11, i10 + i4);
			this.worldClient.func_701_b(i9 + i3, i11, i10 + i4, i9 + i3, i11, i10 + i4);
		}

	}

	public void handleMapChunk(Packet51MapChunk packet51MapChunk1) {
		this.worldClient.func_711_c(packet51MapChunk1.xPosition, packet51MapChunk1.yPosition, packet51MapChunk1.zPosition, packet51MapChunk1.xPosition + packet51MapChunk1.xSize - 1, packet51MapChunk1.yPosition + packet51MapChunk1.ySize - 1, packet51MapChunk1.zPosition + packet51MapChunk1.zSize - 1);
		this.worldClient.func_693_a(packet51MapChunk1.xPosition, packet51MapChunk1.yPosition, packet51MapChunk1.zPosition, packet51MapChunk1.xSize, packet51MapChunk1.ySize, packet51MapChunk1.zSize, packet51MapChunk1.chunk);
	}

	public void handleBlockChange(Packet53BlockChange packet53BlockChange1) {
		this.worldClient.func_714_c(packet53BlockChange1.xPosition, packet53BlockChange1.yPosition, packet53BlockChange1.zPosition, packet53BlockChange1.type, packet53BlockChange1.metadata);
	}

	public void handleKickDisconnect(Packet255KickDisconnect packet255KickDisconnect1) {
		this.netManager.networkShutdown("disconnect.kicked", new Object[0]);
		this.disconnected = true;
		this.mc.func_6261_a((World)null);
		this.mc.displayGuiScreen(new GuiConnectFailed("disconnect.disconnected", "disconnect.genericReason", new Object[]{packet255KickDisconnect1.reason}));
	}

	public void handleErrorMessage(String string1, Object[] object2) {
		if(!this.disconnected) {
			this.disconnected = true;
			this.mc.func_6261_a((World)null);
			this.mc.displayGuiScreen(new GuiConnectFailed("disconnect.lost", string1, object2));
		}
	}

	public void addToSendQueue(Packet packet1) {
		if(!this.disconnected) {
			this.netManager.addToSendQueue(packet1);
		}
	}

	public void handleCollect(Packet22Collect packet22Collect1) {
		Entity entity2 = this.func_12246_a(packet22Collect1.collectedEntityId);
		Object object3 = (EntityLiving)this.func_12246_a(packet22Collect1.collectorEntityId);
		if(object3 == null) {
			object3 = this.mc.thePlayer;
		}

		if(entity2 != null) {
			this.worldClient.playSoundAtEntity(entity2, "random.pop", 0.2F, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
			this.mc.effectRenderer.func_1192_a(new EntityPickupFX(this.mc.theWorld, entity2, (Entity)object3, -0.5F));
			this.worldClient.removeEntityFromWorld(packet22Collect1.collectedEntityId);
		}

	}

	public void handleChat(Packet3Chat packet3Chat1) {
		this.mc.ingameGUI.addChatMessage(packet3Chat1.message);
	}

	public void handleArmAnimation(Packet18ArmAnimation packet18ArmAnimation1) {
		Entity entity2 = this.func_12246_a(packet18ArmAnimation1.entityId);
		if(entity2 != null) {
			if(packet18ArmAnimation1.animate == 1) {
				EntityPlayer entityPlayer3 = (EntityPlayer)entity2;
				entityPlayer3.swingItem();
			} else if(packet18ArmAnimation1.animate == 100) {
				entity2.field_9300_bu = true;
			} else if(packet18ArmAnimation1.animate == 101) {
				entity2.field_9300_bu = false;
			} else if(packet18ArmAnimation1.animate == 102) {
				entity2.field_9299_bv = true;
			} else if(packet18ArmAnimation1.animate == 103) {
				entity2.field_9299_bv = false;
			} else if(packet18ArmAnimation1.animate == 104) {
				entity2.field_12240_bw = true;
			} else if(packet18ArmAnimation1.animate == 105) {
				entity2.field_12240_bw = false;
			} else if(packet18ArmAnimation1.animate == 2) {
				entity2.performHurtAnimation();
			}

		}
	}

	public void handleHandshake(Packet2Handshake packet2Handshake1) {
		if(packet2Handshake1.username.equals("-")) {
			this.addToSendQueue(new Packet1Login(this.mc.session.playerName, "Password", 8));
		} else {
			try {
				URL uRL2 = new URL("http://www.minecraft.net/game/joinserver.jsp?user=" + this.mc.session.playerName + "&sessionId=" + this.mc.session.field_6543_c + "&serverId=" + packet2Handshake1.username);
				BufferedReader bufferedReader3 = new BufferedReader(new InputStreamReader(uRL2.openStream()));
				String string4 = bufferedReader3.readLine();
				bufferedReader3.close();
				if(string4.equalsIgnoreCase("ok")) {
					this.addToSendQueue(new Packet1Login(this.mc.session.playerName, "Password", 8));
				} else {
					this.netManager.networkShutdown("disconnect.loginFailedInfo", new Object[]{string4});
				}
			} catch (Exception exception5) {
				exception5.printStackTrace();
				this.netManager.networkShutdown("disconnect.genericReason", new Object[]{"Internal client error: " + exception5.toString()});
			}
		}

	}

	public void disconnect() {
		this.disconnected = true;
		this.netManager.networkShutdown("disconnect.closed", new Object[0]);
	}

	public void handleMobSpawn(Packet24MobSpawn packet24MobSpawn1) {
		double d2 = (double)packet24MobSpawn1.xPosition / 32.0D;
		double d4 = (double)packet24MobSpawn1.yPosition / 32.0D;
		double d6 = (double)packet24MobSpawn1.zPosition / 32.0D;
		float f8 = (float)(packet24MobSpawn1.yaw * 360) / 256.0F;
		float f9 = (float)(packet24MobSpawn1.pitch * 360) / 256.0F;
		EntityLiving entityLiving10 = (EntityLiving)EntityList.createEntity(packet24MobSpawn1.type, this.mc.theWorld);
		entityLiving10.serverPosX = packet24MobSpawn1.xPosition;
		entityLiving10.serverPosY = packet24MobSpawn1.yPosition;
		entityLiving10.serverPosZ = packet24MobSpawn1.zPosition;
		entityLiving10.field_620_ab = packet24MobSpawn1.entityId;
		entityLiving10.setPositionAndRotation(d2, d4, d6, f8, f9);
		entityLiving10.field_9343_G = true;
		this.worldClient.func_712_a(packet24MobSpawn1.entityId, entityLiving10);
	}

	public void handleUpdateTime(Packet4UpdateTime packet4UpdateTime1) {
		this.mc.theWorld.setWorldTime(packet4UpdateTime1.time);
	}

	public void handleSpawnPosition(Packet6SpawnPosition packet6SpawnPosition1) {
		this.worldClient.spawnX = packet6SpawnPosition1.xPosition;
		this.worldClient.spawnY = packet6SpawnPosition1.yPosition;
		this.worldClient.spawnZ = packet6SpawnPosition1.zPosition;
	}

	public void func_6497_a(Packet39 packet391) {
		Object object2 = this.func_12246_a(packet391.field_6365_a);
		Entity entity3 = this.func_12246_a(packet391.field_6364_b);
		if(packet391.field_6365_a == this.mc.thePlayer.field_620_ab) {
			object2 = this.mc.thePlayer;
		}

		if(object2 != null) {
			((Entity)object2).mountEntity(entity3);
		}
	}

	public void func_9447_a(Packet38 packet381) {
		Entity entity2 = this.func_12246_a(packet381.field_9274_a);
		if(entity2 != null) {
			entity2.func_9282_a(packet381.field_9273_b);
		}

	}

	private Entity func_12246_a(int i1) {
		return (Entity)(i1 == this.mc.thePlayer.field_620_ab ? this.mc.thePlayer : this.worldClient.func_709_b(i1));
	}

	public void handleHealth(Packet8 packet81) {
		this.mc.thePlayer.setHealth(packet81.healthMP);
	}

	public void func_9448_a(Packet9 packet91) {
		this.mc.respawn();
	}

	public void func_12245_a(Packet60 packet601) {
		Explosion explosion2 = new Explosion(this.mc.theWorld, (Entity)null, packet601.field_12236_a, packet601.field_12235_b, packet601.field_12239_c, packet601.field_12238_d);
		explosion2.field_12251_g = packet601.field_12237_e;
		explosion2.func_12247_b();
	}

	public void func_20087_a(Packet100 packet1001) {
		if(packet1001.field_20037_b == 0) {
			InventoryBasic inventoryBasic2 = new InventoryBasic(packet1001.field_20040_c, packet1001.field_20039_d);
			this.mc.thePlayer.displayGUIChest(inventoryBasic2);
			this.mc.thePlayer.field_20068_h.unusedList = packet1001.field_20038_a;
		} else if(packet1001.field_20037_b == 2) {
			TileEntityFurnace tileEntityFurnace3 = new TileEntityFurnace();
			this.mc.thePlayer.displayGUIFurnace(tileEntityFurnace3);
			this.mc.thePlayer.field_20068_h.unusedList = packet1001.field_20038_a;
		} else if(packet1001.field_20037_b == 1) {
			EntityPlayerSP entityPlayerSP4 = this.mc.thePlayer;
			this.mc.thePlayer.displayWorkbenchGUI(MathHelper.floor_double(entityPlayerSP4.posX), MathHelper.floor_double(entityPlayerSP4.posY), MathHelper.floor_double(entityPlayerSP4.posZ));
			this.mc.thePlayer.field_20068_h.unusedList = packet1001.field_20038_a;
		}

	}

	public void func_20088_a(Packet103 packet1031) {
		if(packet1031.field_20042_a == -1) {
			this.mc.thePlayer.inventory.func_20076_b(packet1031.field_20043_c);
		} else if(packet1031.field_20042_a == 0) {
			this.mc.thePlayer.field_20069_g.func_20119_a(packet1031.field_20041_b, packet1031.field_20043_c);
		} else if(packet1031.field_20042_a == this.mc.thePlayer.field_20068_h.unusedList) {
			this.mc.thePlayer.field_20068_h.func_20119_a(packet1031.field_20041_b, packet1031.field_20043_c);
		}

	}

	public void func_20089_a(Packet106 packet1061) {
		CraftingInventoryCB craftingInventoryCB2 = null;
		if(packet1061.field_20029_a == 0) {
			craftingInventoryCB2 = this.mc.thePlayer.field_20069_g;
		} else if(packet1061.field_20029_a == this.mc.thePlayer.field_20068_h.unusedList) {
			craftingInventoryCB2 = this.mc.thePlayer.field_20068_h;
		}

		if(craftingInventoryCB2 != null) {
			if(packet1061.field_20030_c) {
				craftingInventoryCB2.func_20113_a(packet1061.field_20028_b);
			} else {
				craftingInventoryCB2.func_20110_b(packet1061.field_20028_b);
				this.addToSendQueue(new Packet106(packet1061.field_20029_a, packet1061.field_20028_b, true));
			}
		}

	}

	public void func_20094_a(Packet104 packet1041) {
		if(packet1041.field_20036_a == 0) {
			this.mc.thePlayer.field_20069_g.func_20115_a(packet1041.field_20035_b);
		} else if(packet1041.field_20036_a == this.mc.thePlayer.field_20068_h.unusedList) {
			this.mc.thePlayer.field_20068_h.func_20115_a(packet1041.field_20035_b);
		}

	}

	public void func_20093_a(Packet130 packet1301) {
		if(this.mc.theWorld.blockExists(packet1301.field_20020_a, packet1301.field_20019_b, packet1301.field_20022_c)) {
			TileEntity tileEntity2 = this.mc.theWorld.getBlockTileEntity(packet1301.field_20020_a, packet1301.field_20019_b, packet1301.field_20022_c);
			if(tileEntity2 instanceof TileEntitySign) {
				TileEntitySign tileEntitySign3 = (TileEntitySign)tileEntity2;

				for(int i4 = 0; i4 < 4; ++i4) {
					tileEntitySign3.signText[i4] = packet1301.field_20021_d[i4];
				}

				tileEntitySign3.onInventoryChanged();
			}
		}

	}

	public void func_20090_a(Packet105 packet1051) {
		this.func_4114_b(packet1051);
		if(this.mc.thePlayer.field_20068_h != null && this.mc.thePlayer.field_20068_h.unusedList == packet1051.field_20032_a) {
			this.mc.thePlayer.field_20068_h.func_20112_a(packet1051.field_20031_b, packet1051.field_20033_c);
		}

	}

	public void handlePlayerInventory(Packet5PlayerInventory packet5PlayerInventory1) {
		Entity entity2 = this.func_12246_a(packet5PlayerInventory1.type);
		if(entity2 != null) {
			entity2.func_20045_c(packet5PlayerInventory1.stacks, packet5PlayerInventory1.field_20044_c);
		}

	}

	public void func_20092_a(Packet101 packet1011) {
		this.mc.thePlayer.func_20059_m();
	}
}
