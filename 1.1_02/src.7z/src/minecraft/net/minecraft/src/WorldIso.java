package net.minecraft.src;

import java.io.File;

class WorldIso extends World {
	final CanvasIsomPreview A;

	WorldIso(CanvasIsomPreview canvasIsomPreview1, File file2, String string3) {
		super(file2, string3);
		this.A = canvasIsomPreview1;
	}

	protected IChunkProvider func_4081_a(File file1) {
		return new ChunkProviderIso(this, new ChunkLoader(file1, false));
	}
}
