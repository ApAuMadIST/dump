package net.minecraft.src;

import java.util.Comparator;

public class EntitySorter implements Comparator {
	private Entity field_1594_a;

	public EntitySorter(Entity entity1) {
		this.field_1594_a = entity1;
	}

	public int a(WorldRenderer worldRenderer1, WorldRenderer worldRenderer2) {
		return worldRenderer1.distanceToEntity(this.field_1594_a) < worldRenderer2.distanceToEntity(this.field_1594_a) ? -1 : 1;
	}

	public int compare(Object object1, Object object2) {
		return this.a((WorldRenderer)object1, (WorldRenderer)object2);
	}
}
