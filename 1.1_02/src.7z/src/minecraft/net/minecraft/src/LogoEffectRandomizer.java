package net.minecraft.src;

class LogoEffectRandomizer {
	public double field_1312_a;
	public double field_1311_b;
	public double field_1314_c;
	final GuiMainMenu mainMenu;

	public LogoEffectRandomizer(GuiMainMenu guiMainMenu1, int i2, int i3) {
		this.mainMenu = guiMainMenu1;
		this.field_1312_a = this.field_1311_b = (double)(10 + i3) + GuiMainMenu.getRand().nextDouble() * 32.0D + (double)i2;
	}

	public void func_875_a() {
		this.field_1311_b = this.field_1312_a;
		if(this.field_1312_a > 0.0D) {
			this.field_1314_c -= 0.6D;
		}

		this.field_1312_a += this.field_1314_c;
		this.field_1314_c *= 0.9D;
		if(this.field_1312_a < 0.0D) {
			this.field_1312_a = 0.0D;
			this.field_1314_c = 0.0D;
		}

	}
}
