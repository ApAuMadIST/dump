package net.minecraft.src;

import org.lwjgl.input.Keyboard;

public class GuiMultiplayer extends GuiScreen {
	private GuiScreen updateCounter;
	private int parentScreen = 0;
	private String serverAddress = "";

	public GuiMultiplayer(GuiScreen guiScreen1) {
		this.updateCounter = guiScreen1;
	}

	public void updateScreen() {
		++this.parentScreen;
	}

	public void initGui() {
		StringTranslate stringTranslate1 = StringTranslate.func_20162_a();
		Keyboard.enableRepeatEvents(true);
		this.controlList.clear();
		this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 96 + 12, stringTranslate1.func_20163_a("multiplayer.connect")));
		this.controlList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 120 + 12, stringTranslate1.func_20163_a("gui.cancel")));
		this.serverAddress = this.mc.gameSettings.lastServer.replaceAll("_", ":");
		((GuiButton)this.controlList.get(0)).enabled = this.serverAddress.length() > 0;
	}

	public void onGuiClosed() {
		Keyboard.enableRepeatEvents(false);
	}

	protected void actionPerformed(GuiButton guiButton1) {
		if(guiButton1.enabled) {
			if(guiButton1.id == 1) {
				this.mc.displayGuiScreen(this.updateCounter);
			} else if(guiButton1.id == 0) {
				this.mc.gameSettings.lastServer = this.serverAddress.replaceAll(":", "_");
				this.mc.gameSettings.saveOptions();
				String[] string2 = this.serverAddress.split(":");
				this.mc.displayGuiScreen(new GuiConnecting(this.mc, string2[0], string2.length > 1 ? this.func_4067_a(string2[1], 25565) : 25565));
			}

		}
	}

	private int func_4067_a(String string1, int i2) {
		try {
			return Integer.parseInt(string1.trim());
		} catch (Exception exception4) {
			return i2;
		}
	}

	protected void keyTyped(char c1, int i2) {
		if(c1 == 22) {
			String string3 = GuiScreen.getClipboardString();
			if(string3 == null) {
				string3 = "";
			}

			int i4 = 32 - this.serverAddress.length();
			if(i4 > string3.length()) {
				i4 = string3.length();
			}

			if(i4 > 0) {
				this.serverAddress = this.serverAddress + string3.substring(0, i4);
			}
		}

		if(c1 == 13) {
			this.actionPerformed((GuiButton)this.controlList.get(0));
		}

		if(i2 == 14 && this.serverAddress.length() > 0) {
			this.serverAddress = this.serverAddress.substring(0, this.serverAddress.length() - 1);
		}

		if(FontAllowedCharacters.field_20157_a.indexOf(c1) >= 0 && this.serverAddress.length() < 32) {
			this.serverAddress = this.serverAddress + c1;
		}

		((GuiButton)this.controlList.get(0)).enabled = this.serverAddress.length() > 0;
	}

	public void drawScreen(int i1, int i2, float f3) {
		StringTranslate stringTranslate4 = StringTranslate.func_20162_a();
		this.drawDefaultBackground();
		this.drawCenteredString(this.fontRenderer, stringTranslate4.func_20163_a("multiplayer.title"), this.width / 2, this.height / 4 - 60 + 20, 0xFFFFFF);
		this.drawString(this.fontRenderer, stringTranslate4.func_20163_a("multiplayer.info1"), this.width / 2 - 140, this.height / 4 - 60 + 60 + 0, 10526880);
		this.drawString(this.fontRenderer, stringTranslate4.func_20163_a("multiplayer.info2"), this.width / 2 - 140, this.height / 4 - 60 + 60 + 9, 10526880);
		this.drawString(this.fontRenderer, stringTranslate4.func_20163_a("multiplayer.ipinfo"), this.width / 2 - 140, this.height / 4 - 60 + 60 + 36, 10526880);
		int i5 = this.width / 2 - 100;
		int i6 = this.height / 4 - 10 + 50 + 18;
		short s7 = 200;
		byte b8 = 20;
		this.drawRect(i5 - 1, i6 - 1, i5 + s7 + 1, i6 + b8 + 1, -6250336);
		this.drawRect(i5, i6, i5 + s7, i6 + b8, 0xFF000000);
		this.drawString(this.fontRenderer, this.serverAddress + (this.parentScreen / 6 % 2 == 0 ? "_" : ""), i5 + 4, i6 + (b8 - 8) / 2, 14737632);
		super.drawScreen(i1, i2, f3);
	}
}
