package net.minecraft.src;

public class GuiOptions extends GuiScreen {
	private GuiScreen parentScreen;
	protected String screenTitle = "Options";
	private GameSettings options;

	public GuiOptions(GuiScreen guiScreen1, GameSettings gameSettings2) {
		this.parentScreen = guiScreen1;
		this.options = gameSettings2;
	}

	public void initGui() {
		StringTranslate stringTranslate1 = StringTranslate.func_20162_a();
		this.screenTitle = stringTranslate1.func_20163_a("options.title");
		EnumOptions[] enumOptions2 = EnumOptions.values();
		int i3 = enumOptions2.length;

		for(int i4 = 0; i4 < i3; ++i4) {
			EnumOptions enumOptions5 = enumOptions2[i4];
			int i6 = enumOptions5.func_20135_c();
			if(!enumOptions5.func_20136_a()) {
				this.controlList.add(new GuiSmallButton(enumOptions5.func_20135_c(), this.width / 2 - 155 + i6 % 2 * 160, this.height / 6 + 24 * (i6 >> 1), enumOptions5, this.options.getKeyBinding(enumOptions5)));
			} else {
				this.controlList.add(new GuiSlider(enumOptions5.func_20135_c(), this.width / 2 - 155 + i6 % 2 * 160, this.height / 6 + 24 * (i6 >> 1), enumOptions5, this.options.getKeyBinding(enumOptions5), this.options.func_20104_a(enumOptions5)));
			}
		}

		this.controlList.add(new GuiButton(100, this.width / 2 - 100, this.height / 6 + 120 + 12, stringTranslate1.func_20163_a("options.controls")));
		this.controlList.add(new GuiButton(200, this.width / 2 - 100, this.height / 6 + 168, stringTranslate1.func_20163_a("gui.done")));
	}

	protected void actionPerformed(GuiButton guiButton1) {
		if(guiButton1.enabled) {
			if(guiButton1.id < 100 && guiButton1 instanceof GuiSmallButton) {
				this.options.setOptionValue(((GuiSmallButton)guiButton1).func_20078_a(), 1);
				guiButton1.displayString = this.options.getKeyBinding(EnumOptions.func_20137_a(guiButton1.id));
			}

			if(guiButton1.id == 100) {
				this.mc.gameSettings.saveOptions();
				this.mc.displayGuiScreen(new GuiControls(this, this.options));
			}

			if(guiButton1.id == 200) {
				this.mc.gameSettings.saveOptions();
				this.mc.displayGuiScreen(this.parentScreen);
			}

		}
	}

	public void drawScreen(int i1, int i2, float f3) {
		this.drawDefaultBackground();
		this.drawCenteredString(this.fontRenderer, this.screenTitle, this.width / 2, 20, 0xFFFFFF);
		super.drawScreen(i1, i2, f3);
	}
}
