package net.minecraft.src;

public class ItemAxe extends ItemTool {
	private static Block[] blocksEffectiveAgainst = new Block[]{Block.planks, Block.bookShelf, Block.wood, Block.crate};

	public ItemAxe(int i1, int i2) {
		super(i1, 3, i2, blocksEffectiveAgainst);
	}
}
